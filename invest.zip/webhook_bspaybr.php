<?php
// webhook_bspaybr.php - VERSÃO COMPLETA CORRIGIDA
// (Sugestão: Coloque este arquivo na raiz do seu public_html,
// ao lado das pastas 'adm' e 'servidor')

// Define o arquivo de log específico para o webhook
define('LOG_FILE_WEBHOOK', __DIR__ . '/webhook_bspaybr.log');

/**
 * Função para registrar mensagens no log do webhook.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_log_webhook($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(LOG_FILE_WEBHOOK, $log_entry, FILE_APPEND);
}

write_log_webhook("=== WEBHOOK BSPayBR ACIONADO ===", 'DEBUG');
write_log_webhook("Método: " . $_SERVER['REQUEST_METHOD'], 'DEBUG');
write_log_webhook("IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A'), 'DEBUG');
write_log_webhook("User-Agent: " . ($_SERVER['HTTP_USER_AGENT'] ?? 'N/A'), 'DEBUG');

// Inclua o arquivo de conexão com o banco de dados
require 'servidor/database.php';

// Configura o fuso horário para o log
date_default_timezone_set('America/Fortaleza');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!$data) {
        write_log_webhook("ERRO: Dados JSON inválidos ou ausentes.", 'ERROR');
        http_response_code(400); // Bad Request
        exit('Invalid JSON');
    }
    
    write_log_webhook("Dados brutos recebidos: " . $input, 'DEBUG');
    write_log_webhook("Dados parseados: " . print_r($data, true), 'DEBUG');

    // CORREÇÃO: Verificar se os dados estão dentro de 'requestBody'
    $webhookData = isset($data['requestBody']) ? $data['requestBody'] : $data;
    write_log_webhook("Dados do webhook após processamento: " . print_r($webhookData, true), 'DEBUG');
    
    // Identifica o tipo de transação pelo campo 'transactionType'
    $transactionType = $webhookData['transactionType'] ?? null;
    $bspaybrExternalId = $webhookData['external_id'] ?? null;

    if (!$transactionType) {
        write_log_webhook("ERRO: Tipo de transação 'transactionType' ausente no payload.", 'ERROR');
        http_response_code(400);
        exit('Missing transactionType');
    }
    
    write_log_webhook("Processando transactionType: '$transactionType', external_id: '$bspaybrExternalId'", 'INFO');
    
    // Inicia a transação no banco de dados
    $conn->begin_transaction();
    try {
        switch ($transactionType) {
            case 'RECEIVEPIX': // Lógica para DEPOSITOS
                write_log_webhook("Processando RECEIVEPIX (Depósito)", 'INFO');
                $bspaybrStatus = $webhookData['status'] ?? null;
                if (!$bspaybrExternalId || !$bspaybrStatus) {
                    write_log_webhook("ERRO RECEIVEPIX: Dados essenciais ausentes (external_id ou status).", 'ERROR');
                    throw new Exception("Dados essenciais ausentes para RECEIVEPIX.");
                }

                // Busca a transação de depósito
                $sql = "SELECT id, status, amount, user_id FROM depositos WHERE external_id = ? FOR UPDATE";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Erro ao preparar consulta de depósito: " . $conn->error);
                }
                $stmt->bind_param("s", $bspaybrExternalId);
                $stmt->execute();
                $result = $stmt->get_result();
                $transacao = $result->fetch_assoc();
                $stmt->close();

                if ($transacao) {
                    $currentStatus = $transacao['status'];
                    $depositoId = $transacao['id'];
                    $amount = $transacao['amount'];
                    $usuarioId = $transacao['user_id'];
                    $bspaybrStatusLower = strtolower($bspaybrStatus);

                    if ($bspaybrStatusLower === 'paid' && $currentStatus === 'pendente') {
                        $newStatus = 'pago';
                        $updateSql = "UPDATE depositos SET status = ?, data_confirmacao = NOW() WHERE id = ?";
                        $updateStmt = $conn->prepare($updateSql);
                        $updateStmt->bind_param("si", $newStatus, $depositoId);
                        $updateStmt->execute();
                        $updateStmt->close();
                        
                        // Adicionar o valor ao saldo do usuário
                        $sql_update_saldo = "UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?";
                        $stmt_update_saldo = $conn->prepare($sql_update_saldo);
                        $stmt_update_saldo->bind_param("di", $amount, $usuarioId);
                        $stmt_update_saldo->execute();
                        $stmt_update_saldo->close();

                        write_log_webhook("SUCCESS: Depósito ID {$depositoId} marcado como 'pago'. Saldo de R$ {$amount} adicionado ao usuário ID {$usuarioId}.", 'INFO');
                    } else {
                        write_log_webhook("INFO: Depósito ID {$depositoId} já está em status '{$currentStatus}', ignorando status '{$bspaybrStatus}' da BSPayBR.", 'INFO');
                    }
                } else {
                    write_log_webhook("WARNING: Transação RECEIVEPIX (external_id: {$bspaybrExternalId}) não encontrada no sistema.", 'WARNING');
                }
                break;

            case 'PAYMENT': // Lógica para SAQUES
                write_log_webhook("Processando PAYMENT (Saque)", 'INFO');
                $bspaybrTransactionId = $webhookData['transactionId'] ?? null;
                $bspaybrStatusId = $webhookData['statusCode']['statusId'] ?? null;
                $bspaybrStatusDesc = $webhookData['statusCode']['description'] ?? null;

                write_log_webhook("Dados PAYMENT: transactionId='$bspaybrTransactionId', external_id='$bspaybrExternalId', statusId='$bspaybrStatusId', description='$bspaybrStatusDesc'", 'DEBUG');

                if (!$bspaybrExternalId || !isset($bspaybrStatusId)) {
                    write_log_webhook("ERRO PAYMENT: Dados essenciais ausentes (external_id ou statusCode).", 'ERROR');
                    throw new Exception("Dados essenciais ausentes para PAYMENT.");
                }

                $saque = null;
                $searchMethod = '';

                // ESTRATÉGIA 1: Buscar por bspaybr_payment_id (MAIS CONFIÁVEL)
                if ($bspaybrExternalId) {
                    write_log_webhook("Estratégia 1: Buscando por bspaybr_payment_id = '$bspaybrExternalId'", 'DEBUG');
                    $sql = "SELECT id, status, usuario_id, valor_retirada FROM transacoes_retirada WHERE bspaybr_payment_id = ? FOR UPDATE";
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("s", $bspaybrExternalId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $saque = $result->fetch_assoc();
                        $stmt->close();
                        
                        if ($saque) {
                            $searchMethod = "bspaybr_payment_id";
                            write_log_webhook("SUCCESS: Encontrado por bspaybr_payment_id! ID: {$saque['id']}", 'INFO');
                        } else {
                            write_log_webhook("INFO: Não encontrado por bspaybr_payment_id", 'DEBUG');
                        }
                    }
                }
                
                // ESTRATÉGIA 2: Buscar por external_id
                if (!$saque && $bspaybrExternalId) {
                    write_log_webhook("Estratégia 2: Buscando por external_id = '$bspaybrExternalId'", 'DEBUG');
                    $sql = "SELECT id, status, usuario_id, valor_retirada FROM transacoes_retirada WHERE external_id = ? FOR UPDATE";
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("s", $bspaybrExternalId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $saque = $result->fetch_assoc();
                        $stmt->close();
                        
                        if ($saque) {
                            $searchMethod = "external_id";
                            write_log_webhook("SUCCESS: Encontrado por external_id! ID: {$saque['id']}", 'INFO');
                        } else {
                            write_log_webhook("INFO: Não encontrado por external_id", 'DEBUG');
                        }
                    }
                }
                
                // ESTRATÉGIA 3: Buscar por transactionId
                if (!$saque && $bspaybrTransactionId) {
                    write_log_webhook("Estratégia 3: Buscando por bspaybr_payment_id = '$bspaybrTransactionId'", 'DEBUG');
                    $sql = "SELECT id, status, usuario_id, valor_retirada FROM transacoes_retirada WHERE bspaybr_payment_id = ? FOR UPDATE";
                    $stmt = $conn->prepare($sql);
                    if ($stmt) {
                        $stmt->bind_param("s", $bspaybrTransactionId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        $saque = $result->fetch_assoc();
                        $stmt->close();
                        
                        if ($saque) {
                            $searchMethod = "bspaybr_payment_id (transactionId)";
                            write_log_webhook("SUCCESS: Encontrado por transactionId! ID: {$saque['id']}", 'INFO');
                        } else {
                            write_log_webhook("INFO: Não encontrado por transactionId", 'DEBUG');
                        }
                    }
                }
                
                // ESTRATÉGIA 4: Buscar transação mais recente em processamento (EMERGÊNCIA)
                if (!$saque) {
                    write_log_webhook("Estratégia 4: Buscando transação mais recente em 'processando_bspaybr'", 'DEBUG');
                    $sql = "SELECT id, status, usuario_id, valor_retirada FROM transacoes_retirada WHERE status = 'processando_bspaybr' ORDER BY id DESC LIMIT 1";
                    $result = $conn->query($sql);
                    
                    if ($result && $result->num_rows > 0) {
                        $saque = $result->fetch_assoc();
                        $searchMethod = "mais_recente_em_processamento";
                        write_log_webhook("WARNING: Usando transação mais recente em processamento! ID: {$saque['id']}", 'WARNING');
                    } else {
                        write_log_webhook("INFO: Nenhuma transação em processamento encontrada", 'DEBUG');
                    }
                }
                
                if ($saque) {
                    $saqueId = $saque['id'];
                    $currentStatus = $saque['status'];
                    $usuarioId = $saque['usuario_id'];
                    $valorRetirada = $saque['valor_retirada'];
                    
                    write_log_webhook("Processando saque: ID={$saqueId}, Status={$currentStatus}, Método={$searchMethod}", 'INFO');

                    if ($bspaybrStatusId == 1) { // 1 = Transferência concluída com sucesso
                        $newStatus = 'pago';
                        $updateSql = "UPDATE transacoes_retirada SET status = ?, data_confirmacao = NOW() WHERE id = ?";
                        $updateStmt = $conn->prepare($updateSql);
                        if ($updateStmt) {
                            $updateStmt->bind_param("si", $newStatus, $saqueId);
                            $updateStmt->execute();
                            $updateStmt->close();
                            write_log_webhook("🎉 SUCCESS: Saque ID {$saqueId} marcado como 'pago'! Método de busca: {$searchMethod}", 'INFO');
                        } else {
                            write_log_webhook("ERRO: Falha ao preparar UPDATE para marcar como pago: " . $conn->error, 'ERROR');
                        }
                    } else {
                         // Trata outros status (falha, etc.)
                        $newStatus = 'cancelada';
                        $updateSql = "UPDATE transacoes_retirada SET status = ?, data_cancelamento = NOW() WHERE id = ?";
                        $updateStmt = $conn->prepare($updateSql);
                        if ($updateStmt) {
                            $updateStmt->bind_param("si", $newStatus, $saqueId);
                            $updateStmt->execute();
                            $updateStmt->close();
                            
                            // IMPLEMENTAR ESTORNO DE SALDO
                            if ($usuarioId && $valorRetirada) {
                                $sqlEstorno = "UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?";
                                $stmtEstorno = $conn->prepare($sqlEstorno);
                                if ($stmtEstorno) {
                                    $stmtEstorno->bind_param("di", $valorRetirada, $usuarioId);
                                    $stmtEstorno->execute();
                                    $stmtEstorno->close();
                                    write_log_webhook("INFO: Saldo de R$ {$valorRetirada} estornado para usuário ID {$usuarioId}", 'INFO');
                                } else {
                                    write_log_webhook("ERRO: Falha ao estornar saldo: " . $conn->error, 'ERROR');
                                }
                            }
                            
                            write_log_webhook("WARNING: Saque ID {$saqueId} falhou: {$bspaybrStatusDesc}. Status: 'cancelada', saldo estornado.", 'WARNING');
                        } else {
                            write_log_webhook("ERRO: Falha ao preparar UPDATE para cancelar: " . $conn->error, 'ERROR');
                        }
                    }
                } else {
                    write_log_webhook("❌ ERRO CRÍTICO: Transação não encontrada com nenhum método!", 'ERROR');
                    write_log_webhook("Dados procurados:", 'ERROR');
                    write_log_webhook("- external_id: '$bspaybrExternalId'", 'ERROR');
                    write_log_webhook("- transactionId: '$bspaybrTransactionId'", 'ERROR');
                    write_log_webhook("Verifique a tabela 'transacoes_retirada' no banco de dados", 'ERROR');
                    
                    // Log de debug - mostrar transações em processamento
                    $debugSql = "SELECT id, external_id, bspaybr_payment_id, status FROM transacoes_retirada WHERE status = 'processando_bspaybr' ORDER BY id DESC LIMIT 5";
                    $debugResult = $conn->query($debugSql);
                    if ($debugResult && $debugResult->num_rows > 0) {
                        write_log_webhook("DEBUG: Transações em processamento encontradas:", 'DEBUG');
                        while ($debugRow = $debugResult->fetch_assoc()) {
                            write_log_webhook("- ID: {$debugRow['id']}, external_id: '{$debugRow['external_id']}', bspaybr_payment_id: '{$debugRow['bspaybr_payment_id']}'", 'DEBUG');
                        }
                    } else {
                        write_log_webhook("DEBUG: Nenhuma transação em 'processando_bspaybr' encontrada", 'DEBUG');
                    }
                }
                break;
                
            default:
                write_log_webhook("WARNING: Tipo de transação desconhecido: '$transactionType'. Payload: " . print_r($webhookData, true), 'WARNING');
                break;
        }

        $conn->commit();
        write_log_webhook("✅ Webhook processado com sucesso! Transação DB commitada.", 'INFO');
        http_response_code(200);
        echo "OK";
        
    } catch (Exception $e) {
        $conn->rollback();
        write_log_webhook("❌ ERRO FATAL no webhook: " . $e->getMessage(), 'ERROR');
        write_log_webhook("Stack trace: " . $e->getTraceAsString(), 'ERROR');
        http_response_code(500);
        echo "Erro: " . $e->getMessage();
    }
} else {
    write_log_webhook("ERRO: Método HTTP inválido: {$_SERVER['REQUEST_METHOD']}. Esperado: POST", 'ERROR');
    http_response_code(405);
    echo "Método não permitido";
}

if (isset($conn)) {
    $conn->close();
}

write_log_webhook("=== FIM DO PROCESSAMENTO DO WEBHOOK ===", 'DEBUG');
?>