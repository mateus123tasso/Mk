<?php
session_start();
include('servidor/atualizar_rendimento.php');
include('servidor/infor.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php';

// Fetch user balance information
$saldo_retirada = usuario($_SESSION['user_id'], 'saldo_retirada');
$saldo_recarga = usuario($_SESSION['user_id'], 'saldo_recarga');
$totalInvestido = usuario($_SESSION['user_id'], 'total_investido');

// Ensure balances are not null and format for display
$saldo_retirada = number_format($saldo_retirada ?? 0, 2, ',', '.');
$saldo_recarga = number_format($saldo_recarga ?? 0, 2, ',', '.');

// Generate invitation link (not used directly on this page but kept for context)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$codigoConvite = usuario($_SESSION['user_id'], 'codigo_convite');
$newUrl = $protocol . $_SERVER['HTTP_HOST'] . '/register?invitationCode=' . urlencode($codigoConvite);

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Meu Perfil</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&family=Orbitron:wght@400;500;700;900&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="mytabbar.css">
    
    <style>
        /* Reset e configurações básicas */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #fff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        /* Efeitos de fundo futuristas */
        .cyber-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 30px 30px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(30px, 30px); }
        }

        .floating-particles {
            position: fixed;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: radial-gradient(circle, rgba(255,215,0,0.8), transparent);
            border-radius: 50%;
            animation: floatParticle linear infinite;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(-50px);
                opacity: 0;
            }
        }

        /* Loading Spinner Sofisticado */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.8s ease, visibility 0.8s ease;
        }

        .loading-overlay.hidden {
            opacity: 0;
            visibility: hidden;
        }

        .futuristic-spinner {
            position: relative;
            width: 120px;
            height: 120px;
        }

        .spinner-ring {
            position: absolute;
            border: 2px solid transparent;
            border-radius: 50%;
            animation: spinRotate 2s linear infinite;
        }

        .spinner-ring:nth-child(1) {
            width: 120px;
            height: 120px;
            border-top: 2px solid #FFD700;
            border-right: 2px solid #FFD700;
            animation-duration: 1.5s;
        }

        .spinner-ring:nth-child(2) {
            width: 90px;
            height: 90px;
            border-bottom: 2px solid #FFA500;
            border-left: 2px solid #FFA500;
            top: 15px;
            left: 15px;
            animation-direction: reverse;
            animation-duration: 2s;
        }

        .spinner-ring:nth-child(3) {
            width: 60px;
            height: 60px;
            border-top: 2px solid #17706E;
            border-right: 2px solid #17706E;
            top: 30px;
            left: 30px;
            animation-duration: 1.2s;
        }

        .spinner-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #FFD700, #FFA500);
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes spinRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
            50% { transform: translate(-50%, -50%) scale(1.5); opacity: 0.7; }
        }

        /* Container Principal */
        .main-container {
            position: relative;
            z-index: 10;
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            min-height: 100vh;
            padding-bottom: 120px;
        }

        /* Header Futurista */
        .cyber-header {
            position: relative;
            padding: 70px 20px 30px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.1) 0%,
                rgba(255,255,255,0.05) 50%,
                rgba(255,255,255,0.1) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,215,0,0.3);
            margin-bottom: 30px;
            text-align: center;
        }

        .cyber-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            animation: scanLine 3s ease-in-out infinite;
        }

        @keyframes scanLine {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        .profile-avatar {
            position: relative;
            display: inline-block;
            margin-bottom: 20px;
        }

        .avatar-container {
            position: relative;
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            border: 3px solid rgba(255,215,0,0.5);
            background: linear-gradient(45deg, #FFD700, #FFA500);
            padding: 3px;
            animation: avatarGlow 2s ease-in-out infinite alternate;
        }

        @keyframes avatarGlow {
            0% { box-shadow: 0 0 20px rgba(255,215,0,0.3); }
            100% { box-shadow: 0 0 40px rgba(255,215,0,0.6); }
        }

        .avatar-img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-name {
            font-family: 'Orbitron', monospace;
            font-size: 24px;
            font-weight: 700;
            color: #fff;
            text-shadow: 0 0 20px rgba(255,215,0,0.5);
            margin-bottom: 10px;
        }

        .profile-status {
            font-size: 14px;
            color: rgba(255,255,255,0.7);
            padding: 5px 15px;
            background: rgba(0,0,0,0.3);
            border-radius: 20px;
            display: inline-block;
        }

        /* Menu Hambúrguer Futurista */
        .cyber-menu-toggle {
            position: fixed;
            left: 20px;
            top: 30px;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            border: 1px solid rgba(255,215,0,0.3);
            z-index: 30;
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
        }

        .cyber-menu-toggle:hover {
            transform: scale(1.1);
            border-color: rgba(255,215,0,0.6);
            box-shadow: 0 0 20px rgba(255,215,0,0.3);
        }

        .menu-bar {
            width: 25px;
            height: 3px;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            margin: 3px 0;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .cyber-menu-toggle.active .menu-bar:nth-child(1) {
            transform: rotate(45deg) translate(6px, 6px);
        }

        .cyber-menu-toggle.active .menu-bar:nth-child(2) {
            opacity: 0;
        }

        .cyber-menu-toggle.active .menu-bar:nth-child(3) {
            transform: rotate(-45deg) translate(6px, -6px);
        }

        /* Side Menu Futurista */
        .cyber-side-menu {
            position: fixed;
            top: 0;
            left: -300px;
            width: 280px;
            height: 100vh;
            background: linear-gradient(135deg, #0A4A3C 0%, #17706E 100%);
            backdrop-filter: blur(20px);
            box-shadow: 5px 0 25px rgba(0,0,0,0.5);
            z-index: 25;
            transition: left 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            padding-top: 100px;
            border-right: 1px solid rgba(255,215,0,0.3);
        }

        .cyber-side-menu.open {
            left: 0;
        }

        .cyber-side-menu::before {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 2px;
            height: 100%;
            background: linear-gradient(180deg, transparent, #FFD700, transparent);
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 18px 25px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            position: relative;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }

        .menu-item:hover {
            color: #FFD700;
            background: rgba(255,215,0,0.1);
            border-left-color: #FFD700;
            transform: translateX(10px);
        }

        .menu-item::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            width: 0;
            height: 100%;
            background: linear-gradient(90deg, rgba(255,215,0,0.2), transparent);
            transition: width 0.3s ease;
        }

        .menu-item:hover::before {
            width: 100%;
        }

        .menu-item img {
            width: 24px;
            height: 24px;
            margin-right: 15px;
            filter: brightness(1.2) drop-shadow(0 0 5px rgba(255,215,0,0.3));
            transition: all 0.3s ease;
        }

        .menu-item:hover img {
            filter: brightness(1.5) drop-shadow(0 0 10px rgba(255,215,0,0.6));
            transform: scale(1.1);
        }

        .menu-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(5px);
            z-index: 24;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .menu-overlay.open {
            opacity: 1;
            visibility: visible;
        }

        /* Cards Futuristas */
        .cyber-card {
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.08) 0%,
                rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            border: 1px solid rgba(255,215,0,0.15);
            margin: 0 20px 15px;
            padding: 25px;
            position: relative;
            overflow: hidden;
            animation: slideInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        .cyber-card:nth-child(2) { animation-delay: 0.2s; }
        .cyber-card:nth-child(3) { animation-delay: 0.4s; }
        .cyber-card:nth-child(4) { animation-delay: 0.6s; }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .cyber-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.1);
        }

        /* Balance Card */
        .balance-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 15px;
        }

        .balance-item {
            text-align: center;
            padding: 15px;
            background: rgba(0,0,0,0.2);
            border-radius: 15px;
            border: 1px solid rgba(255,215,0,0.1);
        }

        .balance-label {
            font-size: 12px;
            color: rgba(255,255,255,0.7);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }

        .balance-amount {
            font-family: 'Orbitron', monospace;
            font-size: 22px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
        }

        .billing-link {
            text-align: center;
            padding: 12px;
            background: rgba(255,215,0,0.08);
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,215,0,0.15);
        }

        .billing-link:hover {
            background: rgba(255,215,0,0.12);
            transform: translateY(-2px);
        }

        .billing-link span {
            color: rgba(255,255,255,0.9);
            font-size: 14px;
        }

        /* Action Cards */
        .action-card {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            padding: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, rgba(255,215,0,0.08), rgba(255,165,0,0.04));
            border: 1px solid rgba(255,215,0,0.15);
        }

        .action-card:hover {
            background: linear-gradient(135deg, rgba(255,215,0,0.12), rgba(255,165,0,0.08));
            transform: translateY(-2px);
        }

        .action-icon {
            width: 40px;
            height: 40px;
            filter: brightness(1.2) drop-shadow(0 0 10px rgba(255,215,0,0.3));
        }

        .action-text {
            font-size: 18px;
            font-weight: 600;
            color: #FFD700;
            text-shadow: 0 0 10px rgba(255,215,0,0.3);
        }

        /* Products Section */
        .products-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .products-title {
            font-family: 'Orbitron', monospace;
            font-size: 24px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
            margin-bottom: 10px;
        }

        .products-subtitle {
            color: rgba(255,255,255,0.7);
            font-size: 14px;
            line-height: 1.6;
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .main-container {
                padding-bottom: 140px;
            }
            
            .cyber-header {
                padding: 60px 15px 25px;
            }
            
            .avatar-container {
                width: 70px;
                height: 70px;
            }
            
            .profile-name {
                font-size: 20px;
            }
            
            .cyber-menu-toggle {
                left: 15px;
                top: 25px;
                width: 45px;
                height: 45px;
            }
            
            .cyber-card {
                margin: 0 15px 15px;
                padding: 20px;
            }
            
            .balance-grid {
                gap: 15px;
            }
            
            .balance-amount {
                font-size: 18px;
            }
            
            .action-text {
                font-size: 16px;
            }
            
            .products-title {
                font-size: 20px;
            }
        }

        @media (max-width: 480px) {
            .balance-grid {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            
            .cyber-side-menu {
                width: 250px;
            }
            
            .menu-item {
                padding: 15px 20px;
                font-size: 15px;
            }
        }

        /* Micro animações */
        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
        }

        .glitch-effect:hover {
            animation: glitch 0.3s;
        }
    </style>
</head>

<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="futuristic-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-center"></div>
        </div>
    </div>

    <!-- Background Effects -->
    <div class="cyber-grid"></div>
    <div class="floating-particles" id="particles"></div>

    <!-- Menu Toggle -->
    <div class="cyber-menu-toggle" id="menuToggle">
        <div class="menu-bar"></div>
        <div class="menu-bar"></div>
        <div class="menu-bar"></div>
    </div>

    <!-- Side Menu -->
    <div class="cyber-side-menu" id="sideMenu">
        <a href="/index" class="menu-item">
            <img src="static/yunta/tabbar/home_1.png" alt="Lar"> Lar
        </a>
        <a href="/recharge" class="menu-item">
            <img src="static/yunta/mine/Recharge.png" alt="Recarregar"> Recarregar
        </a>
        <a href="/withdraw" class="menu-item">
            <img src="static/yunta/mine/Withdraw.png" alt="Retirar"> Retirar
        </a>
        <a href="/account" class="menu-item">
            <img src="static/yunta/mine/Account.png" alt="Conta"> Conta
        </a>
        <a href="/pwd" class="menu-item">
            <img src="static/yunta/mine/psd.png" alt="Senha"> Senha
        </a>
        <a href="servidor/logout" class="menu-item">
            <img src="static/yunta/mine/logout.png" alt="Sair"> Sair
        </a>
    </div>

    <div class="menu-overlay" id="menuOverlay"></div>

    <!-- Main Container -->
    <div class="main-container" id="mainContent" style="opacity: 0;">
        <!-- Profile Header -->
        <div class="cyber-header">
            <div class="profile-avatar">
                <div class="avatar-container">
                    <img src="/logo/avatar.png" alt="User Avatar" class="avatar-img">
                </div>
            </div>
            <div class="profile-name glitch-effect"><?php echo htmlspecialchars(usuario($_SESSION['user_id'], 'username')); ?></div>
            <div class="profile-status">Status: Ativo • Investidor Premium</div>
        </div>

        <!-- Balance Card -->
        <div class="cyber-card holographic">
            <div class="balance-grid">
                <div class="balance-item">
                    <div class="balance-label">Saldo Recarga</div>
                    <div class="balance-amount">R$<?php echo $saldo_recarga; ?></div>
                </div>
                <div class="balance-item">
                    <div class="balance-label">Saldo para Sacar</div>
                    <div class="balance-amount">R$<?php echo $saldo_retirada; ?></div>
                </div>
            </div>
            <div class="billing-link" onclick="window.location.href='/history'">
                <span>📊 Ver detalhes de faturamento completo</span>
            </div>
        </div>

        <!-- Recharge Action Card -->
        <div class="cyber-card action-card" onclick="window.location.href='/recharge'">
            <img src="static/yunta/mine/Recharge.png" alt="Recarregar" class="action-icon">
            <span class="action-text">Recarregar Saldo</span>
        </div>
        
        <!-- My Products Card -->
        <div class="cyber-card">
            <div class="products-header">
                <div class="products-title">Meus Produtos</div>
                <div class="products-subtitle">
                    🚀 Seus investimentos e produtos ativos aparecerão aqui
                    <br>
                    💎 Acompanhe rentabilidade, ciclos e retornos em tempo real
                    <br>
                    ⚡ Dashboard completo de performance disponível em breve
                </div>
            </div>
        </div>
    </div>

    <div class="tabbar">
        <div class="tabbar-nav">
            <a href="/" class="tab-item" data-page="home">
                <svg class="tab-icon" viewBox="0 0 24 24">
                    <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
                </svg>
                <div class="tab-text">Início</div>
            </a>
            <a href="/team" class="tab-item" data-page="team">
                <svg class="tab-icon" viewBox="0 0 24 24">
                    <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-4 0c1.66 0 2.99-1.34 2.99-3S13.66 5 12 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-4 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm8 4c-2.33 0-7 1.17-7 3.5V19h14v-1.5c0-2.33-4.67-3.5-7-3.5z"/>
                </svg>
                <div class="tab-text">Equipe</div>
            </a>
            <a href="/record" class="tab-item" data-page="record">
                <svg class="tab-icon" viewBox="0 0 24 24">
                    <path d="M13 3c-4.97 0-9 4.03-9 9H1l3.05 3.05c.29.29.76.29 1.05 0L8 12H5c0-3.86 3.14-7 7-7s7 3.14 7 7-3.14 7-7 7c-1.93 0-3.68-.79-4.95-2.05-.29-.29-.76-.29-1.05 0C7.81 20.35 9.8 21 12 21c4.97 0 9-4.03 9-9s-4.03-9-9-9z"/>
                </svg>
                <div class="tab-text">Registro</div>
            </a>
            <a href="/my" class="tab-item tab-active" data-page="my">
                <svg class="tab-icon" viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
                <div class="tab-text">Meu</div>
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Loading Animation
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('loadingOverlay').classList.add('hidden');
                document.getElementById('mainContent').style.opacity = '1';
                document.getElementById('mainContent').style.transition = 'opacity 1s ease';
            }, 1200);
        });

        // Create floating particles
        function createParticles() {
            const particleContainer = document.getElementById('particles');
            const particleCount = 12;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 8 + 4) + 's';
                particle.style.animationDelay = Math.random() * 4 + 's';
                particleContainer.appendChild(particle);
            }
        }

        createParticles();

        // Menu functionality
        const menuToggle = document.getElementById('menuToggle');
        const sideMenu = document.getElementById('sideMenu');
        const menuOverlay = document.getElementById('menuOverlay');

        function toggleMenu() {
            menuToggle.classList.toggle('active');
            sideMenu.classList.toggle('open');
            menuOverlay.classList.toggle('open');
        }

        menuToggle.addEventListener('click', toggleMenu);
        menuOverlay.addEventListener('click', toggleMenu);

        // Add loading states to navigation links
        const actionCards = document.querySelectorAll('.action-card, .billing-link');
        actionCards.forEach(card => {
            card.addEventListener('click', function(e) {
                if (this.onclick) {
                    const originalContent = this.innerHTML;
                    this.style.opacity = '0.7';
                    this.style.pointerEvents = 'none';
                    
                    setTimeout(() => {
                        this.style.opacity = '1';
                        this.style.pointerEvents = 'auto';
                    }, 1000);
                }
            });
        });

        // Enhanced hover effects
        const cyberCards = document.querySelectorAll('.cyber-card');
        cyberCards.forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
    </script>
</body>
</html>