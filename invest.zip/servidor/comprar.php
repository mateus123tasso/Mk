<?php

// Habilita o log de erros para ajudar na depuração
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php-error.log');

session_start();

require 'database.php';

date_default_timezone_set('America/Fortaleza');

if (!isset($_SESSION['user_id'])) {
    die("Usuário não logado.");
}

if (!isset($_POST['id'])) {
    die("Dados incompletos.");
}

$usuarioId = $_SESSION['user_id'];
$planoId = intval($_POST['id']);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Inicia uma transação para garantir que todas as operações sejam atômicas
    $pdo->beginTransaction();

    // 1. Obtém dados do usuário e do plano
    // Usamos FOR UPDATE para bloquear a linha do usuário durante a transação
    $stmtUser = $pdo->prepare("SELECT saldo_recarga, saldo_retirada, total_investido, id_patrocinador FROM usuarios WHERE id = ? FOR UPDATE");
    $stmtUser->execute([$usuarioId]);
    $usuario = $stmtUser->fetch(PDO::FETCH_ASSOC);

    $stmtPlano = $pdo->prepare("SELECT preco, diasDeReceita, nome, limite, vip FROM planos WHERE id = ?");
    $stmtPlano->execute([$planoId]);
    $plano = $stmtPlano->fetch(PDO::FETCH_ASSOC);

    if (!$usuario || !$plano) {
        $pdo->rollBack();
        die("Usuário ou plano não encontrado.");
    }
    
    // 2. Verifica se o VIP do usuário é compatível
    $totalInvestido = $usuario['total_investido'];
    $nivelVIP = 0;
    $stmtVIP = $pdo->prepare("SELECT nivel FROM niveis_vip WHERE investimento_minimo <= ? ORDER BY investimento_minimo DESC LIMIT 1");
    $stmtVIP->execute([$totalInvestido]);
    $nivelVIP = $stmtVIP->fetchColumn() ?? 0;
    
    if ($plano['vip'] > $nivelVIP) {
        $pdo->rollBack();
        die("Você não possui VIP compatível para comprar este plano.");
    }

    // 3. Verifica o limite de compras do plano
    $stmtCompras = $pdo->prepare("SELECT COUNT(*) AS totalCompras FROM compras WHERE usuario_id = ? AND plano_id = ?");
    $stmtCompras->execute([$usuarioId, $planoId]);
    $comprasExistentes = $stmtCompras->fetchColumn();

    if ($comprasExistentes >= $plano['limite']) {
        $pdo->rollBack();
        die("Limite de compras atingido.");
    }

    // 4. Lógica de dedução do saldo (primeiro de recarga, depois de retirada)
    $preco = $plano['preco'];
    $saldoRecarga = $usuario['saldo_recarga'];
    $saldoRetirada = $usuario['saldo_retirada'];

    if (($saldoRecarga + $saldoRetirada) < $preco) {
        $pdo->rollBack();
        die("Saldo insuficiente");
    }

    if ($saldoRecarga >= $preco) {
        $novoSaldoRecarga = $saldoRecarga - $preco;
        $novoSaldoRetirada = $saldoRetirada;
    } else {
        $precoRestante = $preco - $saldoRecarga;
        $novoSaldoRecarga = 0;
        $novoSaldoRetirada = $saldoRetirada - $precoRestante;
    }
    
    // 5. Atualiza o saldo e o total investido do usuário
    $novoTotalInvestido = $usuario['total_investido'] + $preco;
    $stmtUpdateUser = $pdo->prepare("UPDATE usuarios SET saldo_recarga = ?, saldo_retirada = ?, total_investido = ? WHERE id = ?");
    $stmtUpdateUser->execute([$novoSaldoRecarga, $novoSaldoRetirada, $novoTotalInvestido, $usuarioId]);

    // 6. Calcula as datas e horários da compra
    $dataCompra = new DateTime();
    $diasDeReceita = (float) $plano['diasDeReceita'];
    
    $vencimento = (clone $dataCompra)->modify('+' . ($diasDeReceita) . ' days');
    
    // O próximo rendimento é 24 horas após a compra
    $proximoRendimento = (clone $dataCompra)->modify('+1 day');

    // 7. Insere a nova compra no banco de dados
    $stmtInsertCompra = $pdo->prepare("
        INSERT INTO compras 
        (usuario_id, plano_id, data_compra, vencimento, status, proximo_rendimento) 
        VALUES (:usuario_id, :plano_id, :data_compra, :vencimento, 'rodando', :proximo_rendimento)
    ");
    $stmtInsertCompra->execute([
        ':usuario_id' => $usuarioId,
        ':plano_id' => $planoId,
        ':data_compra' => $dataCompra->format('Y-m-d H:i:s'),
        ':vencimento' => $vencimento->format('Y-m-d H:i:s'),
        ':proximo_rendimento' => $proximoRendimento->format('Y-m-d H:i:s')
    ]);

    // 8. Processa comissões de indicação (se existirem)
    $stmtConfig = $pdo->query("SELECT lv1, lv2, lv3 FROM configuracoes LIMIT 1");
    $configuracoes = $stmtConfig->fetch(PDO::FETCH_ASSOC);

    $patrocinadorId = $usuario['id_patrocinador'];
    $valorPlano = $plano['preco'];

    // Comissão Nível 1
    if ($patrocinadorId) {
        $comissaoLv1 = $valorPlano * $configuracoes['lv1'] / 100;
        $stmtUpdatePatrocinador = $pdo->prepare("UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?");
        $stmtUpdatePatrocinador->execute([$comissaoLv1, $patrocinadorId]);
        
        $stmtInsertTransacao = $pdo->prepare("INSERT INTO transacoes (usuario_id, tipo, valor, descricao) VALUES (?, 'comissao', ?, 'Comissão Nível 1 da compra do plano {$plano['nome']}')");
        $stmtInsertTransacao->execute([$patrocinadorId, $comissaoLv1]);

        // Comissão Nível 2
        $stmtPatrocinadorLv2 = $pdo->prepare("SELECT id_patrocinador FROM usuarios WHERE id = ?");
        $stmtPatrocinadorLv2->execute([$patrocinadorId]);
        $patrocinadorLv2 = $stmtPatrocinadorLv2->fetchColumn();

        if ($patrocinadorLv2) {
            $comissaoLv2 = $valorPlano * $configuracoes['lv2'] / 100;
            $stmtUpdatePatrocinador = $pdo->prepare("UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?");
            $stmtUpdatePatrocinador->execute([$comissaoLv2, $patrocinadorLv2]);
            
            $stmtInsertTransacao = $pdo->prepare("INSERT INTO transacoes (usuario_id, tipo, valor, descricao) VALUES (?, 'comissao', ?, 'Comissão Nível 2 da compra do plano {$plano['nome']}')");
            $stmtInsertTransacao->execute([$patrocinadorLv2, $comissaoLv2]);

            // Comissão Nível 3
            $stmtPatrocinadorLv3 = $pdo->prepare("SELECT id_patrocinador FROM usuarios WHERE id = ?");
            $stmtPatrocinadorLv3->execute([$patrocinadorLv2]);
            $patrocinadorLv3 = $stmtPatrocinadorLv3->fetchColumn();

            if ($patrocinadorLv3) {
                $comissaoLv3 = $valorPlano * $configuracoes['lv3'] / 100;
                $stmtUpdatePatrocinador = $pdo->prepare("UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?");
                $stmtUpdatePatrocinador->execute([$comissaoLv3, $patrocinadorLv3]);
                
                $stmtInsertTransacao = $pdo->prepare("INSERT INTO transacoes (usuario_id, tipo, valor, descricao) VALUES (?, 'comissao', ?, 'Comissão Nível 3 da compra do plano {$plano['nome']}')");
                $stmtInsertTransacao->execute([$patrocinadorLv3, $comissaoLv3]);
            }
        }
    }

    // 9. Confirma todas as operações
    $pdo->commit();

    echo "sucesso!";

} catch (PDOException $e) {
    // Reverte todas as operações em caso de erro
    $pdo->rollBack();
    error_log("Erro no script de compra: " . $e->getMessage());
    die("Ocorreu um erro interno. Tente novamente mais tarde.");
}
?>