<?php
// public_html/servidor/login.php

require_once 'database.php'; // Inclui o arquivo de conexão com o banco de dados
session_start(); // Inicia a sessão PHP

// Verifica se a requisição é POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados de 'mobile' (que será o username na sua tabela) e 'password' do POST.
    // O campo 'mobile' do frontend agora corresponde ao 'username' no banco de dados.
    $username_input = $_POST['mobile'] ?? ''; // O input 'mobile' do frontend é o 'username'
    $password_input = $_POST['password'] ?? '';

    // Validação básica: verifica se os campos não estão vazios.
    if (empty($username_input) || empty($password_input)) {
        echo "Por favor, preencha todos os campos.";
        exit(); // Encerra o script
    }

    try {
        // Prepara a consulta SQL para buscar o usuário pelo 'username' (que é o 'mobile' do frontend).
        // A tabela é 'usuarios' e a coluna de login é 'username'.
        $stmt = $pdo->prepare("SELECT id, username, password, saldo_recarga, saldo_retirada FROM usuarios WHERE username = :username");
        $stmt->bindParam(':username', $username_input); // Liga o valor do input 'mobile' ao placeholder :username
        $stmt->execute();

        $user = $stmt->fetch(); // Obtém a linha do usuário (se encontrada)

        // Verifica se o usuário existe e a senha está correta
        if ($user) {
            // Usa password_verify() para verificar a senha hasheada
            if (password_verify($password_input, $user['password'])) {
                // Login bem-sucedido!
                // Armazena informações importantes do usuário na sessão.
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username']; // Armazena o username
                $_SESSION['saldo_recarga'] = $user['saldo_recarga']; // Salva o saldo de recarga
                $_SESSION['saldo_retirada'] = $user['saldo_retirada']; // Salva o saldo de retirada
                // Você pode adicionar mais dados do usuário na sessão conforme necessário

                echo "Login bem-sucedido!"; // Resposta para o frontend
            } else {
                // Senha incorreta
                echo "Credenciais inválidas. Verifique seu usuário e senha.";
            }
        } else {
            // Usuário não encontrado
            echo "Credenciais inválidas. Verifique seu usuário e senha.";
        }

    } catch (PDOException $e) {
        // Em caso de erro no banco de dados durante a consulta.
        // Em produção, use error_log() e dê uma mensagem genérica por segurança.
        error_log("Erro no login (servidor/login.php): " . $e->getMessage());
        echo "Ocorreu um erro interno do servidor. Por favor, tente novamente mais tarde.";
        // Para depuração, você pode descomentar a linha abaixo, mas REMOVA EM PRODUÇÃO!
        // echo "Detalhes do erro: " . $e->getMessage();
    }
} else {
    // Se a requisição não for POST
    echo "Método de requisição inválido.";
}
?>