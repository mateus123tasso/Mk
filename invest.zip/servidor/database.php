<?php

$host = '127.0.0.1';
$dbname = 'u700037883_x';
$username_db = 'u700037883_x';
$password_db = 'Resident4567';

// --- Configurações do Webhook ---
// AJUSTE SEU_DOMINIO.COM para o seu domínio real
define('SITE_DOMAIN', 'raspwin.com');

// O webhook UNIFICADO agora tem um único caminho para depósitos e saques
define('BSPAYBR_WEBHOOK_URL', 'https://' . SITE_DOMAIN . '/webhook_bspaybr.php');


date_default_timezone_set('America/Fortaleza');

$conn = new mysqli($host, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username_db, $password_db, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch (PDOException $e) {
    die("Erro na conexão PDO: " . $e->getMessage());
}

?>