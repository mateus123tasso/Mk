<?php
session_start();
date_default_timezone_set('America/Fortaleza');

// --- Configuração do Arquivo de Log ---
define('SAQUE_LOG_FILE', __DIR__ . '/../logs/saque_debug.log');

function write_saque_log($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(SAQUE_LOG_FILE, $log_entry, FILE_APPEND);
}
// --- Fim da Configuração do Log ---

header('Content-Type: application/json');

function returnError($message, $httpCode = 400) {
    write_saque_log("ERRO (HTTP {$httpCode}): {$message}", 'ERROR');
    http_response_code($httpCode);
    echo json_encode(['success' => false, 'message' => $message]);
    exit();
}

function returnSuccess($message, $data = []) {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit();
}

write_saque_log("Início da requisição de retirada (NOVA LÓGICA).", 'DEBUG');

if (!isset($_SESSION['user_id'])) {
    returnError("Usuário não autenticado. Por favor, faça login.", 401);
}

$usuario_id = $_SESSION['user_id'];
require 'database.php';

if (!isset($pdo) || !($pdo instanceof PDO)) {
    returnError("Erro interno do servidor: Não foi possível conectar ao banco de dados.", 500);
}

// --- Obter Dados do Usuário ---
try {
    $stmt_user = $pdo->prepare("SELECT saldo_retirada, total_sacado_hoje, data_ultimo_saque_diario FROM usuarios WHERE id = ?");
    $stmt_user->execute([$usuario_id]);
    $user_data = $stmt_user->fetch(PDO::FETCH_ASSOC);

    if (!$user_data) {
        returnError("Dados do usuário não encontrados. Por favor, entre em contato com o suporte.", 404);
    }
    $saldo_retirada = $user_data['saldo_retirada'];
    $total_sacado_hoje = $user_data['total_sacado_hoje'];
    $data_ultimo_saque_diario = $user_data['data_ultimo_saque_diario'];

} catch (PDOException $e) {
    write_saque_log("Erro de PDO ao buscar dados do usuário (ID: {$usuario_id}): " . $e->getMessage(), 'CRITICAL');
    returnError("Erro interno ao buscar dados do usuário.", 500);
}

// --- Puxar Configurações de Saque do Banco de Dados ---
try {
    $stmt_config = $pdo->query("SELECT saque_minimo, taxa_saque, saque_diario_max, saque_maximo_por_transacao, permitir_saque_24h FROM configuracoes ORDER BY id ASC LIMIT 1");
    $configuracoes = $stmt_config->fetch(PDO::FETCH_ASSOC);

    if (!$configuracoes) {
        returnError("Configurações de saque não encontradas. Por favor, configure o sistema.", 500);
    }

    $saque_minimo = $configuracoes['saque_minimo'] ?? 0.00;
    $saque_taxa = $configuracoes['taxa_saque'] ?? 0.00;
    $saque_diario_max = $configuracoes['saque_diario_max'] ?? 0.00;
    $saque_maximo_por_transacao = $configuracoes['saque_maximo_por_transacao'] ?? 3000.00;
    $permitir_saque_24h = (bool)($configuracoes['permitir_saque_24h'] ?? false);

} catch (PDOException $e) {
    write_saque_log("Erro de PDO ao buscar configurações de saque: " . $e->getMessage(), 'CRITICAL');
    returnError("Erro interno ao buscar configurações de saque.", 500);
}

// --- Validações de Tempo, Requisição e Valor ---
$dataHoraAtual = new DateTime();
$horaInicio = new DateTime('10:00:00');
$horaFim = new DateTime('17:00:00');
$diaDaSemanaPermitido = ($dataHoraAtual->format('N') >= 1 && $dataHoraAtual->format('N') <= 5);
$horarioPermitido = $permitir_saque_24h || ($dataHoraAtual >= $horaInicio && $dataHoraAtual <= $horaFim && $diaDaSemanaPermitido);

if (!$horarioPermitido) {
    returnError("A retirada está disponível apenas em horários específicos. Verifique as instruções de retirada.");
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['amount'])) {
    returnError("Requisição inválida.");
}

$valor_retirada = filter_var($_POST['amount'], FILTER_VALIDATE_FLOAT);
if ($valor_retirada === false || $valor_retirada <= 0) {
    returnError("Por favor, insira um valor válido e positivo para a retirada.");
}

if ($valor_retirada < $saque_minimo) {
    returnError("O valor mínimo para retirada é de R$" . number_format($saque_minimo, 2, ',', '.') . ".");
}

if ($saque_maximo_por_transacao > 0 && $valor_retirada > $saque_maximo_por_transacao) {
    returnError("O valor máximo permitido por transação é de R$" . number_format($saque_maximo_por_transacao, 2, ',', '.') . ".");
}

$hoje = $dataHoraAtual->format('Y-m-d');
$novo_total_sacado_hoje = ($data_ultimo_saque_diario !== $hoje) ? 0 : $total_sacado_hoje;

if ($saque_diario_max > 0 && ($novo_total_sacado_hoje + $valor_retirada) > $saque_diario_max) {
    returnError("Você atingiu o limite diário de saque de R$" . number_format($saque_diario_max, 2, ',', '.') . ".");
}

// ----------------------------------------------------------------------
// --- NOVA LÓGICA PRINCIPAL AQUI: VALIDAÇÃO E DEDUÇÃO APENAS DO VALOR BRUTO ---
// ----------------------------------------------------------------------

// 1. Validação do saldo do usuário para o valor BRUTO do saque
if ($saldo_retirada < $valor_retirada) {
    write_saque_log("Falha na validação de saldo. Saldo atual: {$saldo_retirada}, Necessário: {$valor_retirada}.", 'WARNING');
    returnError("Saldo insuficiente para a retirada. Seu saldo: R$" . number_format($saldo_retirada, 2, ',', '.') . ".");
}

// Iniciar Transação de Banco de Dados
$pdo->beginTransaction();

try {
    // 2. Atualizar o saldo do usuário, **deduzindo APENAS o valor bruto do saque**
    $novo_saldo = $saldo_retirada - $valor_retirada;
    $update_user_stmt = $pdo->prepare("UPDATE usuarios SET saldo_retirada = ?, total_sacado_hoje = ?, data_ultimo_saque_diario = ? WHERE id = ?");
    $update_user_stmt->execute([$novo_saldo, $novo_total_sacado_hoje + $valor_retirada, $hoje, $usuario_id]);
    write_saque_log("Saldo do usuário atualizado. Novo saldo: {$novo_saldo}.", 'DEBUG');

    // 3. Obter dados da carteira Pix para registro
    $carteira_query = "SELECT chave_pix, cpf, nome_completo FROM carteiras WHERE uid = ?";
    $carteira_stmt = $pdo->prepare($carteira_query);
    $carteira_stmt->execute([$usuario_id]);
    $carteira_info = $carteira_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$carteira_info) {
        $pdo->rollBack();
        returnError("Nenhuma carteira Pix registrada para sua conta.", 400);
    }
    $chave_pix = $carteira_info['chave_pix'];
    $cpf = $carteira_info['cpf'];
    $nome_completo = $carteira_info['nome_completo'];

    // 4. Registrar a transação de retirada com status 'pendente'
    // O valor da taxa e o valor final a receber serão registrados aqui,
    // mas o débito só será feito do lado do administrador.
    $taxa_cobrada = $valor_retirada * ($saque_taxa / 100);
    $valor_a_receber_pelo_usuario = $valor_retirada - $taxa_cobrada;

    $transacao_stmt = $pdo->prepare("INSERT INTO transacoes_retirada (usuario_id, api, valor_retirada, taxa_cobrada, total_recebido, chave_pix, cpf, nome_completo, data_transacao, saldo_anterior, saldo_atual, status)
                                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?, 'pendente')");
    $transacao_stmt->execute([
        $usuario_id,
        'Site/User Request',
        $valor_retirada,
        $taxa_cobrada,
        $valor_a_receber_pelo_usuario,
        $chave_pix,
        $cpf,
        $nome_completo,
        $saldo_retirada, // Saldo antes do débito do valor bruto
        $novo_saldo      // Saldo após o débito do valor bruto
    ]);

    $pdo->commit();
    returnSuccess('Sua solicitação de retirada foi enviada com sucesso! Aguarde a aprovação.');

} catch (PDOException $e) {
    $pdo->rollBack();
    write_saque_log("Erro de PDO durante a transação de retirada (Rollback): " . $e->getMessage(), 'CRITICAL');
    returnError("Erro interno ao processar sua retirada. Por favor, tente novamente mais tarde.", 500);
}