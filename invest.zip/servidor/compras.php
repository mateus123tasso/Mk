<?php
session_start();
require 'database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
    exit();
}

$userId = $_SESSION['user_id'];
date_default_timezone_set('America/Fortaleza');

try {
    $stmt = $pdo->prepare("
        SELECT
            c.id AS compra_id,
            c.usuario_id,
            c.plano_id,
            c.data_compra,
            c.vencimento,
            c.status,
            c.ultima_renda_creditada_at,
            p.nome AS nome_plano,
            p.preco AS valor_investido,
            p.receitaDiaria,
            p.receitaTotal AS renda_total_prevista,
            p.duracao_plano_dias
        FROM
            compras c
        JOIN
            planos p ON c.plano_id = p.id
        WHERE
            c.usuario_id = :user_id
        ORDER BY
            c.data_compra DESC
    ");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $agora = new DateTime();

    foreach ($compras as &$compra) {
        $ultimaRenda = new DateTime($compra['ultima_renda_creditada_at'] ?? $compra['data_compra']);
        $proximaRenda = $ultimaRenda->getTimestamp() + (24 * 60 * 60);

        if ($compra['status'] === 'rodando') {
            $tempoRestanteSegundos = $proximaRenda - $agora->getTimestamp();
            if ($tempoRestanteSegundos < 0) {
                $compra['tempo_restante_segundos'] = 0;
            } else {
                $compra['tempo_restante_segundos'] = $tempoRestanteSegundos;
            }
        } else {
            $compra['tempo_restante_segundos'] = -1; // -1 para indicar que não há contagem
        }
    }

    echo json_encode(['success' => true, 'compras' => $compras]);

} catch (PDOException $e) {
    error_log("Erro ao buscar compras do usuário: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.']);
}
?>