<?php
// ATENÇÃO: Este script executa o processamento de rendimentos
// sem nenhuma proteção por senha. Qualquer pessoa que descobrir
// a URL pode executá-lo. Use com cautela.

// Exibe um cabeçalho simples para indicar o que o script está fazendo.
echo "<h1>Executando Processamento de Rendimentos...</h1>";
echo "<p>Por favor, aguarde. Não feche esta página.</p>";

// Limpa o cache de saída para que as mensagens sejam exibidas
// em tempo real (caso o servidor esteja configurado para isso).
ob_flush();
flush();

// Inclui e executa o script principal de processamento.
require 'processa_rendimentos.php';

// Exibe uma mensagem de sucesso no final.
echo "<h2>Processamento concluído com sucesso!</h2>";
echo "<p>Os saldos e cronômetros foram atualizados.</p>";
?>