<?php
session_start();
require 'database.php'; // Incluindo a configuração do banco de dados

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo "Você não está logado.";
    exit();
}

// Conexão com o banco de dados
$usuarioId = $_SESSION['user_id'];
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Processa a mudança de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['password'];
    $password_confirmation = $_POST['password_confirmation'];

    // Consulta para obter a senha atual do usuário
    $stmt = $pdo->prepare("SELECT password FROM usuarios WHERE id = ?");
    $stmt->execute([$usuarioId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($current_password, $user['password'])) {
        // Verifica se a nova senha e a confirmação são iguais
        if ($new_password === $password_confirmation) {
            // Hash da nova senha
            $passwordHash = password_hash($new_password, PASSWORD_BCRYPT);
            
            // Atualiza a senha no banco de dados
            $updateStmt = $pdo->prepare("UPDATE usuarios SET password = ? WHERE id = ?");
            $updateStmt->execute([$passwordHash, $usuarioId]);

            echo "Senha alterada com sucesso!";
        } else {
            echo "As senhas não coincidem.";
        }
    } else {
        echo "Senha antiga incorreta.";
    }
} else {
    echo "Método de requisição inválido.";
}