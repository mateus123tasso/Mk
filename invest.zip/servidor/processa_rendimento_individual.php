<?php
// /servidor/processa_rendimento_individual.php
session_start();

header('Content-Type: application/json');

// Para ambiente de teste, remova em produção
error_reporting(E_ALL);
ini_set('display_errors', 1);

date_default_timezone_set('America/Fortaleza');

require 'database.php';

$response = [
    'success' => false,
    'message' => 'Ocorreu um erro desconhecido.'
];

if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'Usuário não autenticado.';
    echo json_encode($response);
    exit();
}

$compraId = $_POST['compra_id'] ?? null;
if (!$compraId) {
    $response['message'] = 'ID da compra não fornecido.';
    echo json_encode($response);
    exit();
}

$userId = $_SESSION['user_id'];

try {
    $pdo->beginTransaction();

    // 1. Obter os dados da compra e do plano em uma única consulta
    $query = "
        SELECT
            c.id, c.usuario_id, c.proximo_rendimento, c.vencimento, c.status,
            p.receitaDiaria, p.nome
        FROM
            compras c
        JOIN
            planos p ON c.plano_id = p.id
        WHERE
            c.id = :compra_id AND c.usuario_id = :user_id AND c.status = 'rodando'
        FOR UPDATE
    ";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':compra_id', $compraId, PDO::PARAM_INT);
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    $compra = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$compra) {
        $response['message'] = 'Plano não encontrado, não ativo ou já processado.';
        echo json_encode($response);
        $pdo->rollBack();
        exit();
    }

    $proximoRendimento = new DateTime($compra['proximo_rendimento']);
    $agora = new DateTime();

    // 2. Verificar se o rendimento já está disponível
    if ($proximoRendimento > $agora) {
        $response['message'] = 'Rendimento ainda não disponível.';
        echo json_encode($response);
        $pdo->rollBack();
        exit();
    }

    $receitaDiaria = $compra['receitaDiaria'];
    $nomePlano = $compra['nome'];
    $vencimentoDate = new DateTime($compra['vencimento']);

    // Loop para processar rendimentos atrasados (se houver)
    $rendimentosProcessados = 0;
    while ($proximoRendimento <= $agora && $proximoRendimento < $vencimentoDate) {
        // Creditar no saldo do usuário
        $queryUpdateSaldo = "UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?";
        $stmtUpdateSaldo = $pdo->prepare($queryUpdateSaldo);
        $stmtUpdateSaldo->execute([$receitaDiaria, $userId]);

        // Registrar na tabela de transações
        $descricao = "Rendimento de produto: " . $nomePlano;
        $queryTransacao = "INSERT INTO transacoes (usuario_id, tipo, valor, descricao, data_transacao) VALUES (?, 'produto', ?, ?, ?)";
        $stmtTransacao = $pdo->prepare($queryTransacao);
        $stmtTransacao->execute([$userId, $receitaDiaria, $descricao, $proximoRendimento->format('Y-m-d H:i:s')]);

        // Avança para o próximo ciclo
        $proximoRendimento->add(new DateInterval("P1D"));
        $rendimentosProcessados++;
    }

    // 3. Atualizar a data do próximo rendimento na tabela de compras
    $queryUpdateProximo = "UPDATE compras SET proximo_rendimento = ? WHERE id = ?";
    $stmtUpdateProximo = $pdo->prepare($queryUpdateProximo);
    $stmtUpdateProximo->execute([$proximoRendimento->format('Y-m-d H:i:s'), $compraId]);

    $pdo->commit();
    $response['success'] = true;
    $response['message'] = "{$rendimentosProcessados} rendimento(s) processado(s) com sucesso para o plano '{$nomePlano}'.";
    $response['novoProximoRendimento'] = $proximoRendimento->getTimestamp() * 1000;

    echo json_encode($response);

} catch (PDOException $e) {
    $pdo->rollBack();
    $response['message'] = 'Erro no banco de dados: ' . $e->getMessage();
    echo json_encode($response);
}
?>