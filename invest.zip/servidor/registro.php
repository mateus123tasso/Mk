<?php
session_start();

// Define o arquivo de log para o registro
define('REGISTRO_LOG_FILE', __DIR__ . '/registro.log');

/**
 * Função para registrar mensagens no arquivo de log do registro.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_registro_log($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(REGISTRO_LOG_FILE, $log_entry, FILE_APPEND);
}

write_registro_log("Início da requisição de registro. Método: " . $_SERVER['REQUEST_METHOD'], 'DEBUG');

// Definindo o fuso horário para Fortaleza (Brasil)
date_default_timezone_set('America/Fortaleza');

// Inclui o arquivo de conexão com o banco de dados
require 'database.php'; // Caminho relativo a este script

// Função auxiliar para enviar resposta JSON
function sendJsonResponse($status, $message, $data = []) {
    header('Content-Type: application/json');
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Função para gerar um código de convite aleatório
function generateInvitationCode($length = 10) { // Aumentei o tamanho para 10 para mais unicidade
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[random_int(0, strlen($characters) - 1)];
    }
    return $code;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    write_registro_log("Dados POST recebidos: " . json_encode($_POST), 'DEBUG');

    // Coleta e sanitiza os dados do POST
    $fullName = trim($_POST['fullName'] ?? '');
    $cpf = trim($_POST['cpf'] ?? '');
    $phone_input = trim($_POST['phone'] ?? ''); // Será o 'username'
    $password_input = $_POST['password'] ?? '';
    $invitationCode_input = trim($_POST['invitationCode'] ?? ''); // Opcional

    // --- Validações de Entrada (Backend) ---
    if (empty($fullName) || empty($cpf) || empty($phone_input) || empty($password_input)) {
        write_registro_log("Validação falhou: Campos obrigatórios vazios.", 'WARNING');
        sendJsonResponse('error', 'Por favor, preencha todos os campos obrigatórios: Nome Completo, CPF, Celular e Senha.');
    }

    if (strlen($password_input) < 6) {
        write_registro_log("Validação falhou: Senha muito curta.", 'WARNING');
        sendJsonResponse('error', 'A senha deve ter no mínimo 6 caracteres.');
    }

    if (!preg_match('/^\d{11}$/', $phone_input)) {
        write_registro_log("Validação falhou: Celular inválido. Valor: {$phone_input}", 'WARNING');
        sendJsonResponse('error', 'Número de celular inválido. Deve ter 11 dígitos (incluindo DDD, ex: 11987654321).');
    }

    if (!preg_match('/^\d{11}$/', $cpf)) {
        write_registro_log("Validação falhou: CPF inválido. Valor: {$cpf}", 'WARNING');
        sendJsonResponse('error', 'CPF inválido. Deve ter 11 dígitos (somente números).');
    }

    try {
        // Verifica se a conexão PDO está disponível
        if (!isset($pdo) || !$pdo instanceof PDO) {
            write_registro_log("Erro crítico: Conexão PDO não estabelecida. Verifique database.php.", 'CRITICAL');
            sendJsonResponse('error', 'Erro interno: Conexão com o banco de dados não estabelecida.');
        }

        // --- Verificação de Unicidade (Celular e CPF) ---
        write_registro_log("Verificando unicidade de celular ({$phone_input}) e CPF ({$cpf}).", 'DEBUG');
        $stmtCheck = $pdo->prepare("SELECT id FROM usuarios WHERE username = :username OR cpf = :cpf");
        $stmtCheck->execute([':username' => $phone_input, ':cpf' => $cpf]);
        if ($stmtCheck->rowCount() > 0) {
            write_registro_log("Validação falhou: Celular ou CPF já cadastrados.", 'WARNING');
            sendJsonResponse('error', 'Este número de celular ou CPF já está em uso por outra conta. Por favor, verifique seus dados.');
        }

        // --- Validação e ID do Patrocinador (Código de Convite) ---
        $id_patrocinador = null;
        if (!empty($invitationCode_input)) {
            write_registro_log("Código de convite inserido: {$invitationCode_input}. Validando...", 'DEBUG');
            $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE codigo_convite = :codigo_convite");
            $stmt->execute([':codigo_convite' => $invitationCode_input]);
            if ($stmt->rowCount() > 0) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $id_patrocinador = $row['id'];
                write_registro_log("Código de convite válido. Patrocinador ID: {$id_patrocinador}", 'INFO');
            } else {
                write_registro_log("Validação falhou: Código de convite inválido ou não encontrado.", 'WARNING');
                sendJsonResponse('error', 'Código de convite inválido ou não encontrado.');
            }
        } else {
            write_registro_log("Nenhum código de convite inserido.", 'DEBUG');
        }
        
        // --- Hashing da Senha ---
        $passwordHash = password_hash($password_input, PASSWORD_BCRYPT);
        write_registro_log("Senha hasheada.", 'DEBUG');

        // --- Gerar Código de Convite Único para o NOVO Usuário ---
        $novo_codigo_convite = '';
        do {
            $novo_codigo_convite = generateInvitationCode(); // Chama a função que gera código
            $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE codigo_convite = :codigo_convite");
            $stmt->execute([':codigo_convite' => $novo_codigo_convite]);
            write_registro_log("Tentando gerar código de convite único: {$novo_codigo_convite}", 'DEBUG');
        } while ($stmt->rowCount() > 0);
        write_registro_log("Código de convite único gerado para novo usuário: {$novo_codigo_convite}.", 'INFO');

        // --- Inserir Novo Usuário no Banco de Dados ---
        // Definindo saldos iniciais.
        // Se sua tabela tem 'saldo_principal' e 'saldo_recarga' e 'saldo_retirada' (DECIMAL(10,2)):
        $saldo_principal_inicial = 0.00;
        $saldo_recarga_inicial = 10.00; // Conforme seu default na DB (se tiver)
        $saldo_retirada_inicial = 0.00; // Conforme seu default na DB (se tiver)

        // ATENÇÃO: Esta é a query de INSERT.
        // VOCÊ PRECISA GARANTIR QUE AS COLUNAS ABAIXO EXISTEM NA SUA TABELA `usuarios` NO DB
        // E ESTÃO COM OS NOMES EXATOS!
        // As colunas devem ser:
        // id (PRIMARY KEY, AUTO_INCREMENT)
        // nome_completo VARCHAR(255)
        // cpf VARCHAR(11)
        // username VARCHAR(255) (para o celular)
        // password VARCHAR(255)
        // id_patrocinador INT (NULLable)
        // codigo_convite VARCHAR(10)
        // saldo_principal DECIMAL(10, 2)
        // saldo_recarga DECIMAL(10, 2)
        // saldo_retirada DECIMAL(10, 2)
        // data_cadastro (DATETIME, DEFAULT CURRENT_TIMESTAMP)
        // E quaisquer outras colunas que você tenha (ex: total_investido, total_sacado_hoje, etc.)

        $stmtInsert = $pdo->prepare("INSERT INTO usuarios 
                                    (nome_completo, cpf, username, password, id_patrocinador, codigo_convite, saldo_principal, saldo_recarga, saldo_retirada)
                                    VALUES (:fullName, :cpf, :username, :password, :id_patrocinador, :codigo_convite, :saldo_principal, :saldo_recarga, :saldo_retirada)");

        $stmtInsert->bindParam(':fullName', $fullName);
        $stmtInsert->bindParam(':cpf', $cpf);
        $stmtInsert->bindParam(':username', $phone_input);
        $stmtInsert->bindParam(':password', $passwordHash);
        $stmtInsert->bindParam(':id_patrocinador', $id_patrocinador, PDO::PARAM_INT);
        $stmtInsert->bindParam(':codigo_convite', $novo_codigo_convite);
        $stmtInsert->bindParam(':saldo_principal', $saldo_principal_inicial);
        $stmtInsert->bindParam(':saldo_recarga', $saldo_recarga_inicial);
        $stmtInsert->bindParam(':saldo_retirada', $saldo_retirada_inicial);

        write_registro_log("Executando INSERT na tabela usuarios.", 'DEBUG');
        if ($stmtInsert->execute()) {
            write_registro_log("Usuário registrado com sucesso. User ID: " . $pdo->lastInsertId(), 'INFO');
            sendJsonResponse('success', 'Conta criada com sucesso!', ['user_id' => $pdo->lastInsertId()]);
        } else {
            $errorInfo = $stmtInsert->errorInfo();
            write_registro_log("Erro ao executar INSERT no DB: SQLSTATE: {$errorInfo[0]}, Code: {$errorInfo[1]}, Message: {$errorInfo[2]}", 'ERROR');
            sendJsonResponse('error', 'Erro ao registrar usuário. Por favor, tente novamente. Detalhes: ' . $errorInfo[2]);
        }

    } catch (PDOException $e) {
        write_registro_log("Erro PDO catch ao registrar usuário: " . $e->getMessage(), 'CRITICAL');
        sendJsonResponse('error', 'Ocorreu um erro interno do servidor ao registrar. Por favor, tente novamente mais tarde.');
    } catch (Exception $e) {
        write_registro_log("Erro geral catch ao registrar usuário: " . $e->getMessage(), 'CRITICAL');
        sendJsonResponse('error', 'Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.');
    }

} else {
    sendJsonResponse('error', 'Método de requisição inválido.');
}
?>