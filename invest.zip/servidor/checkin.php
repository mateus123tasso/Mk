<?php

session_start();

require 'database.php';

date_default_timezone_set('America/Fortaleza');

if (!isset($_SESSION['user_id'])) {
    exit();
}

$usuario_id = $_SESSION['user_id'];
$data_hoje = date('Y-m-d');
$valor = 1;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('SELECT COUNT(*) FROM checkins WHERE usuario_id = :usuario_id AND data_checkin = :data_checkin');
    $stmt->execute(['usuario_id' => $usuario_id, 'data_checkin' => $data_hoje]);
    $ja_fez_checkin = $stmt->fetchColumn();

    if ($ja_fez_checkin) {
        echo "login uma vez por dia";
    } else {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare('INSERT INTO checkins (usuario_id, data_checkin) VALUES (:usuario_id, :data_checkin)');
        $stmt->execute(['usuario_id' => $usuario_id, 'data_checkin' => $data_hoje]);

        $stmt = $pdo->prepare('UPDATE usuarios SET saldo_recarga = saldo_recarga + 1 WHERE id = :usuario_id');
        $stmt->execute(['usuario_id' => $usuario_id]);
        
        $queryTransacaoCheckin = "INSERT INTO transacoes (usuario_id, tipo, valor, descricao) VALUES (?, 'checkin', ?, 'Login diario')";
        $stmtTransacaoCheckin = $pdo->prepare($queryTransacaoCheckin);
        $stmtTransacaoCheckin->execute([$usuario_id, $valor]);

        $pdo->commit();
        
        echo "success";
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['message' => 'Ocorreu um erro: ' . $e->getMessage()]);
}
?>
