<?php
// Este script deve ser executado APENAS por Cron Job,
// por exemplo, a cada minuto.

require 'database.php'; // Inclui a conexão com o banco de dados

date_default_timezone_set('America/Fortaleza'); // Garante a timezone

try {
    // 1. Lógica para creditar o rendimento diário para planos ativos
    $sql_investimentos_ativos = "SELECT c.*, p.receitaDiaria, p.diasDeReceita, p.receitaTotal
                                 FROM compras c
                                 JOIN planos p ON c.plano_id = p.id -- Corrigido para `planos` e `plano_id`
                                 WHERE c.status = 'rodando'";
    $stmt_ativos = $pdo->query($sql_investimentos_ativos);
    $investimentos = $stmt_ativos->fetchAll(PDO::FETCH_ASSOC);

    foreach ($investimentos as $investimento) {
        $compraId = $investimento['id'];
        $usuarioId = $investimento['usuario_id'];
        $rendaDiaria = $investimento['receitaDiaria']; // Corrigido para `receitaDiaria`
        $ultimoCredito = new DateTime($investimento['ultimo_credito'] ?? $investimento['data_compra']);
        $agora = new DateTime();
        $intervalo = $agora->getTimestamp() - $ultimoCredito->getTimestamp();

        // Verifica se 24 horas (86400 segundos) se passaram desde o último crédito
        if ($intervalo >= 86400) {
            $pdo->beginTransaction();
            try {
                // A. Adiciona o rendimento diário ao 'saldo_retirada' do usuário
                $sql_creditar = "UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?";
                $stmt_creditar = $pdo->prepare($sql_creditar);
                $stmt_creditar->execute([$rendaDiaria, $usuarioId]);

                // B. Registra o rendimento no histórico 'rendimentos_diarios'
                $sql_registro_rendimento = "INSERT INTO rendimentos_diarios (usuario_id, compra_id, valor, data_rendimento) VALUES (?, ?, ?, NOW())";
                $stmt_registro = $pdo->prepare($sql_registro_rendimento);
                $stmt_registro->execute([$usuarioId, $compraId, $rendaDiaria]);

                // C. Atualiza a coluna 'ultimo_credito' para agora
                $sql_atualizar_credito = "UPDATE compras SET ultimo_credito = NOW() WHERE id = ?";
                $stmt_atualizar = $pdo->prepare($sql_atualizar_credito);
                $stmt_atualizar->execute([$compraId]);

                $pdo->commit();
                error_log("Rendimento de R$ " . $rendaDiaria . " creditado para o usuário " . $usuarioId . " da compra " . $compraId);

            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erro na transação para creditar rendimento da compra " . $compraId . ": " . $e->getMessage());
            }
        }
    }

    // 2. Lógica para finalizar planos que atingiram a duração total
    $sql_finalizar = "SELECT c.*, p.diasDeReceita
                      FROM compras c
                      JOIN planos p ON c.plano_id = p.id -- Corrigido para `planos` e `plano_id`
                      WHERE c.status = 'rodando'";
    $stmt_finalizar = $pdo->query($sql_finalizar);
    $compras_para_finalizar = $stmt_finalizar->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($compras_para_finalizar as $compra) {
        $compraId = $compra['id'];
        $dataCompra = new DateTime($compra['data_compra']);
        $agora = new DateTime();
        $tempoDecorridoSegundos = $agora->getTimestamp() - $dataCompra->getTimestamp();
        $duracaoTotalSegundos = $compra['diasDeReceita'] * 86400; // Corrigido para `diasDeReceita`

        if ($tempoDecorridoSegundos >= $duracaoTotalSegundos) {
            $pdo->beginTransaction();
            try {
                // Atualiza o status da compra para 'finalizado'
                $queryUpdateStatus = "UPDATE compras SET status = 'finalizado', data_vencimento = NOW() WHERE id = ?";
                $stmtUpdateStatus = $pdo->prepare($queryUpdateStatus);
                $stmtUpdateStatus->execute([$compraId]);

                $pdo->commit();
                error_log("Compra " . $compraId . " finalizada por expiração da duração do plano.");
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erro ao finalizar a compra " . $compraId . ": " . $e->getMessage());
            }
        }
    }

} catch (PDOException $e) {
    error_log("Erro geral no script de atualização: " . $e->getMessage());
}
?>