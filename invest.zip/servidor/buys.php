<?php
session_start();

header('Content-Type: application/json');

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    echo json_encode([]);
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
// A linha abaixo presume que 'database.php' está na mesma pasta.
// Se não estiver, ajuste o caminho.
require 'database.php';

$userId = $_SESSION['user_id'];

try {
    // Consulta SQL para JUNTAR as tabelas 'compras' e 'planos'
    // A query foi mantida, pois já está otimizada e busca todos os dados necessários
    $stmt = $pdo->prepare("
        SELECT
            c.id,
            c.usuario_id,
            c.plano_id,
            c.data_compra,
            c.vencimento,
            c.status,
            c.proximo_rendimento,
            p.nome AS nome_plano,
            p.preco AS valor_investido,
            p.receitaDiaria AS renda_diaria,
            p.receitaTotal AS renda_total_prevista
        FROM
            compras c
        JOIN
            planos p ON c.plano_id = p.id
        WHERE
            c.usuario_id = :user_id
        ORDER BY
            c.data_compra DESC
    ");
    $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($compras);

} catch (PDOException $e) {
    // Em produção, registre o erro em um arquivo de log para segurança
    error_log("Erro ao buscar compras do usuário: " . $e->getMessage());
    // Retorna um array vazio para o front-end em caso de falha
    echo json_encode([]);
}
?>