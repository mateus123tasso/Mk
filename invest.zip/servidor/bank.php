<?php
session_start();
header('Content-Type: application/json'); // Garante que a resposta será JSON

// Define o arquivo de log para o script bank.php
define('BANK_LOG_FILE', __DIR__ . '/bank.log'); // Será criado em servidor/bank.log

/**
 * Função para registrar mensagens no arquivo de log do banco.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_bank_log($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(BANK_LOG_FILE, $log_entry, FILE_APPEND);
}

write_bank_log("Início da requisição para servidor/bank.php. Método: " . $_SERVER['REQUEST_METHOD'], 'DEBUG');

// Inclui o arquivo de conexão com o banco de dados
require 'database.php'; // Caminho relativo a este script

// Função auxiliar para enviar resposta JSON e encerrar o script
function sendJsonResponse($status, $message, $data = [], $http_code = 200) {
    http_response_code($http_code);
    echo json_encode(['status' => $status, 'mensagem' => $message, 'dados' => $data]);
    exit();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    write_bank_log("Usuário não autenticado. Acesso negado a servidor/bank.php.", 'WARNING');
    sendJsonResponse('erro', 'Usuário não autenticado.', [], 401);
}

$user_id = $_SESSION['user_id'];
write_bank_log("Usuário autenticado. User ID: {$user_id}.", 'DEBUG');

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Lógica para buscar os dados de Nome, CPF do usuário (da tabela 'usuarios')
        // e a chave_pix (da tabela 'carteiras', se já salva)
        try {
            // Primeiro, busca nome_completo e cpf da tabela 'usuarios'
            $stmtUser = $pdo->prepare("SELECT nome_completo, cpf FROM usuarios WHERE id = ?");
            if (!$stmtUser) {
                write_bank_log("Erro ao preparar stmtUser GET: " . json_encode($pdo->errorInfo()), 'ERROR');
                throw new Exception("Erro ao preparar busca de dados do usuário.");
            }
            $stmtUser->execute([$user_id]);
            $userInfo = $stmtUser->fetch(PDO::FETCH_ASSOC);
            $stmtUser->closeCursor();

            $nome_completo_db = $userInfo['nome_completo'] ?? null;
            $cpf_db = $userInfo['cpf'] ?? null;
            
            // Depois, busca a carteira na tabela 'carteiras' usando 'uid'
            $stmtCarteira = $pdo->prepare("SELECT chave_pix, cpf, nome_completo FROM carteiras WHERE uid = ?"); // 'uid' é o user_id
            if (!$stmtCarteira) {
                write_bank_log("Erro ao preparar stmtCarteira GET: " . json_encode($pdo->errorInfo()), 'ERROR');
                throw new Exception("Erro ao preparar busca de carteira.");
            }
            $stmtCarteira->execute([$user_id]);
            $carteiraInfo = $stmtCarteira->fetch(PDO::FETCH_ASSOC);
            $stmtCarteira->closeCursor();

            $chave_pix_carteira = $carteiraInfo['chave_pix'] ?? null;
            // Opcional: Se 'carteiras' também tem CPF e Nome, pode usá-los aqui,
            // mas para a lógica atual, priorizamos 'usuarios' para nome/cpf de cadastro.
            // $cpf_carteira = $carteiraInfo['cpf'] ?? null;
            // $nome_completo_carteira = $carteiraInfo['nome_completo'] ?? null;

            write_bank_log("GET request: Dados para User ID {$user_id} - Nome (usuarios): '{$nome_completo_db}', CPF (usuarios): '{$cpf_db}', Chave PIX (carteiras): '{$chave_pix_carteira}'", 'DEBUG');

            // Se a carteira for encontrada, significa que a chave pix já foi configurada
            if ($carteiraInfo) {
                sendJsonResponse(
                    'sucesso', // Retorna 'sucesso' se encontrou a carteira
                    'Carteira encontrada e dados recuperados.',
                    [
                        'nome_completo' => $nome_completo_db, // Nome sempre vem de 'usuarios'
                        'cpf' => $cpf_db, // CPF sempre vem de 'usuarios'
                        'chave_pix' => $chave_pix_carteira // Chave PIX vem de 'carteiras'
                    ]
                );
            } else {
                // Se nenhum dado for encontrado, retorna 'vazio' para o frontend
                sendJsonResponse(
                    'vazio', // Retorna 'vazio' para o frontend para indicar que não há chave pix salva
                    'Nenhuma carteira encontrada.',
                    [
                        'nome_completo' => $nome_completo_db, // Nome sempre vem de 'usuarios'
                        'cpf' => $cpf_db, // CPF sempre vem de 'usuarios'
                        'chave_pix' => null
                    ]
                );
            }

        } catch (Exception $e) {
            write_bank_log("Erro ao buscar dados da conta PIX (GET): " . $e->getMessage(), 'ERROR');
            sendJsonResponse('erro', 'Erro ao buscar dados da conta PIX: ' . $e->getMessage(), [], 500);
        }
        break;

    case 'POST':
        // Lógica para salvar/atualizar os dados da conta PIX (Nome, CPF e Chave PIX = CPF)
        $input = json_decode(file_get_contents('php://input'), true);

        // Verifica se os dados JSON foram decodificados corretamente
        if (json_last_error() !== JSON_ERROR_NONE) {
            write_bank_log("Erro ao decodificar JSON do POST: " . json_last_error_msg(), 'ERROR');
            sendJsonResponse('erro', 'Erro nos dados enviados. Formato inválido.', [], 400);
        }

        $nome_completo_recebido = trim($input['nome_completo'] ?? '');
        $chave_pix_recebida = trim($input['chave_pix'] ?? ''); // O valor do campo Chave PIX (que é o CPF)
        $cpf_recebido = trim($input['cpf'] ?? ''); // O valor do campo CPF

        write_bank_log("POST request: Recebidos para User ID {$user_id} - Nome: '{$nome_completo_recebido}', Chave PIX: '{$chave_pix_recebida}', CPF: '{$cpf_recebido}'", 'DEBUG');

        // Validação de Backend: Nome, CPF e Chave PIX (que é o CPF) devem estar preenchidos
        if (empty($nome_completo_recebido) || empty($chave_pix_recebida) || empty($cpf_recebido)) {
            write_bank_log("Validação falhou: Campos obrigatórios vazios. Nome: '{$nome_completo_recebido}', Chave: '{$chave_pix_recebida}', CPF: '{$cpf_recebido}'", 'WARNING');
            sendJsonResponse('erro', 'Todos os campos são obrigatórios: Nome completo, Chave PIX e CPF.', [], 400);
        }

        // Validação de CPF (11 dígitos numéricos)
        if (strlen($cpf_recebido) !== 11 || !ctype_digit($cpf_recebido)) {
            write_bank_log("Validação falhou: CPF inválido. Valor: '{$cpf_recebido}'", 'WARNING');
            sendJsonResponse('erro', 'CPF inválido. Por favor, insira 11 dígitos numéricos.', [], 400);
        }

        // Validação de consistência: Chave PIX deve ser igual ao CPF
        if ($chave_pix_recebida !== $cpf_recebido) {
            write_bank_log("Validação falhou: Chave PIX ({$chave_pix_recebida}) diferente do CPF ({$cpf_recebido}).", 'WARNING');
            sendJsonResponse('erro', 'A Chave PIX deve ser o mesmo valor que o CPF.', [], 400);
        }

        // Inicia uma transação no DB para garantir atomicidade
        $pdo->beginTransaction();
        try {
            // 1. Atualiza nome_completo e cpf na tabela `usuarios`
            // Isso garante que os dados de cadastro estejam atualizados.
            $stmtUpdateUser = $pdo->prepare("UPDATE usuarios SET nome_completo = ?, cpf = ? WHERE id = ?");
            if (!$stmtUpdateUser) {
                write_bank_log("Erro ao preparar stmtUpdateUser: " . json_encode($pdo->errorInfo()), 'ERROR');
                throw new Exception("Erro ao preparar atualização de dados do usuário.");
            }
            $stmtUpdateUser->execute([$nome_completo_recebido, $cpf_recebido, $user_id]);
            write_bank_log("Usuário ID {$user_id}: Nome e CPF atualizados na tabela 'usuarios'.", 'INFO');
            $stmtUpdateUser->closeCursor();

            // 2. Insere ou atualiza a carteira na tabela `carteiras`
            // Verifica se já existe um registro para este uid (user_id) na tabela `carteiras`
            $stmtCheckCarteira = $pdo->prepare("SELECT id FROM carteiras WHERE uid = ?");
            if (!$stmtCheckCarteira) {
                write_bank_log("Erro ao preparar stmtCheckCarteira: " . json_encode($pdo->errorInfo()), 'ERROR');
                throw new Exception("Erro ao preparar verificação de carteira.");
            }
            $stmtCheckCarteira->execute([$user_id]);
            $existingCarteiraId = $stmtCheckCarteira->fetchColumn();
            $stmtCheckCarteira->closeCursor();

            if ($existingCarteiraId) {
                // Se a carteira já existe, atualiza
                $stmtUpdateCarteira = $pdo->prepare("UPDATE carteiras SET chave_pix = ?, cpf = ?, nome_completo = ? WHERE uid = ?");
                if (!$stmtUpdateCarteira) {
                    write_bank_log("Erro ao preparar stmtUpdateCarteira: " . json_encode($pdo->errorInfo()), 'ERROR');
                    throw new Exception("Erro ao preparar atualização de carteira.");
                }
                $stmtUpdateCarteira->execute([$chave_pix_recebida, $cpf_recebido, $nome_completo_recebido, $user_id]);
                write_bank_log("Usuário ID {$user_id}: Carteira atualizada no DB.", 'INFO');
                $stmtUpdateCarteira->closeCursor();
            } else {
                // Se a carteira não existe, insere
                $stmtInsertCarteira = $pdo->prepare("INSERT INTO carteiras (uid, chave_pix, cpf, nome_completo) VALUES (?, ?, ?, ?)");
                if (!$stmtInsertCarteira) {
                    write_bank_log("Erro ao preparar stmtInsertCarteira: " . json_encode($pdo->errorInfo()), 'ERROR');
                    throw new Exception("Erro ao preparar inserção de carteira.");
                }
                $stmtInsertCarteira->execute([$user_id, $chave_pix_recebida, $cpf_recebido, $nome_completo_recebido]);
                write_bank_log("Usuário ID {$user_id}: Nova carteira inserida no DB.", 'INFO');
                $stmtInsertCarteira->closeCursor();
            }

            $pdo->commit();
            write_bank_log("Dados da conta PIX para User ID {$user_id} salvos com sucesso.", 'INFO');
            sendJsonResponse('sucesso', 'Sua chave PIX foi configurada com sucesso!');

        } catch (Exception $e) {
            $pdo->rollBack();
            write_bank_log("Erro ao salvar dados da conta PIX (POST): " . $e->getMessage(), 'ERROR');
            sendJsonResponse('erro', 'Erro ao salvar sua chave PIX: ' . $e->getMessage(), [], 500);
        }
        break;

    default:
        write_bank_log("Método HTTP não permitido: " . $method, 'WARNING');
        sendJsonResponse('erro', 'Método não permitido.', [], 405);
        break;
}

// Fechar conexão PDO se necessário (ou deixar o PHP fechar automaticamente)
// if ($pdo) { $pdo = null; }

?>