<?php
// /servidor/processa_rendimentos.php
set_time_limit(0);

// Para ambiente de teste, remova em produção
error_reporting(E_ALL);
ini_set('display_errors', 1);

date_default_timezone_set('America/Fortaleza');

require 'database.php';

function writeLog($message) {
    $logFile = 'equipe.log';
    $timestamp = date('[Y-m-d H:i:s]');
    file_put_contents($logFile, $timestamp . " " . $message . PHP_EOL, FILE_APPEND);
}

// =========================================================================
// Lógica Principal de Processamento
// =========================================================================
function processarRendimentos($pdo, $compraId = null) {
    writeLog("Iniciando processamento de rendimentos. ID da Compra: " . ($compraId ?? 'Todos (Cron)'));
    $response = ['success' => false, 'message' => 'Nenhum rendimento disponível para processamento.'];
    $sucessoProcessamento = false;
    $vencido = false;

    try {
        $pdo->beginTransaction();

        // 1. FINALIZAR PLANOS VENCIDOS (para cron job)
        if ($compraId === null) {
            $queryFinalizarVencidos = "UPDATE compras SET status = 'finalizado' WHERE status = 'rodando' AND vencimento < NOW()";
            $stmtFinalizarVencidos = $pdo->prepare($queryFinalizarVencidos);
            $stmtFinalizarVencidos->execute();
        }

        // 2. SELECIONA OS PLANOS QUE PRECISAM DE RENDIMENTO
        $queryCompras = "
            SELECT c.*, p.receitaDiaria, p.nome
            FROM compras c
            JOIN planos p ON c.plano_id = p.id
            WHERE c.status = 'rodando' AND c.proximo_rendimento <= NOW()
        ";
        if ($compraId !== null) {
            $queryCompras .= " AND c.id = :compra_id";
        }
        $queryCompras .= " FOR UPDATE";

        $stmtCompras = $pdo->prepare($queryCompras);
        if ($compraId !== null) {
            $stmtCompras->bindParam(':compra_id', $compraId, PDO::PARAM_INT);
        }
        $stmtCompras->execute();
        $comprasParaAtualizar = $stmtCompras->fetchAll(PDO::FETCH_ASSOC);

        foreach ($comprasParaAtualizar as $compra) {
            $compraId = $compra['id'];
            $usuarioId = $compra['usuario_id'];
            $receitaDiaria = $compra['receitaDiaria'];
            $nomePlano = $compra['nome'];

            $agora = new DateTime();
            
            // Lógica de reparo APRIMORADA para datas corrompidas
            $proximoRendimentoString = preg_replace('/\s+/', ' ', trim($compra['proximo_rendimento']));
            $vencimentoString = preg_replace('/\s+/', ' ', trim($compra['vencimento']));

            $proximoRendimento = DateTime::createFromFormat('Y-m-d H:i:s', $proximoRendimentoString);
            $vencimentoDate = DateTime::createFromFormat('Y-m-d H:i:s', $vencimentoString);

            if ($proximoRendimento === false || $vencimentoDate === false) {
                // Se a data ainda for inválida, loga o erro e pula a compra.
                writeLog("ERRO: Falha ao converter datas para a compra #{$compraId}. Dados no DB: '{$compra['proximo_rendimento']}' e '{$compra['vencimento']}'. Pulando...");
                continue;
            }
            
            // Se as strings foram corrigidas, atualiza o banco de dados
            if ($proximoRendimentoString !== $compra['proximo_rendimento'] || $vencimentoString !== $compra['vencimento']) {
                $queryUpdateDates = "UPDATE compras SET proximo_rendimento = ?, vencimento = ? WHERE id = ?";
                $stmtUpdateDates = $pdo->prepare($queryUpdateDates);
                $stmtUpdateDates->execute([$proximoRendimentoString, $vencimentoString, $compraId]);
                writeLog("AVISO: Datas corrigidas e atualizadas para a compra #{$compraId}.");
            }

            // Loop para processar múltiplos rendimentos se o cron job estiver atrasado
            $ganhosProcessados = 0;
            while ($proximoRendimento <= $agora && $proximoRendimento < $vencimentoDate) {
                // Credita no saldo do usuário
                $queryUpdateSaldo = "UPDATE usuarios SET saldo_retirada = saldo_retirada + ? WHERE id = ?";
                $stmtUpdateSaldo = $pdo->prepare($queryUpdateSaldo);
                $stmtUpdateSaldo->execute([$receitaDiaria, $usuarioId]);

                // Registra na tabela de transações
                $descricao = "Rendimento de produto: " . $nomePlano;
                $queryTransacaoRendimento = "INSERT INTO transacoes (usuario_id, tipo, valor, descricao, data_transacao) VALUES (?, 'produto', ?, ?, ?)";
                $stmtTransacaoRendimento = $pdo->prepare($queryTransacaoRendimento);
                $stmtTransacaoRendimento->execute([$usuarioId, $receitaDiaria, $descricao, $proximoRendimento->format('Y-m-d H:i:s')]);
                
                $proximoRendimento->add(new DateInterval("P1D"));
                $ganhosProcessados++;
            }
            
            if ($proximoRendimento >= $vencimentoDate) {
                 $vencido = true;
                 $queryUpdateStatus = "UPDATE compras SET status = 'finalizado' WHERE id = ?";
                 $stmtUpdateStatus = $pdo->prepare($queryUpdateStatus);
                 $stmtUpdateStatus->execute([$compraId]);
            }

            // Atualiza a data do próximo rendimento, se houver rendimentos processados
            if ($ganhosProcessados > 0) {
                $sucessoProcessamento = true;
                $queryUpdateProximo = "UPDATE compras SET proximo_rendimento = ? WHERE id = ?";
                $stmtUpdateProximo = $pdo->prepare($queryUpdateProximo);
                $stmtUpdateProximo->execute([$proximoRendimento->format('Y-m-d H:i:s'), $compraId]);

                writeLog("INFO: {$ganhosProcessados} rendimento(s) processado(s) para a compra #{$compraId}. Próximo rendimento: " . $proximoRendimento->format('Y-m-d H:i:s'));
            }
        }
        
        $pdo->commit();
        writeLog("Processamento de rendimentos concluído com sucesso.");

        if ($sucessoProcessamento) {
            $response = [
                'success' => true,
                'message' => 'Rendimento(s) recebido(s) com sucesso.',
                'novoProximoRendimento' => $proximoRendimento->getTimestamp() * 1000
            ];
            if ($vencido) {
                $response['message'] = 'O plano foi finalizado e os rendimentos foram creditados.';
            }
        }

        return $response;

    } catch (PDOException $e) {
        $pdo->rollBack();
        writeLog("ERRO CRÍTICO: Falha no processamento de rendimentos. Mensagem: " . $e->getMessage());
        return ['success' => false, 'message' => 'Erro no banco de dados: ' . $e->getMessage()];
    }
}

// =========================================================================
// Rota para o Navegador (AJAX) ou Cron Job
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['compra_id'])) {
    session_start();
    header('Content-Type: application/json');

    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Usuário não autenticado.']);
        exit();
    }
    
    $stmt = $pdo->prepare("SELECT id FROM compras WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$_POST['compra_id'], $_SESSION['user_id']]);
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Acesso negado ou plano inexistente.']);
        exit();
    }

    $response = processarRendimentos($pdo, $_POST['compra_id']);
    echo json_encode($response);

} else {
    writeLog("==================================================");
    processarRendimentos($pdo);
    writeLog("Finalizando processamento automático de rendimentos.");
    writeLog("==================================================");
}
?>