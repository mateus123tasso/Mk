<?php
session_start();

// Include necessary server-side scripts
include('servidor/infor.php');
include('servidor/atualizar_rendimento.php');

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Minha Conta Bancária</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&display=swap" rel="stylesheet">
    <style>
        /* --- Ocultar Scrollbar --- */
        ::-webkit-scrollbar {
            width: 0px;
            background: transparent;
        }
        body {
            -ms-overflow-style: none; /* IE e Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* --- Basic Reset & Body Styles --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif; /* Consistent with other pages */
        }

        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            /* Heineken Background */
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow-x: hidden;
            position: relative;
            padding-bottom: 0; /* No need for padding-bottom here if the main container handles it */
        }

        /* --- Background Shapes (consistent) --- */
        .background-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            pointer-events: none;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* --- Main Container (like .device on other pages) --- */
        .main-container {
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 30px; /* Adjust if a fixed tabbar is present below content */
            background: rgba(255, 255, 255, 0.1); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding-top: 0;
            display: flex;
            flex-direction: column; /* Allows content to stack vertically */
        }

        /* --- Header (consistent) --- */
        .header {
            padding: 50px 17px 20px;
            background: rgba(255, 255, 255, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 20;
        }

        .header .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            width: 24px;
            height: 24px;
            margin-right: 15px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3)); /* White arrow with shadow */
        }

        .header-title {
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            font-size: 26px;
            font-weight: 800;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* --- Bank Account Box --- */
        .bank-account-box {
            margin: 30px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.15); /* Glassmorphism effect */
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 30px 20px;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            animation: fadeInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .bank-account-box .card-image {
            text-align: center;
            margin-bottom: 25px;
        }
        .bank-account-box .card-image img {
            width: 320px; /* Adjust size as needed */
            max-width: 90%;
            height: auto;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            filter: brightness(1.1); /* Make the image pop */
        }

        .input-group {
            margin-bottom: 25px; /* More space between input groups */
            border-bottom: 1px solid rgba(255, 255, 255, 0.2); /* Softer divider */
            padding-bottom: 15px;
        }
        .input-group:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .input-group .label {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 10px;
        }

        .input-field-wrapper {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-top: 10px;
            height: 50px; /* Taller input fields */
            background: rgba(255, 255, 255, 0.3); /* Lighter background for input */
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            padding: 0 15px;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .input-field-wrapper input {
            flex: 1;
            border: none;
            outline: none;
            background: transparent;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            color: #0A4A3C; /* Dark green text for input */
            font-weight: 600;
        }
        .input-field-wrapper input::placeholder {
            color: rgba(10, 74, 60, 0.7); /* Lighter placeholder */
        }

        .confirm-button {
            margin-top: 30px;
            height: 55px;
            background: linear-gradient(90deg, #FFD700 0%, #FFA500 100%); /* Gold button */
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .confirm-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(255, 215, 0, 0.4);
        }
        .confirm-button:active {
            transform: translateY(0);
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.2);
        }

        /* --- Responsive Adjustments --- */
        @media (max-width: 500px) {
            .main-container {
                border-radius: 0;
                box-shadow: none;
                padding-bottom: 20px;
            }
            .header {
                padding: 40px 15px 15px;
            }
            .header-title {
                font-size: 24px;
            }
            .bank-account-box {
                width: calc(100% - 30px);
                margin-left: 15px;
                margin-right: 15px;
                padding: 25px 15px;
            }
            .bank-account-box .card-image img {
                width: 280px; /* Smaller image on mobile */
            }
            .input-group {
                margin-bottom: 20px;
                padding-bottom: 10px;
            }
            .input-group .label {
                font-size: 13px;
            }
            .input-field-wrapper {
                height: 45px;
            }
            .input-field-wrapper input {
                font-size: 15px;
            }
            .confirm-button {
                height: 50px;
                font-size: 18px;
            }
        }
    </style>
</head>
<body class="uni-body pages-sys-user-bankAccount">
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="main-container">
        <div class="header">
            <div class="back-button" onclick="window.history.back()">
                <img src="static/yunta/image/device/left.png" alt="Voltar">
            </div>
            <div class="header-title">Minha Conta Bancária</div>
        </div>

        <div class="bank-account-box">
            <div class="card-image">
                <img src="static/yunta/image/user/h-b.png" alt="Card Illustration">
            </div>

            <div class="input-form-section">
                <div class="input-group">
                    <div class="label">Nome real</div>
                    <div class="input-field-wrapper">
                        <input id="nome_completo" maxlength="140" placeholder="Por favor, insira seu nome completo" autocomplete="off" type="text">
                    </div>
                </div>
                <div class="input-group">
                    <div class="label">Número PIX (CPF)</div>
                    <div class="input-field-wrapper">
                        <input id="chave_pix" maxlength="140" placeholder="Por favor, insira a chave PIX" autocomplete="off" type="text">
                    </div>
                </div>
                <div class="input-group">
                    <div class="label">CPF</div>
                    <div class="input-field-wrapper">
                        <input id="cpf" maxlength="140" placeholder="Por favor, insira o CPF" autocomplete="off" type="text">
                    </div>
                </div>
            </div>

            <div id="bankAccountBtn" class="confirm-button">
                Confirmar
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const nomeCompletoInput = document.getElementById("nome_completo");
            const chavePixInput = document.getElementById("chave_pix");
            const cpfInput = document.getElementById("cpf");
            const bankAccountBtn = document.getElementById("bankAccountBtn");

            /**
             * Fetches bank account data and updates the form.
             * Hides the "Confirmar" button if an account already exists.
             */
            async function fetchBankAccount() {
                try {
                    const response = await fetch("servidor/bank");
                    const data = await response.json();

                    if (data.status === "sucesso") {
                        // Populate fields
                        nomeCompletoInput.value = data.dados.nome_completo || "";
                        chavePixInput.value = data.dados.chave_pix || "";
                        cpfInput.value = data.dados.cpf || "";

                        // Make fields read-only
                        nomeCompletoInput.readOnly = true;
                        chavePixInput.readOnly = true;
                        cpfInput.readOnly = true;

                        bankAccountBtn.style.display = "none"; // Hide button if account exists
                    } else {
                        // Ensure fields are editable if no data
                        nomeCompletoInput.readOnly = false;
                        chavePixInput.readOnly = false;
                        cpfInput.readOnly = false;
                        bankAccountBtn.style.display = "flex"; // Show button if no account (using flex for styling)
                    }
                } catch (error) {
                    console.error("Erro ao buscar carteira:", error);
                    // In case of error, ensure button is visible and fields are editable
                    nomeCompletoInput.readOnly = false;
                    chavePixInput.readOnly = false;
                    cpfInput.readOnly = false;
                    bankAccountBtn.style.display = "flex";
                }
            }

            /**
             * Handles saving the bank account data.
             */
            bankAccountBtn.addEventListener("click", async function () {
                const nomeCompleto = nomeCompletoInput.value.trim();
                const chavePix = chavePixInput.value.trim();
                const cpf = cpfInput.value.trim();

                if (!nomeCompleto || !chavePix || !cpf) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Atenção!',
                        text: 'Todos os campos são obrigatórios!',
                        position: 'center',
                        showConfirmButton: true
                    });
                    return;
                }

                // Basic CPF validation (adjust as needed for stronger validation)
                if (cpf.length !== 11 || !/^\d+$/.test(cpf)) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro!',
                        text: 'CPF inválido. Por favor, insira 11 dígitos numéricos.',
                        position: 'center',
                        showConfirmButton: true
                    });
                    return;
                }

                try {
                    const response = await fetch("servidor/bank", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ nome_completo: nomeCompleto, chave_pix: chavePix, cpf: cpf })
                    });
                    const data = await response.json();

                    Swal.fire({
                        icon: data.status === "sucesso" ? 'success' : 'error',
                        title: 'Resposta',
                        text: data.mensagem,
                        position: 'center',
                        showConfirmButton: true
                    });

                    if (data.status === "sucesso") {
                        // After successful save, make fields read-only and hide the button
                        nomeCompletoInput.readOnly = true;
                        chavePixInput.readOnly = true;
                        cpfInput.readOnly = true;
                        bankAccountBtn.style.display = "none";
                    }
                } catch (error) {
                    console.error("Erro ao enviar dados:", error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro!',
                        text: 'Ocorreu um erro ao salvar os dados. Tente novamente.',
                        position: 'center',
                        showConfirmButton: true
                    });
                }
            });

            // Call the function immediately and then every second
            fetchBankAccount();
            setInterval(fetchBankAccount, 1000); // Poll for updates
        });
    </script>
</body>
</html>