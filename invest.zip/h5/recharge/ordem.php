<?php
session_start();

// Define o arquivo de log no mesmo diretório do script
define('LOG_FILE', __DIR__ . '/pix_payment_debug.log');

/**
 * Função para registrar mensagens no arquivo de log.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_log($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(LOG_FILE, $log_entry, FILE_APPEND);
}

write_log("Início da requisição. URL: " . $_SERVER['REQUEST_URI'], 'DEBUG');

// --- Verificação de Autenticação do Usuário ---
if (!isset($_SESSION['user_id'])) {
    write_log("Usuário não autenticado. Redirecionando ou retornando erro JSON.", 'INFO');
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(["error" => "Usuário não autenticado"]);
        exit;
    } else {
        header('Location: /login.php');
        exit;
    }
}

$uid = $_SESSION['user_id'];
write_log("Usuário autenticado. UID: " . $uid, 'DEBUG');

include('../../servidor/database.php');

if (!$conn) {
    write_log("Erro de conexão com o banco de dados: " . mysqli_connect_error(), 'ERROR');
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(["error" => "Erro interno: Não foi possível conectar ao banco de dados."]);
    } else {
        die("Erro fatal: Não foi possível conectar ao banco de dados. Por favor, tente novamente mais tarde.");
    }
    exit;
}
write_log("Conexão com o banco de dados estabelecida.", 'DEBUG');

// --- Lógica de Verificação de Status para Requisições AJAX ---
if (isset($_GET['action']) && $_GET['action'] === 'check_status' && isset($_GET['external_id'])) {
    header('Content-Type: application/json');

    $external_id = $_GET['external_id'];
    write_log("Requisição de status recebida. External ID: " . $external_id, 'INFO');

    $stmt = $conn->prepare("SELECT amount, status FROM depositos WHERE user_id = ? AND external_id = ?");
    if (!$stmt) {
        write_log("Erro ao preparar statement para consulta local de depósito: " . $conn->error, 'ERROR');
        echo json_encode(["error" => "Erro interno ao consultar depósito."]);
        exit;
    }
    $stmt->bind_param("is", $uid, $external_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $deposit_info = $result->fetch_assoc();
    $stmt->close();

    if (!$deposit_info) {
        write_log("Transação (ID externo: " . $external_id . ") não encontrada no DB local para o UID: " . $uid, 'WARNING');
        echo json_encode(["error" => "Transação não encontrada ou não pertence ao usuário."]);
        exit;
    }

    if ($deposit_info['status'] === 'pago') {
        write_log("Transação (ID externo: " . $external_id . ") já marcada como 'pago' no DB local.", 'INFO');
        echo json_encode(["status" => "PAID", "message" => "Transação já foi paga."]);
        exit;
    } else {
        echo json_encode(["status" => "PENDING", "message" => "Aguardando pagamento..."]);
        exit;
    }
}

write_log("Requisição de página completa. Iniciando geração do QR Code Pix.", 'INFO');

$valor = isset($_GET['g']) ? floatval($_GET['g']) : 0.00;
if ($valor <= 0) {
    write_log("Valor de recarga inválido: " . $valor, 'ERROR');
    die("Erro: Valor de recarga inválido. Por favor, especifique um valor maior que zero.");
}
write_log("Valor da recarga solicitado: R$ " . number_format($valor, 2, ',', '.'), 'INFO');

// --- MUDANÇA AQUI: Busca as credenciais da BSPayBR do banco de dados ---
$stmt = $conn->prepare("SELECT client_id, client_secret, urlnoty FROM gateway_bspaybr WHERE id = 1 LIMIT 1");
$stmt->execute();
$gatewayCreds = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$gatewayCreds || empty($gatewayCreds['client_id']) || empty($gatewayCreds['client_secret'])) {
    write_log("Erro: Credenciais BSPayBR não configuradas no banco de dados.", 'ERROR');
    die("Erro interno: As credenciais de pagamento não foram configuradas corretamente.");
}

$CLIENT_ID = $gatewayCreds['client_id'];
$CLIENT_SECRET = $gatewayCreds['client_secret'];
$CALLBACK_URL = $gatewayCreds['urlnoty'];

// --- FIM DA MUDANÇA DE BUSCA DE CREDENCIAIS ---

// --- INÍCIO DA LÓGICA DE REUTILIZAÇÃO DA SESSÃO ---
$PIX_SESSION_KEY = 'pix_gerado_' . $uid;
$tempo_expiracao = 60 * 15; // 15 minutos em segundos

$pix_dados = $_SESSION[$PIX_SESSION_KEY] ?? null;

if ($pix_dados && (time() - $pix_dados['timestamp'] < $tempo_expiracao) && $pix_dados['valor'] == $valor) {
    $valor_pix = $pix_dados['valor'];
    $external_id = $pix_dados['external_id'];
    $qrcode = $pix_dados['qrcode'];
    $expira_em = $pix_dados['timestamp'] + $tempo_expiracao;
    write_log("Reutilizando PIX da sessão para external_id: " . $external_id, 'INFO');
} else {
    $valor_pix = $valor;

    // Dados do usuário (você pode buscar do banco se tiver)
    $user_name = 'João da Silva'; // Pode ser buscado do DB pelo UID
    $user_cpf = '12345678901'; // Pode ser buscado do DB pelo UID

    $external_id_interno = md5(uniqid("user{$uid}_", true));

    // Payload para BSPayBR
    $payload = [
        'client_id' => $CLIENT_ID,
        'client_secret' => $CLIENT_SECRET,
        'nome' => $user_name,
        'cpf' => $user_cpf,
        'valor' => $valor_pix,
        'descricao' => 'Depósito na plataforma',
        'urlnoty' => $CALLBACK_URL
    ];

    write_log("Payload para API BSPayBR: " . json_encode($payload), 'DEBUG');

    // Requisição para BSPayBR
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://bspaybr.com/v3/pix/qrcode',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($payload),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
            'User-Agent: SeuApp/1.0'
        ]
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    write_log("Resposta da API BSPayBR (código HTTP: $httpCode): " . $response, 'DEBUG');

    $resposta = json_decode($response, true);

    if ($httpCode !== 200 || !isset($resposta['qrcode']) || !isset($resposta['external_id'])) {
        $error_message = $resposta['message'] ?? 'Erro desconhecido';
        write_log("Erro: QR Code ou external_id não encontrados na resposta da API BSPayBR. Erro: " . $error_message, 'ERROR');
        die("❌ Erro ao gerar QR Code PIX: " . $error_message . ". Por favor, tente novamente mais tarde.");
    }

    $qrcode = $resposta['qrcode'];
    $external_id = $resposta['external_id'];
    $transaction_id = $resposta['transactionId'];
    $expira_em = time() + $tempo_expiracao;

    // Salvar no banco de dados
    $stmt = $conn->prepare("INSERT INTO depositos (user_id, transaction_no, external_id, amount, descricao, status) VALUES (?, ?, ?, ?, ?, 'pendente')");
    if (!$stmt) {
        write_log("Erro ao preparar statement para inserir depósito: " . $conn->error, 'ERROR');
        die("Erro interno: Não foi possível preparar a inserção do depósito.");
    }
    $stmt->bind_param("issds", $uid, $transaction_id, $external_id, $valor_pix, $payload['descricao']);
    if ($stmt->execute()) {
        write_log("Depósito inicial salvo no DB com status 'pendente'. External ID: " . $external_id . ", Transaction ID: " . $transaction_id, 'INFO');
    } else {
        write_log("Erro ao inserir depósito no banco de dados. UID: " . $uid . ", External ID: " . $external_id . " - Erro: " . $stmt->error, 'ERROR');
        die("Erro interno ao salvar depósito. Por favor, tente novamente.");
    }
    $stmt->close();
    
    // Salvar na sessão
    $_SESSION[$PIX_SESSION_KEY] = [
        'valor' => $valor_pix,
        'external_id' => $external_id,
        'qrcode' => $qrcode,
        'timestamp' => time()
    ];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>PIX Gerado</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* MUDANÇA: Estilo para o tema verde */
        :root {
            --primary-color: #00e880;
            --secondary-color: #121419;
            --dark-background: #0e1015;
            --card-background: #1e1f29;
            --text-color: #fff;
            --subtle-text-color: #ccc;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--dark-background);
            color: var(--text-color);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .main-content {
            max-width: 600px;
            width: 100%;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header-deposito {
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            margin-bottom: 20px;
        }
        
        .back-btn {
            position: absolute;
            left: 0;
            color: var(--text-color);
            font-size: 24px;
            text-decoration: none;
        }

        .container {
            background: var(--secondary-color);
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
            padding: 30px;
            text-align: center;
        }

        .title {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .subtitle {
            font-size: 16px;
            color: var(--subtle-text-color);
            margin-bottom: 20px;
        }

        .timer {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 20px;
        }

        .qrcode {
            background: var(--text-color);
            padding: 10px;
            border-radius: 8px;
            display: inline-block;
            margin-bottom: 20px;
        }

        .qrcode img {
            display: block;
            max-width: 200px;
            height: auto;
        }

        textarea {
            width: 100%;
            background: var(--card-background);
            border: 1px solid #333;
            color: var(--subtle-text-color);
            padding: 10px;
            border-radius: 8px;
            resize: none;
            font-size: 14px;
            margin-bottom: 15px;
            box-sizing: border-box;
            -webkit-user-select: all;
            -moz-user-select: all;
            -ms-user-select: all;
            user-select: all;
        }

        .btn-copiar {
            background-color: var(--primary-color);
            color: var(--secondary-color);
            border: none;
            padding: 15px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            width: 100%;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .btn-copiar:hover {
            background-color: #00c26d;
        }

        .msg-copiado {
            margin-top: 10px;
            color: var(--primary-color);
        }

        .tutorial {
            background: var(--card-background);
            border-radius: 8px;
            padding: 20px;
            margin-top: 20px;
            text-align: left;
        }

        .tutorial h3 {
            font-size: 18px;
            margin-top: 0;
            margin-bottom: 15px;
            color: var(--primary-color);
            text-align: center;
        }

        .passo {
            display: flex;
            align-items: flex-start;
            margin-bottom: 10px;
            line-height: 1.5;
        }
        
        .passo span {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            background-color: var(--primary-color);
            color: var(--secondary-color);
            border-radius: 50%;
            font-weight: bold;
            font-size: 14px;
            margin-right: 10px;
            flex-shrink: 0;
        }
        
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            display: none;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            color: var(--text-color);
            font-size: 24px;
            text-align: center;
            z-index: 1000;
        }
        .checkmark__circle {
            stroke-dasharray: 166;
            stroke-dashoffset: 166;
            stroke-width: 2;
            stroke-miterlimit: 10;
            stroke: var(--primary-color);
            fill: none;
            animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
        }
        .checkmark {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: block;
            stroke-width: 2;
            stroke: var(--text-color);
            stroke-miterlimit: 10;
            margin: 10% auto;
            box-shadow: inset 0 0 0 var(--primary-color);
            animation: fill 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
        }
        .checkmark__check {
            transform-origin: 50% 50%;
            stroke-dasharray: 48;
            stroke-dashoffset: 48;
            animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
        }
        @keyframes stroke {
            100% { stroke-dashoffset: 0; }
        }
        @keyframes fill {
            100% { box-shadow: inset 0 0 0 30px var(--primary-color); }
        }
        @keyframes scale {
            0%, 100% { transform: none; }
            50% { transform: scale3d(1.1, 1.1, 1); }
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="header-deposito">
            <a href="/my" class="back-btn"><i class="fas fa-arrow-left"></i></a>
            <div class="title">PIX gerado</div>
        </div>

        <div class="container">
            <div class="title">Depósito de R$ <?= number_format($valor_pix, 2, ',', '.') ?></div>
            <div class="subtitle">Escaneie o QR Code ou copie o código abaixo:</div>
            
            <div class="timer" id="countdown"></div>

            <div class="qrcode">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=<?= urlencode($qrcode) ?>" alt="QR Code PIX">
            </div>
            <textarea id="codigoPix" rows="4" readonly><?= htmlspecialchars($qrcode) ?></textarea>
            <button class="btn-copiar" onclick="copiarCodigo()">Copiar código PIX</button>
            <div class="msg-copiado" id="mensagemCopiado" style="display:none;">Código copiado com sucesso!</div>
            <div class="tutorial">
                <h3>Como pagar com PIX:</h3>
                <div class="passo"><span>1</span>Abra seu aplicativo do banco</div>
                <div class="passo"><span>2</span>Escolha a opção **PIX**</div>
                <div class="passo"><span>3</span>Selecione **Pix Copia e Cola**</div>
                <div class="passo"><span>4</span>Cole o código que você copiou acima</div>
                <div class="passo"><span>5</span>Confirme o valor e finalize o pagamento</div>
            </div>
            <div id="statusPagamento" style="text-align:center; margin-top: 15px; color: #00e880;"></div>
        </div>
    </div>

    <div class="overlay" id="successOverlay">
        <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
            <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
            <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
        </svg>
        <p id="successMessage">Pagamento confirmado!</p>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <script>
        function copiarCodigo() {
            const textarea = document.getElementById("codigoPix");
            textarea.select();
            textarea.setSelectionRange(0, 99999);
            document.execCommand("copy");
            const msg = document.getElementById("mensagemCopiado");
            msg.style.display = "block";
            setTimeout(() => msg.style.display = "none", 3000);
        }
        
        const externalId = "<?= $external_id ?>";
        const statusMsg = document.getElementById("statusPagamento");
        const successOverlay = document.getElementById('successOverlay');
        const successMessage = document.getElementById('successMessage');
        let pollingInterval;

        function verificarStatus() {
            fetch('<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>?action=check_status&external_id=' + externalId)
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'PAID') {
                        clearInterval(pollingInterval);
                        successOverlay.style.display = 'flex';
                        
                        // LÓGICA DE REDIRECIONAMENTO COM CONTADOR
                        let countdown = 5;
                        successMessage.innerHTML = `Pagamento confirmado! Você será redirecionado em ${countdown} segundos.`;
                        const redirectInterval = setInterval(() => {
                            countdown--;
                            successMessage.innerHTML = `Pagamento confirmado! Você será redirecionado em ${countdown} segundos.`;
                            if (countdown <= 0) {
                                clearInterval(redirectInterval);
                                window.location.href = '/my';
                            }
                        }, 1000);
                    } else if (data.status === 'PENDING') {
                        statusMsg.innerHTML = '⏳ Aguardando confirmação do pagamento...';
                    } else {
                        statusMsg.innerHTML = '⚠️ Status desconhecido.';
                    }
                })
                .catch(() => statusMsg.innerHTML = '❌ Erro ao verificar status.');
        }

        verificarStatus();
        pollingInterval = setInterval(verificarStatus, 5000);

        const expirationTime = <?= $expira_em ?>;
        const countdownElement = document.getElementById('countdown');

        function updateCountdown() {
            const now = Math.floor(Date.now() / 1000);
            const remaining = expirationTime - now;

            if (remaining <= 0) {
                countdownElement.textContent = 'Tempo esgotado!';
                clearInterval(countdownInterval);
                statusMsg.innerHTML = 'O PIX expirou. Por favor, gere um novo depósito.';
            } else {
                const minutes = Math.floor(remaining / 60);
                const seconds = remaining % 60;
                countdownElement.textContent = `Expira em: ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }
        updateCountdown();
        const countdownInterval = setInterval(updateCountdown, 1000);
    </script>
</body>
</html>