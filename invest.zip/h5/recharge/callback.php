<?php

include('../../servidor/database.php');

$response = json_decode(file_get_contents('php://input'), true);
//file_put_contents('lo2g.json', json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND);

if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["message" => "Erro ao decodificar JSON: " . json_last_error_msg()]);
    exit();
}

if (isset($response['reference_code']) && isset($response['status'])) {
    $plat_order_no = $response['reference_code'];
    $amount = (float)$response['value_cents'] / 100;


    $stmt = $conn->prepare("SELECT id, user_id, status FROM depositos WHERE transaction_no = ?");
    $stmt->bind_param("s", $plat_order_no);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $deposito = $result->fetch_assoc();
        $deposito_id = $deposito['id'];
        $user_id = $deposito['user_id'];
        $status = $deposito['status'];

        if ($status === "pendente") {
            $update_stmt = $conn->prepare("UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?");
            $update_stmt->bind_param("di", $amount, $user_id);

            if ($update_stmt->execute()) {
                $update_status_stmt = $conn->prepare("UPDATE depositos SET status = 'aprovado' WHERE id = ?");
                $update_status_stmt->bind_param("i", $deposito_id);
                
                $sqlRegistro = "INSERT INTO transacoes (usuario_id, tipo, valor, descricao) VALUES (?, 'saldo', ?, '  recarga brl ')";
                $stmtRegistro = $conn->prepare($sqlRegistro);
                if (!$stmtRegistro) throw new Exception('Erro ao preparar o registro de transação: ' . $conn->error);
                
                $stmtRegistro->bind_param("id", $user_id, $amount);
                if (!$stmtRegistro->execute()) throw new Exception('Erro ao registrar a transação: ' . $stmtRegistro->error);
                $stmtRegistro->close();

                if ($update_status_stmt->execute()) {
                    echo "ok";
                } else {
                    echo json_encode(["status" => "fail"]);
                }
                $update_status_stmt->close();
            } else {
                echo json_encode(["status" => "fail"]);
            }
            $update_stmt->close();
        } else {
            echo json_encode(["status" => "fail"]);
        }
    } else {
        echo json_encode(["status" => "fail"]);
    }
    $stmt->close();
} else {
    echo json_encode(["status" => "fail"]);
}

$conn->close();

?>