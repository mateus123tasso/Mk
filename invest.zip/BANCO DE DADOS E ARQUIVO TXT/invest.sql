-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 18/09/2025 às 14:07
-- Versão do servidor: 11.8.3-MariaDB-log
-- Versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `u700037883_invest`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `administrador`
--

CREATE TABLE `administrador` (
  `id` int(11) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `administrador`
--

INSERT INTO `administrador` (`id`, `usuario`, `senha`) VALUES
(1, 'admin@eu.com', '$2a$12$HfCQjZLgm9JIkyCO58zIluoZ3QDb6TzfgILLQf50RthA8h0AYuvBO');

-- --------------------------------------------------------

--
-- Estrutura para tabela `carteiras`
--

CREATE TABLE `carteiras` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) NOT NULL,
  `chave_pix` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nome_completo` varchar(255) NOT NULL,
  `data_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `carteiras`
--

INSERT INTO `carteiras` (`id`, `uid`, `chave_pix`, `cpf`, `nome_completo`, `data_registro`) VALUES
(1, '1', '11261678940', '11261678940', 'João Carlos tome', '2025-09-17 00:46:58');

-- --------------------------------------------------------

--
-- Estrutura para tabela `checkins`
--

CREATE TABLE `checkins` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `data_checkin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `plano_id` int(11) DEFAULT NULL,
  `data_compra` datetime DEFAULT current_timestamp(),
  `ultima_renda_creditada_at` timestamp NULL DEFAULT NULL,
  `proximo_rendimento` datetime DEFAULT NULL,
  `vencimento` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'rodando',
  `ultimo_credito` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `configuracoes`
--

CREATE TABLE `configuracoes` (
  `id` int(11) NOT NULL,
  `telegram` varchar(255) NOT NULL,
  `whatsapp` varchar(255) NOT NULL,
  `saque_minimo` varchar(255) NOT NULL,
  `recarga_minima` varchar(255) NOT NULL,
  `taxa_saque` varchar(255) NOT NULL,
  `lv1` varchar(255) NOT NULL,
  `lv2` varchar(255) NOT NULL,
  `lv3` varchar(255) NOT NULL,
  `saque_diario_max` decimal(10,2) DEFAULT 0.00,
  `saque_maximo_por_transacao` decimal(10,2) DEFAULT 3000.00,
  `permitir_saque_24h` tinyint(1) DEFAULT 0,
  `site_name` varchar(255) DEFAULT 'fany-ai',
  `site_title` varchar(255) DEFAULT 'fany-ai plataform premium investiment oficial',
  `banner_image` text DEFAULT 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZuUfV_bkS6-CX7poJDZUspb6tMDShVV1qimsYCRom9GpNvN1rbaeuklov&s=10',
  `favicon` varchar(255) DEFAULT 'static/yunta/favicon.png',
  `checkin_title` varchar(255) DEFAULT 'Login Diário Premium',
  `checkin_subtitle` varchar(255) DEFAULT 'Ganhe R$ 1,00 por check-in diário',
  `checkin_button` varchar(255) DEFAULT 'Entrar',
  `ticker_message_1` text DEFAULT 'Bem-vindo ao futuro dos investimentos com fany-ai',
  `ticker_message_2` text DEFAULT 'Novos planos premium disponíveis com retornos garantidos',
  `ticker_message_3` text DEFAULT 'Promoções especiais por tempo limitado - Aproveite agora!',
  `modal_title` varchar(255) DEFAULT 'O que a fany-ai oferece?',
  `modal_welcome` text DEFAULT 'Bem-vindo à fany-ai',
  `modal_bonus_register` text DEFAULT 'Cadastre-se com sucesso e ganhe 5 R$',
  `modal_daily_login` text DEFAULT 'Entre e faça login diariamente para receber 1 R$',
  `modal_commission` text DEFAULT '31% de comissão de bônus alto está esperando por você',
  `modal_telegram` text DEFAULT 'Siga o canal oficial no Telegram para últimas informações',
  `checkin_success_title` varchar(255) DEFAULT 'Check-in Realizado',
  `checkin_success_message` text DEFAULT 'Você recebeu R$ 1,00 de bônus diário!'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `configuracoes`
--

INSERT INTO `configuracoes` (`id`, `telegram`, `whatsapp`, `saque_minimo`, `recarga_minima`, `taxa_saque`, `lv1`, `lv2`, `lv3`, `saque_diario_max`, `saque_maximo_por_transacao`, `permitir_saque_24h`, `site_name`, `site_title`, `banner_image`, `favicon`, `checkin_title`, `checkin_subtitle`, `checkin_button`, `ticker_message_1`, `ticker_message_2`, `ticker_message_3`, `modal_title`, `modal_welcome`, `modal_bonus_register`, `modal_daily_login`, `modal_commission`, `modal_telegram`, `checkin_success_title`, `checkin_success_message`) VALUES
(1, 'https://t.me/+wqmZUKtNNq8zMDNh', 'https://chat.whatsapp.com/BpjBCpuqVGr7LYifU6Abf1?mode=ems_copy_c', '1', '1', '10', '10', '10', '3', 1000.00, 100.00, 1, 'fany-ai', 'fany-ai plataform premium investiment oficial', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZuUfV_bkS6-CX7poJDZUspb6tMDShVV1qimsYCRom9GpNvN1rbaeuklov&s=10', 'static/yunta/favicon.png', 'Login Diário Premium', 'Ganhe R$ 1,00 por check-in diário', 'Entrar', 'Bem-vindo ao futuro dos investimentos com fany-ai', 'Novos planos premium disponíveis com retornos garantidos', 'Promoções especiais por tempo limitado - Aproveite agora!', 'O que a fany-ai oferece?', 'Bem-vindo à fany-ai', 'Cadastre-se com sucesso e ganhe 5 R$', 'Entre e faça login diariamente para receber 1 R$', '31% de comissão de bônus alto está esperando por você', 'Siga o canal oficial no Telegram para últimas informações', 'Check-in Realizado Com Sucesso', 'Você recebeu R$ 1,00 de bônus diário!'),
(2, 'https://t.me/seu_canal_telegram', 'https://wa.me/5511999999999', '50.00', '10.00', '5.00', '10.00', '5.00', '3.00', 1000.00, 3000.00, 1, 'fany-ai', 'fany-ai plataform premium investiment oficial', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZuUfV_bkS6-CX7poJDZUspb6tMDShVV1qimsYCRom9GpNvN1rbaeuklov&s=10', 'static/yunta/favicon.png', 'Login Diário Premium', 'Ganhe R$ 1,00 por check-in diário', 'Entrar', 'Bem-vindo ao futuro dos investimentos com fany-ai', 'Novos planos premium disponíveis com retornos garantidos', 'Promoções especiais por tempo limitado - Aproveite agora!', 'O que a fany-ai oferece?', 'Bem-vindo à fany-ai', 'Cadastre-se com sucesso e ganhe 5 R$', 'Entre e faça login diariamente para receber 1 R$', '31% de comissão de bônus alto está esperando por você', 'Siga o canal oficial no Telegram para últimas informações', 'Check-in Realizado', 'Você recebeu R$ 1,00 de bônus diário!');

-- --------------------------------------------------------

--
-- Estrutura para tabela `depositos`
--

CREATE TABLE `depositos` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `transaction_no` varchar(255) NOT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `order_no` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(255) NOT NULL DEFAULT 'pendente',
  `data_confirmacao` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `gateway_bspaybr`
--

CREATE TABLE `gateway_bspaybr` (
  `id` int(11) NOT NULL,
  `client_id` varchar(255) NOT NULL,
  `client_secret` varchar(255) NOT NULL,
  `urlnoty` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `gateway_bspaybr`
--

INSERT INTO `gateway_bspaybr` (`id`, `client_id`, `client_secret`, `urlnoty`) VALUES
(1, 'aqui', 'aqui', 'https://meusite.com/webhook_bspaybr.php');

-- --------------------------------------------------------

--
-- Estrutura para tabela `niveis_vip`
--

CREATE TABLE `niveis_vip` (
  `id` int(11) NOT NULL,
  `nivel` int(11) NOT NULL,
  `investimento_minimo` decimal(10,2) NOT NULL,
  `imagem` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `planos`
--

CREATE TABLE `planos` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `receitaTotal` decimal(10,2) NOT NULL,
  `receitaDiaria` decimal(10,2) NOT NULL DEFAULT 0.00,
  `diasDeReceita` int(11) NOT NULL,
  `limite` int(11) NOT NULL DEFAULT 1,
  `vip` varchar(50) NOT NULL,
  `imagem` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT 'static/yunta/image/default_product.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `planos`
--

INSERT INTO `planos` (`id`, `nome`, `foto`, `preco`, `receitaTotal`, `receitaDiaria`, `diasDeReceita`, `limite`, `vip`, `imagem`, `image_url`) VALUES
(37, 'FANY-AI', '', 30.00, 60.00, 1.80, 34, 99, '', NULL, 'static/uploads/planos/plan_689b58a0bcf33.jpg'),
(38, 'FANY-AI 2', '', 100.00, 200.00, 6.20, 34, 55, '', NULL, 'static/uploads/planos/plan_689b59bc15192.jpeg'),
(39, 'FANY-AI 3', '', 500.00, 1000.00, 34.00, 34, 25, '', NULL, 'static/uploads/planos/plan_689b5a2228423.jpeg'),
(53, 'GOLDBOT-1', '', 70.00, 120.00, 8.00, 15, 3, '', NULL, 'static/uploads/planos/plan_68b26a097a71d.jpeg'),
(54, 'GOLDBOT-2', '', 120.00, 180.00, 10.00, 18, 3, '', NULL, 'static/uploads/planos/plan_68b26a5fbcee8.jpeg'),
(55, 'GOLDBOT-4', '', 240.00, 325.00, 25.00, 13, 3, '', NULL, 'static/uploads/planos/plan_68b26a9463f8b.jpeg'),
(56, 'GOLDBOT-4', '', 300.00, 400.00, 50.00, 8, 3, '', NULL, 'static/uploads/planos/plan_68b26aeee0660.jpeg'),
(58, 'Secret edition1', '', 75.00, 105.00, 10.50, 10, 5, '', NULL, 'static/uploads/planos/plan_68b30245b0852.jpeg'),
(59, 'Secret edtion2 ', '', 150.00, 225.00, 15.00, 15, 5, '', NULL, 'static/uploads/planos/plan_68b302bd6ca76.jpeg'),
(60, '7 DE SETEMBRO-1', '', 70.00, 120.00, 7.00, 17, 7, '', NULL, 'static/uploads/planos/plan_68b513c8d72ab.jpeg'),
(61, '7 DE SETEMBRO-2', '', 120.00, 200.00, 14.50, 15, 7, '', NULL, 'static/uploads/planos/plan_68b514214e75e.jpeg'),
(62, '7 DE SETEMBRO-3', '', 210.00, 380.00, 24.00, 16, 7, '', NULL, 'static/uploads/planos/plan_68b5147deb7d8.jpeg'),
(63, '7 DE SETEMBRO-4', '', 250.00, 400.00, 28.00, 14, 7, '', NULL, 'static/uploads/planos/plan_68b514d46785e.jpeg'),
(64, '7 DE SETEMBRO-5', '', 500.00, 850.00, 50.00, 17, 7, '', NULL, 'static/uploads/planos/plan_68b5156c445be.jpeg'),
(65, '7 DE SETEMBRO-6', '', 800.00, 1600.00, 160.00, 10, 7, '', NULL, 'static/uploads/planos/plan_68b515c06e8fd.jpeg'),
(66, '7 DE SETEMBRO-7', '', 2000.00, 4000.00, 400.00, 10, 7, '', NULL, 'static/uploads/planos/plan_68b516144ab51.jpeg');

-- --------------------------------------------------------

--
-- Estrutura para tabela `rendimentos_diarios`
--

CREATE TABLE `rendimentos_diarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `plano_id` int(11) NOT NULL,
  `compra_id` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data_registro` datetime NOT NULL DEFAULT current_timestamp(),
  `data` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `transacoes`
--

CREATE TABLE `transacoes` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `tipo` enum('compra','produto','checkin','comissao','saldo') NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data_transacao` datetime NOT NULL DEFAULT current_timestamp(),
  `descricao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `transacoes_pix`
--

CREATE TABLE `transacoes_pix` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `external_id` varchar(255) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'pendente',
  `criado_em` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `transacoes_retirada`
--

CREATE TABLE `transacoes_retirada` (
  `id` int(11) NOT NULL,
  `bspaybr_payment_id` varchar(255) DEFAULT NULL,
  `external_id` varchar(255) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `api` varchar(255) DEFAULT NULL,
  `bspaybr_reference` varchar(255) DEFAULT NULL,
  `data_envio_pixup` timestamp NULL DEFAULT NULL,
  `data_envio_bspaybr` datetime DEFAULT NULL,
  `valor_retirada` decimal(10,2) NOT NULL,
  `taxa_cobrada` decimal(10,2) NOT NULL,
  `total_recebido` decimal(10,2) NOT NULL,
  `chave_pix` varchar(255) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `nome_completo` varchar(255) NOT NULL,
  `data_transacao` datetime NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pendente',
  `saldo_anterior` decimal(10,2) NOT NULL,
  `saldo_atual` decimal(10,2) NOT NULL,
  `data_cancelamento` datetime DEFAULT NULL,
  `data_confirmacao` datetime DEFAULT NULL,
  `pixup_reference` varchar(255) DEFAULT NULL,
  `pixup_external_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `transacoes_retirada`
--

INSERT INTO `transacoes_retirada` (`id`, `bspaybr_payment_id`, `external_id`, `usuario_id`, `api`, `bspaybr_reference`, `data_envio_pixup`, `data_envio_bspaybr`, `valor_retirada`, `taxa_cobrada`, `total_recebido`, `chave_pix`, `cpf`, `nome_completo`, `data_transacao`, `status`, `saldo_anterior`, `saldo_atual`, `data_cancelamento`, `data_confirmacao`, `pixup_reference`, `pixup_external_id`) VALUES
(1, 'e147e4745aa4d919e65a260398agk89yq', 'saque_1', 1, 'Site/User Request', NULL, '2025-09-17 03:41:43', NULL, 1.11, 0.11, 1.00, '11261678940', '11261678940', 'João Carlos tome', '2025-09-17 03:41:02', 'pago', 3.57, 2.46, NULL, '2025-09-17 03:41:45', NULL, NULL),
(2, 'e6eb1730fac934b31ecb1f0fdc0uapdkn', 'saque_2', 1, 'Site/User Request', NULL, '2025-09-17 04:03:36', NULL, 1.11, 0.11, 1.00, '11261678940', '11261678940', 'João Carlos tome', '2025-09-17 03:49:39', 'pago', 2.46, 1.35, NULL, '2025-09-17 04:03:38', NULL, NULL),
(3, 'e54c28516aca51af36359678e932trmha', 'saque_3', 1, 'Site/User Request', NULL, '2025-09-17 04:04:54', NULL, 1.11, 0.11, 1.00, '11261678940', '11261678940', 'João Carlos tome', '2025-09-17 04:04:36', 'pago', 1.35, 0.24, NULL, '2025-09-17 04:04:56', NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `cpf` varchar(14) DEFAULT NULL,
  `nome_completo` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `saldo_recarga` decimal(10,2) DEFAULT 5.00,
  `saldo_retirada` decimal(10,2) DEFAULT 0.00,
  `id_patrocinador` int(11) DEFAULT NULL,
  `codigo_convite` varchar(50) DEFAULT NULL,
  `saldo_principal` decimal(10,2) DEFAULT 0.00,
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_investido` decimal(10,2) DEFAULT 0.00,
  `total_sacado_hoje` decimal(10,2) DEFAULT 0.00,
  `data_ultimo_saque_diario` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `carteiras`
--
ALTER TABLE `carteiras`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `checkins`
--
ALTER TABLE `checkins`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `depositos`
--
ALTER TABLE `depositos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `external_id` (`external_id`);

--
-- Índices de tabela `gateway_bspaybr`
--
ALTER TABLE `gateway_bspaybr`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `niveis_vip`
--
ALTER TABLE `niveis_vip`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `planos`
--
ALTER TABLE `planos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `rendimentos_diarios`
--
ALTER TABLE `rendimentos_diarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `plano_id` (`plano_id`),
  ADD KEY `compra_id` (`compra_id`);

--
-- Índices de tabela `transacoes`
--
ALTER TABLE `transacoes`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `transacoes_pix`
--
ALTER TABLE `transacoes_pix`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `external_id` (`external_id`),
  ADD KEY `usuario_id` (`usuario_id`);

--
-- Índices de tabela `transacoes_retirada`
--
ALTER TABLE `transacoes_retirada`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `administrador`
--
ALTER TABLE `administrador`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `carteiras`
--
ALTER TABLE `carteiras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `checkins`
--
ALTER TABLE `checkins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `configuracoes`
--
ALTER TABLE `configuracoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `depositos`
--
ALTER TABLE `depositos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `niveis_vip`
--
ALTER TABLE `niveis_vip`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `planos`
--
ALTER TABLE `planos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT de tabela `rendimentos_diarios`
--
ALTER TABLE `rendimentos_diarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `transacoes`
--
ALTER TABLE `transacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `transacoes_pix`
--
ALTER TABLE `transacoes_pix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `transacoes_retirada`
--
ALTER TABLE `transacoes_retirada`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `rendimentos_diarios`
--
ALTER TABLE `rendimentos_diarios`
  ADD CONSTRAINT `rendimentos_diarios_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rendimentos_diarios_ibfk_2` FOREIGN KEY (`plano_id`) REFERENCES `planos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rendimentos_diarios_ibfk_3` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `transacoes_pix`
--
ALTER TABLE `transacoes_pix`
  ADD CONSTRAINT `fk_transacoes_pix_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
