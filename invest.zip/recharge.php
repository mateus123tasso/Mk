<?php
session_start();

include('servidor/infor.php');
include('servidor/atualizar_rendimento.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php';

$stmt = $pdo->query("SELECT * FROM configuracoes ORDER BY id ASC LIMIT 1");
$configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);

$recarga_minima = $configuracoes['recarga_minima'];
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Recarregar</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* --- Ocultar Scrollbar --- */
        ::-webkit-scrollbar {
            width: 0px;
            background: transparent;
        }
        body {
            -ms-overflow-style: none; /* IE e Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* --- Basic Reset & Body Styles --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif; /* Consistent with other pages */
        }

        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            /* Heineken Background */
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow-x: hidden;
            position: relative;
            padding-bottom: 0; /* No need for padding-bottom here if the main container handles it for the tabbar */
        }

        /* --- Background Shapes (consistent) --- */
        .background-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            pointer-events: none;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* --- Main Container (like .device on other pages) --- */
        .main-container {
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 30px; /* Adjust if a fixed tabbar is present below content */
            background: rgba(255, 255, 255, 0.1); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding-top: 0;
            display: flex;
            flex-direction: column; /* Allows content to stack vertically */
        }

        /* --- Header (consistent) --- */
        .header {
            padding: 50px 17px 20px;
            background: rgba(255, 255, 255, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 20;
            justify-content: space-between; /* Para espaçar os itens do cabeçalho */
        }

        .header .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            width: 24px;
            height: 24px;
            margin-right: 15px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3)); /* White arrow with shadow */
        }
        
        /* Contêiner para o título e o botão de histórico */
        .header-content {
            display: flex;
            align-items: center;
            flex-grow: 1; /* Permite que ocupe o espaço disponível */
            justify-content: center; /* Centraliza o título */
            position: relative; /* Para posicionar o botão de histórico */
        }

        .header-title {
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            font-size: 26px;
            font-weight: 800;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
            /* Remove flex-grow se quiser que o título seja centralizado sem empurrar o botão */
        }

        /* Estilo para o botão de histórico */
        .history-button {
            position: absolute; /* Posiciona absolutamente dentro de .header-content */
            right: 0; /* Alinha à direita do .header-content */
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.4);
            border-radius: 10px;
            padding: 8px 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s ease, transform 0.2s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
            color: #fff; /* Ícone e texto brancos */
            font-size: 14px;
            font-weight: 500;
            text-decoration: none; /* Remover sublinhado do link */
            white-space: nowrap; /* Evita que o texto quebre */
        }
        .history-button:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
        }
        .history-button i {
            margin-right: 8px; /* Espaço entre ícone e texto */
            font-size: 18px; /* Tamanho do ícone */
            color: #FFD700; /* Cor dourada para o ícone */
        }

        /* --- Recharge Card (Balance Display) --- */
        .recharge-card {
            padding: 20px 17px;
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.2); /* Translucent background */
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            text-align: center; /* Center content */
            animation: slideInLeft 0.6s ease-out forwards;
            animation-delay: 0.2s;
            opacity: 0;
        }

        @keyframes slideInLeft {
            from { opacity: 0; transform: translateX(-50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .recharge-card .balance-label {
            font-size: 15px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }

        .recharge-card .balance-amount {
            margin-top: 8px;
            font-family: 'Montserrat', sans-serif; /* Montserrat for amount */
            font-weight: 800;
            font-size: 38px;
            color: #FFD700; /* Gold for value */
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
        }

        /* --- Recharge Input Box --- */
        .recharge-box {
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.15); /* Slightly less opaque for inner elements */
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 20px;
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.4s;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .recharge-box .input-label {
            font-size: 15px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 500;
            margin-bottom: 12px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }

        .recharge-input-wrapper {
            height: 50px; /* Slightly taller input */
            background: rgba(255, 255, 255, 0.3); /* Lighter background for input */
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            display: flex;
            align-items: center;
            padding: 0 15px;
            color: #0A4A3C; /* Dark green text for input */
            font-size: 18px;
            font-weight: 600;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .recharge-input-wrapper span {
            color: #0A4A3C;
        }

        .recharge-input-wrapper input {
            flex: 1;
            margin-left: 10px;
            border: none;
            outline: none;
            background: transparent;
            font-size: 18px;
            color: #0A4A3C;
            font-weight: 600;
        }
        .recharge-input-wrapper input::placeholder {
            color: rgba(10, 74, 60, 0.7); /* Lighter placeholder text */
        }

        /* --- Modified Button Styles with Spinner --- */
        .payment-channel-button {
            height: 55px;
            margin-top: 25px;
            background: linear-gradient(90deg, #FFD700 0%, #FFA500 100%); /* Gold button */
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .payment-channel-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(255, 215, 0, 0.4);
        }
        .payment-channel-button:active {
            transform: translateY(0);
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.2);
        }
        
        .payment-channel-button.loading {
            cursor: not-allowed;
            background: linear-gradient(90deg, #B8860B 0%, #CD853F 100%); /* Darker gradient for loading state */
            color: transparent; /* Hides the button text */
        }

        /* Spinner Styles */
        .payment-channel-button.loading::after {
            content: '';
            position: absolute;
            width: 30px;
            height: 30px;
            border: 4px solid rgba(255, 255, 255, 0.5);
            border-top-color: #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* --- Instructions Section --- */
        .recharge-bottom {
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.15);
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 20px;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.6s;
            opacity: 0;
        }

        .recharge-bottom p {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            line-height: 1.6; /* Improved readability */
            margin-bottom: 10px;
            color: rgba(255, 255, 255, 0.9);
        }
        .recharge-bottom p strong {
            color: #FFD700; /* Gold for strong text */
            font-weight: 600;
        }

        /* --- Font Faces (keep if these specific fonts are needed and not from Google Fonts) --- */
        @font-face { font-family: Roboto-Medium; src: url(static/yunta/font/Roboto-Medium.ttf) format("truetype"); }
        @font-face { font-family: Roboto-Bold; src: url(static/yunta/font/Roboto-Bold.ttf) format("truetype"); }
        @font-face { font-family: Roboto-Regular; src: url(static/yunta/font/Roboto-Regular.ttf) format("truetype"); }
        @font-face { font-family: Roboto-SemiBold; src: url(static/yunta/font/Roboto-SemiBold.ttf) format("truetype"); }
        @font-face { font-family: Roboto-Light; src: url(static/yunta/font/Roboto-Light.ttf) format("truetype"); }

        /* --- Responsive Adjustments --- */
        @media (max-width: 500px) {
            .main-container {
                border-radius: 0;
                box-shadow: none;
                padding-bottom: 20px; /* Adjust for mobile, no fixed tabbar on this page */
            }
            .header {
                padding: 40px 15px 15px;
            }
            .header-title {
                font-size: 24px;
                /* No justify-content: center for mobile title, let it align with back button */
                flex-grow: 1; /* Permite que o título ocupe o espaço restante */
                text-align: center; /* Centraliza o texto do título */
                margin-right: 0; /* Remove margem extra à direita do título */
            }
            .history-button { /* Ajuste para o botão em mobile */
                padding: 6px 10px;
                font-size: 12px;
                position: relative; /* Volta para relative para fluxo normal em mobile */
                right: auto; /* Remove alinhamento absoluto */
                margin-left: 10px; /* Adiciona uma pequena margem à esquerda */
            }
            .history-button i {
                margin-right: 5px;
                font-size: 16px;
            }
            .recharge-card,
            .recharge-box,
            .recharge-bottom {
                width: calc(100% - 30px); /* Slightly less padding on smaller screens */
                margin-left: 15px;
                margin-right: 15px;
            }
            .recharge-card .balance-amount {
                font-size: 34px;
            }
            .recharge-input-wrapper {
                height: 45px;
                font-size: 16px;
            }
            .recharge-input-wrapper input {
                font-size: 16px;
            }
            .payment-channel-button {
                height: 50px;
                font-size: 18px;
            }
            .recharge-bottom p {
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="main-container">
        <div class="header">
            <div class="back-button" onclick="window.history.back()">
                <img src="static/yunta/image/device/left.png" alt="Voltar">
            </div>
            <div class="header-content">
                <div class="header-title">Recarregar</div>
                <a href="historico_recargas.php" class="history-button">
                    <i class="fas fa-history"></i> Histórico
                </a>
            </div>
        </div>

        <div class="recharge-card">
            <div>
                <div class="balance-label">Meu Saldo</div>
                <div class="balance-amount">R$<?php echo htmlspecialchars(number_format(usuario($_SESSION['user_id'], 'saldo_recarga'), 2, ',', '.')); ?></div>
            </div>
        </div>

        <div class="recharge-box">
            <div>
                <div class="input-label">Recarga de saldo</div>
                <div class="recharge-input-wrapper">
                    <span>R$</span>
                    <input type="number" id="amount" placeholder="Insira um valor personalizado" pattern="[0-9]*" autocomplete="off" maxlength="140">
                </div>
            </div>
            <div class="payment-channel-button" onclick="iniciarRecharge(this)">
                Canal de pagamento 1
            </div>
        </div>

        <div class="recharge-bottom">
            <p><strong>Instruções de pagamento via PIX:</strong></p>
            <p>1. O valor mínimo de pagamento é de <strong>R$<?php echo htmlspecialchars(number_format($recarga_minima, 2, ',', '.')); ?></strong>. Se o valor for menor que este, ele não será creditado na sua conta.</p>
            <p>2. Após efetuar o pagamento via PIX, Atulize a pagina para o valor contar em sua conta.</p>
            <p>3. O pagamento deve ser realizado exclusivamente através dos **canais oficiais**. Caso o valor não seja creditado, entre em contato com o suporte via WhatsApp e envie o comprovante.</p>
            <p>4. Para cada pagamento, **gere um novo QR Code PIX**. Cada código gerado é válido para apenas uma transação.</p>
            <p>5. O valor do pagamento deve ser **exatamente igual ao valor gerado na ordem**. Pagamentos com valores diferentes podem não ser processados corretamente.</p>
            <p>6. O pagamento via PIX está disponível **24 horas por dia**, todos os dias da semana.</p>
            <p>7. Todas as transações devem ser feitas diretamente no site oficial. Caso alguém entre em contato solicitando pagamentos fora da plataforma, **desconfie, pois pode ser um golpe**.</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function iniciarRecharge(button) {
            const valorRetirada = document.getElementById('amount').value;
            const recargaMinima = parseFloat(<?php echo json_encode($recarga_minima); ?>);

            if (!valorRetirada || isNaN(valorRetirada) || parseFloat(valorRetirada) <= 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Aviso!',
                    text: 'Informe um valor válido para a recarga.',
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            if (parseFloat(valorRetirada) < recargaMinima) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro!',
                    text: 'O valor mínimo para recarga é R$' + recargaMinima.toFixed(2).replace('.', ','),
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // Start loading state
            button.classList.add('loading');
            button.disabled = true;

            setTimeout(() => {
                const urlDestino = "/h5/recharge/ordem?g=" + encodeURIComponent(valorRetirada);
                window.location.href = urlDestino;
            }, 2000); // Wait for 2 seconds before redirecting
        }
    </script>
</body>
</html>