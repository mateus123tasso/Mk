<?php
session_start();
include('servidor/atualizar_rendimento.php');
include('servidor/infor.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php';

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$currentUrl = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$codigoConvite = usuario($_SESSION['user_id'], 'codigo_convite');
$newUrl = $protocol . $_SERVER['HTTP_HOST'] . '/reg?code=' . urlencode($codigoConvite);

try {
    $stmt = $pdo->query("SELECT * FROM configuracoes ORDER BY id ASC LIMIT 1");
    $configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);

    $comissaoLv1 = $configuracoes['lv1'];
    $comissaoLv2 = $configuracoes['lv2'];
    $comissaoLv3 = $configuracoes['lv3'];
    $telegramLink = $configuracoes['telegram'];
    $whatsappLink = $configuracoes['whatsapp'];

    // Formata os links para a API, se necessário
    if (!filter_var($telegramLink, FILTER_VALIDATE_URL) && !empty($telegramLink)) {
        $telegramLink = 'https://t.me/' . ltrim($telegramLink, '@');
    }
    if (!filter_var($whatsappLink, FILTER_VALIDATE_URL) && !empty($whatsappLink)) {
        $whatsappLink = 'https://wa.me/' . preg_replace('/\D/', '', $whatsappLink);
    }

    function countUsersBySponsor($pdo, $sponsorId) {
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id_patrocinador = :id_patrocinador");
        $stmt->bindParam(':id_patrocinador', $sponsorId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    $firstLevel = countUsersBySponsor($pdo, $_SESSION['user_id']);
    
    $secondLevel = [];
    foreach ($firstLevel as $userId) {
        $secondLevel = array_merge($secondLevel, countUsersBySponsor($pdo, $userId));
    }
    
    $thirdLevel = [];
    foreach ($secondLevel as $userId) {
        $thirdLevel = array_merge($thirdLevel, countUsersBySponsor($pdo, $userId));
    }
    
    $totalTeam = count($firstLevel) + count($secondLevel) + count($thirdLevel);

} catch (PDOException $e) {
    error_log("Erro na conexão ou ao buscar configurações: " . $e->getMessage());
    $totalTeam = 0;
    $firstLevel = [];
    $secondLevel = [];
    $thirdLevel = [];
    $comissaoLv1 = 'N/A';
    $comissaoLv2 = 'N/A';
    $comissaoLv3 = 'N/A';
    $telegramLink = '#';
    $whatsappLink = '#';
}

try {
    $stmt = $pdo->prepare("SELECT username, data_cadastro FROM usuarios WHERE id_patrocinador = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $usuariosLv1 = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar usuários: " . $e->getMessage());
    $usuariosLv1 = [];
}

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Ganhos</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&family=Orbitron:wght@400;500;700;900&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="mytabbar.css">
    
    <style>
        /* Reset e configurações básicas */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #fff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        /* Efeitos de fundo futuristas */
        .cyber-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 30px 30px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(30px, 30px); }
        }

        .floating-particles {
            position: fixed;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: radial-gradient(circle, rgba(255,215,0,0.8), transparent);
            border-radius: 50%;
            animation: floatParticle linear infinite;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(-50px);
                opacity: 0;
            }
        }

        /* Loading Spinner Sofisticado */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.8s ease, visibility 0.8s ease;
        }

        .loading-overlay.hidden {
            opacity: 0;
            visibility: hidden;
        }

        .futuristic-spinner {
            position: relative;
            width: 120px;
            height: 120px;
        }

        .spinner-ring {
            position: absolute;
            border: 2px solid transparent;
            border-radius: 50%;
            animation: spinRotate 2s linear infinite;
        }

        .spinner-ring:nth-child(1) {
            width: 120px;
            height: 120px;
            border-top: 2px solid #FFD700;
            border-right: 2px solid #FFD700;
            animation-duration: 1.5s;
        }

        .spinner-ring:nth-child(2) {
            width: 90px;
            height: 90px;
            border-bottom: 2px solid #FFA500;
            border-left: 2px solid #FFA500;
            top: 15px;
            left: 15px;
            animation-direction: reverse;
            animation-duration: 2s;
        }

        .spinner-ring:nth-child(3) {
            width: 60px;
            height: 60px;
            border-top: 2px solid #17706E;
            border-right: 2px solid #17706E;
            top: 30px;
            left: 30px;
            animation-duration: 1.2s;
        }

        .spinner-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #FFD700, #FFA500);
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes spinRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
            50% { transform: translate(-50%, -50%) scale(1.5); opacity: 0.7; }
        }

        /* Container Principal */
        .main-container {
            position: relative;
            z-index: 10;
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 120px;
        }

        /* Header Futurista */
        .cyber-header {
            position: relative;
            padding: 60px 20px 30px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.1) 0%,
                rgba(255,255,255,0.05) 50%,
                rgba(255,255,255,0.1) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,215,0,0.3);
            margin-bottom: 30px;
        }

        .cyber-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            animation: scanLine 3s ease-in-out infinite;
        }

        @keyframes scanLine {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand-logo {
            font-family: 'Orbitron', monospace;
            font-size: 28px;
            font-weight: 900;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            text-shadow: 0 0 20px rgba(255,215,0,0.5);
        }

        .brand-logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 2px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
            align-items: center;
        }

        .action-btn {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,215,0,0.2);
            position: relative;
            overflow: hidden;
            text-decoration: none;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,215,0,0.2), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.3);
            border-color: rgba(255,215,0,0.5);
        }

        .action-btn img {
            width: 24px;
            height: 24px;
            filter: brightness(1.2) drop-shadow(0 0 5px rgba(255,215,0,0.3));
            z-index: 1;
        }

        /* Team Stats Card */
        .team-stats-card {
            margin: 0 20px 20px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.08) 0%,
                rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            border: 1px solid rgba(255,215,0,0.15);
            padding: 30px 25px;
            position: relative;
            overflow: hidden;
            animation: slideInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .team-stats-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.1);
        }

        .stats-header {
            text-align: center;
            margin-bottom: 25px;
        }

        .stats-title {
            font-family: 'Orbitron', monospace;
            font-size: 24px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
            margin-bottom: 10px;
        }

        .stats-subtitle {
            font-size: 14px;
            color: rgba(255,255,255,0.7);
        }

        .team-levels {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .team-level {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background: rgba(0,0,0,0.2);
            border-radius: 12px;
            border-left: 4px solid #FFD700;
            transition: all 0.3s ease;
            position: relative;
        }

        .team-level:hover {
            background: rgba(255,215,0,0.08);
            transform: translateX(5px);
        }

        .level-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .level-number {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #FFD700, #FFA500);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Orbitron', monospace;
            font-weight: 700;
            color: #333;
            font-size: 16px;
        }

        .level-details {
            color: rgba(255,255,255,0.9);
        }

        .level-name {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .level-commission {
            font-size: 12px;
            color: rgba(255,255,255,0.6);
        }

        .level-count {
            font-family: 'Orbitron', monospace;
            font-size: 22px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 10px rgba(255,215,0,0.4);
        }

        /* Invite Section */
        .invite-card {
            margin: 0 20px 20px;
            background: linear-gradient(135deg, 
                rgba(255,215,0,0.08) 0%,
                rgba(255,165,0,0.04) 100%);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            border: 1px solid rgba(255,215,0,0.2);
            padding: 25px;
            position: relative;
            animation: slideInUp 0.8s ease-out forwards;
            animation-delay: 0.3s;
            opacity: 0;
        }

        .invite-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .invite-title {
            font-family: 'Orbitron', monospace;
            font-size: 20px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
            margin-bottom: 8px;
        }

        .invite-subtitle {
            font-size: 14px;
            color: rgba(255,255,255,0.7);
        }

        .invite-input-container {
            position: relative;
            margin-bottom: 20px;
        }

        .invite-input {
            width: 100%;
            padding: 15px 20px;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,215,0,0.3);
            border-radius: 12px;
            color: #fff;
            font-size: 14px;
            font-family: 'Poppins', sans-serif;
            outline: none;
            text-align: center;
            transition: all 0.3s ease;
        }

        .invite-input:focus {
            border-color: rgba(255,215,0,0.6);
            box-shadow: 0 0 15px rgba(255,215,0,0.2);
        }

        .copy-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(135deg, #FFD700, #FFA500);
            border: none;
            border-radius: 12px;
            color: #333;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .copy-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s ease;
        }

        .copy-btn:hover::before {
            left: 100%;
        }

        .copy-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.4);
        }

        .copy-btn:active {
            transform: translateY(0);
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .main-container {
                padding-bottom: 140px;
            }
            
            .cyber-header {
                padding: 50px 15px 25px;
            }
            
            .brand-logo {
                font-size: 22px;
            }
            
            .header-actions {
                gap: 10px;
            }
            
            .action-btn {
                width: 40px;
                height: 40px;
            }
            
            .action-btn img {
                width: 20px;
                height: 20px;
            }
            
            .team-stats-card,
            .invite-card {
                margin: 0 15px 15px;
                padding: 20px;
            }
            
            .stats-title {
                font-size: 20px;
            }
            
            .team-levels {
                gap: 12px;
            }
            
            .team-level {
                padding: 12px 15px;
            }
            
            .level-number {
                width: 35px;
                height: 35px;
                font-size: 14px;
            }
            
            .level-name {
                font-size: 14px;
            }
            
            .level-commission {
                font-size: 11px;
            }
            
            .level-count {
                font-size: 18px;
            }
            
            .invite-title {
                font-size: 18px;
            }
            
            .invite-input {
                padding: 12px 15px;
                font-size: 13px;
            }
            
            .copy-btn {
                padding: 12px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            .level-info {
                gap: 10px;
            }
            
            .team-level {
                padding: 10px 12px;
            }
            
            .level-details {
                min-width: 0;
            }
            
            .level-name {
                font-size: 13px;
            }
            
            .level-commission {
                font-size: 10px;
            }
        }

        /* Micro animações */
        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
        }

        .glitch-effect:hover {
            animation: glitch 0.3s;
        }
    </style>
</head>

<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="futuristic-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-center"></div>
        </div>
    </div>

    <!-- Background Effects -->
    <div class="cyber-grid"></div>
    <div class="floating-particles" id="particles"></div>

    <!-- Main Container -->
    <div class="main-container" id="mainContent" style="opacity: 0;">
        <!-- Header -->
        <div class="cyber-header">
            <div class="header-content">
                <div class="brand-logo glitch-effect">Ganhos</div>
                <div class="header-actions">
                    <a href="<?php echo htmlspecialchars($whatsappLink); ?>" target="_blank" class="action-btn">
                        <img src="/assets/whatsapp.png" alt="WhatsApp">
                    </a>
                    <a href="<?php echo htmlspecialchars($telegramLink); ?>" target="_blank" class="action-btn">
                        <img src="/assets/telegram.png" alt="Telegram">
                    </a>
                    <div class="action-btn" onclick="window.location.href='/cotactUs'">
                        <img src="static/yunta/image/home/service.png" alt="Serviço">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Team Stats Card -->
        <div class="team-stats-card">
            <div class="stats-header">
                <div class="stats-title">Estatísticas da Equipe</div>
                <div class="stats-subtitle">Acompanhe o crescimento da sua rede</div>
            </div>
            
            <div class="team-levels">
                <div class="team-level">
                    <div class="level-info">
                        <div class="level-number">1</div>
                        <div class="level-details">
                            <div class="level-name">Primeiro Nível</div>
                            <div class="level-commission">Comissão: <?php echo htmlspecialchars($comissaoLv1); ?>%</div>
                        </div>
                    </div>
                    <div class="level-count"><?php echo count($firstLevel); ?></div>
                </div>
                
                <div class="team-level">
                    <div class="level-info">
                        <div class="level-number">2</div>
                        <div class="level-details">
                            <div class="level-name">Segundo Nível</div>
                            <div class="level-commission">Comissão: <?php echo htmlspecialchars($comissaoLv2); ?>%</div>
                        </div>
                    </div>
                    <div class="level-count"><?php echo count($secondLevel); ?></div>
                </div>
                
                <div class="team-level">
                    <div class="level-info">
                        <div class="level-number">3</div>
                        <div class="level-details">
                            <div class="level-name">Terceiro Nível</div>
                            <div class="level-commission">Comissão: <?php echo htmlspecialchars($comissaoLv3); ?>%</div>
                        </div>
                    </div>
                    <div class="level-count"><?php echo count($thirdLevel); ?></div>
                </div>
            </div>
        </div>

        <!-- Invite Card -->
        <div class="invite-card">
            <div class="invite-header">
                <div class="invite-title">Link de Convite</div>
                <div class="invite-subtitle">Compartilhe e expanda sua equipe</div>
            </div>
            
            <div class="invite-input-container">
                <input id="inviteLink" class="invite-input" type="text" value="<?php echo htmlspecialchars($newUrl);?>" readonly>
            </div>
            
            <button class="copy-btn" onclick="copyInviteLink()">
                Copiar Link de Convite
            </button>
        </div>
    </div>

    <?php include 'tabbar.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Loading Animation
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('loadingOverlay').classList.add('hidden');
                document.getElementById('mainContent').style.opacity = '1';
                document.getElementById('mainContent').style.transition = 'opacity 1s ease';
            }, 1200);
        });

        // Create floating particles
        function createParticles() {
            const particleContainer = document.getElementById('particles');
            const particleCount = 12;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 8 + 4) + 's';
                particle.style.animationDelay = Math.random() * 4 + 's';
                particleContainer.appendChild(particle);
            }
        }

        createParticles();

        // Copy invite link with loading state
        function copyInviteLink() {
            const btn = event.target;
            const originalText = btn.textContent;
            const copyText = document.getElementById("inviteLink");
            
            // Add loading state
            btn.textContent = 'Copiando...';
            btn.disabled = true;
            btn.style.opacity = '0.7';
            
            // Copy to clipboard
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            
            // Reset button after delay
            setTimeout(() => {
                btn.textContent = originalText;
                btn.disabled = false;
                btn.style.opacity = '1';
                
                // Show success alert
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso!',
                    text: "Link de convite copiado com sucesso!",
                    position: 'center',
                    showConfirmButton: false,
                    timer: 2500,
                    timerProgressBar: true,
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                    color: '#fff',
                    backdrop: 'rgba(0,0,0,0.8)'
                });
            }, 800);
        }

        // Enhanced hover effects
        const teamLevels = document.querySelectorAll('.team-level');
        teamLevels.forEach(level => {
            level.addEventListener('mouseenter', function() {
                this.style.transform = 'translateX(8px) scale(1.02)';
            });
            
            level.addEventListener('mouseleave', function() {
                this.style.transform = 'translateX(0) scale(1)';
            });
        });

        // Add loading states to action buttons
        const actionBtns = document.querySelectorAll('.action-btn');
        actionBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (this.onclick || this.href) {
                    this.style.opacity = '0.7';
                    this.style.pointerEvents = 'none';
                    
                    setTimeout(() => {
                        this.style.opacity = '1';
                        this.style.pointerEvents = 'auto';
                    }, 1000);
                }
            });
        });
    </script>
</body>
</html>