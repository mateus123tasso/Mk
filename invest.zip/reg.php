<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <title>Crie sua Conta</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow: hidden;
            position: relative;
            padding: 10px;
        }

        /* Efeitos de fundo otimizados */
        .background-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 50%;
            animation: moveShapes 20s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 80px; height: 80px; top: 15%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 120px; height: 120px; top: 60%; left: 85%; animation-delay: 3s; }
        .background-shapes div:nth-child(3) { width: 60px; height: 60px; top: 75%; left: 15%; animation-delay: 6s; }
        .background-shapes div:nth-child(4) { width: 160px; height: 160px; top: 25%; left: 70%; animation-delay: 9s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.7; }
            50% { transform: translate(20px, 30px) scale(1.05); opacity: 0.5; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.7; }
        }

        /* Container principal compacto */
        .register-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            padding: 28px 32px;
            width: 100%;
            max-width: 380px;
            text-align: center;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 1;
            animation: slideInUp 0.8s ease-out forwards;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .register-card h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.2em;
            margin-bottom: 8px;
            color: #fff;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
            font-weight: 800;
            letter-spacing: -0.3px;
        }

        .register-card p.subtitle {
            font-size: 0.95em;
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 24px;
            font-weight: 400;
        }

        /* Layout em grid para campos em duas colunas */
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-bottom: 20px;
        }

        .form-grid .full-width {
            grid-column: 1 / -1;
        }

        .input-group {
            position: relative;
        }

        .input-group label {
            position: absolute;
            top: 50%;
            left: 16px;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9em;
            pointer-events: none;
            transition: 0.3s ease all;
            background: transparent;
            padding: 0 4px;
            z-index: 5;
            width: auto;
            text-align: left;
        }

        .input-group.phone-input label {
            left: 55px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            font-size: 0.95em;
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15);
        }

        .input-group.phone-input input {
            padding-left: 55px;
        }

        .input-group .prefix {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.95);
            font-weight: 600;
            font-size: 0.95em;
            z-index: 6;
        }

        .input-group input:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.7);
            background-color: rgba(255, 255, 255, 0.25);
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.3), inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .input-group input:focus + label,
        .input-group input:not(:placeholder-shown) + label {
            top: -12px;
            left: 16px;
            transform: none;
            font-size: 0.75em;
            color: #fff;
            background: linear-gradient(90deg, #2ECC71, #FFD700);
            padding: 2px 8px;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
            z-index: 10;
            width: auto;
            text-align: left;
        }

        .input-group.phone-input input:focus + label,
        .input-group.phone-input input:not(:placeholder-shown) + label {
             left: 16px;
        }

        .register-button {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            color: #333;
            padding: 14px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 700;
            width: 100%;
            transition: all 0.3s ease;
            margin-top: 16px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            letter-spacing: 0.5px;
        }

        .register-button:hover {
            background: linear-gradient(45deg, #FFA500, #FFD700);
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.4);
        }

        .register-button:active {
            transform: translateY(0);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .links {
            margin-top: 20px;
            font-size: 0.9em;
        }

        .links a {
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .links a:hover {
            color: #fff;
            text-shadow: 0 0 8px rgba(255, 255, 255, 0.7);
            text-decoration: underline;
        }

        /* Responsividade aprimorada */
        @media (max-width: 480px) {
            body {
                padding: 15px;
            }
            .register-card {
                padding: 24px 20px;
                border-radius: 14px;
                max-width: 100%;
            }
            .register-card h2 {
                font-size: 1.8em;
                margin-bottom: 6px;
            }
            .register-card p.subtitle {
                font-size: 0.85em;
                margin-bottom: 20px;
            }
            .form-grid {
                grid-template-columns: 1fr;
                gap: 14px;
                margin-bottom: 16px;
            }
            .input-group input {
                padding: 11px 14px;
                font-size: 0.9em;
            }
            .input-group.phone-input input {
                 padding-left: 50px;
            }
            .input-group .prefix {
                left: 14px;
                font-size: 0.9em;
            }
            .input-group label {
                left: 14px;
                font-size: 0.85em;
            }
            .input-group.phone-input label {
                left: 50px;
            }
            .input-group input:focus + label,
            .input-group input:not(:placeholder-shown) + label {
                left: 14px;
                font-size: 0.7em;
            }
            .input-group.phone-input input:focus + label,
            .input-group.phone-input input:not(:placeholder-shown) + label {
                left: 14px;
            }
            .register-button {
                padding: 12px 20px;
                font-size: 1em;
                margin-top: 14px;
            }
            .links {
                margin-top: 16px;
                font-size: 0.85em;
            }
        }

        @media (max-width: 360px) {
            .register-card h2 {
                font-size: 1.6em;
            }
            .form-grid {
                gap: 12px;
            }
        }
    </style>
</head>
<body>

    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="register-card">
        <h2>Crie sua Conta!</h2>
        <p class="subtitle">Junte-se à nossa comunidade hoje.</p>

        <form id="registerForm">
            <div class="form-grid">
                <div class="input-group full-width">
                    <input type="text" id="fullName" name="fullName" placeholder=" " required>
                    <label for="fullName">Nome Completo</label>
                </div>
                <div class="input-group">
                    <input type="text" id="cpf" name="cpf" placeholder=" " required inputmode="numeric" pattern="\d{11}" maxlength="11" title="Digite apenas os 11 números do CPF">
                    <label for="cpf">CPF</label>
                </div>
                <div class="input-group phone-input">
                    <span class="prefix">+55</span>
                    <input type="text" id="phone" name="phone" placeholder=" " required inputmode="numeric" pattern="[0-9]*" maxlength="11">
                    <label for="phone">Celular</label>
                </div>
                <div class="input-group">
                    <input type="password" id="password" name="password" placeholder=" " required>
                    <label for="password">Senha</label>
                </div>
                <div class="input-group">
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder=" " required>
                    <label for="confirmPassword">Confirmar Senha</label>
                </div>
                <div class="input-group full-width">
                    <input type="text" id="invitationCode" name="invitationCode" placeholder=" ">
                    <label for="invitationCode">Código de Convite (Opcional)</label>
                </div>
            </div>
            <button type="submit" class="register-button">Registrar</button>
        </form>

        <div class="links">
            <a href="login">Já tem uma conta? Faça login!</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            const urlParams = new URLSearchParams(window.location.search);
            const invitationCodeFromUrl = urlParams.get('code');

            if (invitationCodeFromUrl) {
                const invitationCodeInput = document.getElementById('invitationCode');
                invitationCodeInput.value = invitationCodeFromUrl;
                
                invitationCodeInput.parentNode.classList.add('focused');
            }
        });

        document.getElementById('registerForm').addEventListener('submit', async function (event) {
            event.preventDefault();

            const fullName = document.getElementById('fullName').value;
            const cpf = document.getElementById('cpf').value;
            const phone = document.getElementById('phone').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const invitationCode = document.getElementById('invitationCode').value;

            // Validação de Frontend
            if (!fullName || !cpf || !phone || !password || !confirmPassword) {
                Swal.fire({ icon: 'warning', title: 'Campos Vazios!', text: 'Por favor, preencha todos os campos obrigatórios.' });
                return;
            }

            if (password !== confirmPassword) {
                Swal.fire({ icon: 'error', title: 'Senhas Diferentes!', text: 'A senha e a confirmação de senha não coincidem.' });
                return;
            }

            if (password.length < 6) {
                Swal.fire({ icon: 'warning', title: 'Senha Curta!', text: 'A senha deve ter no mínimo 6 caracteres.' });
                return;
            }

            // Validação de Celular
            if (!/^\d{11}$/.test(phone)) {
                Swal.fire({ icon: 'warning', title: 'Celular Inválido!', text: 'O número de celular deve ter 11 dígitos (incluindo DDD, ex: 11987654321).' });
                return;
            }

            // Validação de CPF
            if (!/^\d{11}$/.test(cpf)) {
                Swal.fire({ icon: 'warning', title: 'CPF Inválido!', text: 'O CPF deve ter 11 dígitos (somente números).' });
                return;
            }

            // Envia os dados para o backend PHP
            const formData = new FormData();
            formData.append('fullName', fullName);
            formData.append('cpf', cpf);
            formData.append('phone', phone);
            formData.append('password', password);
            formData.append('invitationCode', invitationCode);

            try {
                const response = await fetch('servidor/registro.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (result.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: result.message + ' Redirecionando para o login...',
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => {
                        window.location.href = 'login.php';
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro no Registro!',
                        text: result.message
                    });
                }
            } catch (error) {
                console.error('Erro na requisição AJAX:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erro de Conexão!',
                    text: 'Não foi possível conectar ao servidor. Por favor, tente novamente.'
                });
            }
        });

        document.querySelectorAll('.input-group input').forEach(input => {
            input.addEventListener('focus', () => {
                input.parentNode.classList.add('focused');
            });
            input.addEventListener('blur', () => {
                if (input.value === '') {
                    input.parentNode.classList.remove('focused');
                }
            });
            if (input.value !== '') {
                input.parentNode.classList.add('focused');
            }
        });
    </script>

</body>
</html>