<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <title>Recuperar Senha</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        /* Reset básico */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow: hidden;
            position: relative;
        }

        /* Elementos de fundo animados */
        .background-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* Container principal do cartão (Glassmorphism) */
        .recovery-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            text-align: center;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 1;
            animation: slideInUp 0.8s ease-out forwards;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .recovery-card h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.5em;
            margin-bottom: 10px;
            color: #fff;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
            font-weight: 800;
            letter-spacing: -0.5px;
        }

        .recovery-card p.subtitle {
            font-size: 1.1em;
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 40px;
            font-weight: 400;
        }

        .recovery-button {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            color: #333;
            padding: 16px 30px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 1.3em;
            font-weight: 700;
            width: 100%;
            transition: 0.3s ease transform, 0.3s ease box-shadow, 0.3s ease background;
            margin-top: 35px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            letter-spacing: 1px;
        }

        .recovery-button:hover {
            background: linear-gradient(45deg, #FFA500, #FFD700);
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }

        .recovery-button:active {
            transform: translateY(0);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        .back-link {
            display: block;
            margin-top: 30px;
            font-size: 1em;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: color 0.3s ease, text-shadow 0.3s ease;
            font-weight: 500;
        }

        .back-link:hover {
            color: #fff;
            text-decoration: underline;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.7);
        }

        /* Responsividade */
        @media (max-width: 500px) {
            .recovery-card {
                margin: 20px;
                padding: 30px 25px;
                border-radius: 15px;
            }
            .recovery-card h2 {
                font-size: 2em;
            }
            .recovery-card p.subtitle {
                font-size: 0.9em;
                margin-bottom: 30px;
            }
            .recovery-button {
                padding: 14px 20px;
                font-size: 1.1em;
                margin-top: 25px;
            }
            .back-link {
                margin-top: 25px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>

    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="recovery-card">
        <h2>Trocar Senha</h2>
        <p class="subtitle">Clique no botão abaixo para conversar com nosso suporte e redefinir sua senha.</p>
        
        <button type="button" class="recovery-button" onclick="openTelegram()">Falar com o Suporte</button>

        <a href="index.php" class="back-link">Voltar para o Login</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        function openTelegram() {
            // Nome de usuário do suporte no Telegram
            const telegramUsername = 'Supmindia';
            
            // Mensagem pré-definida para o suporte
            const message = `Olá, desejo alterar minha senha.`;

            // Constrói a URL do Telegram
            const telegramUrl = `https://t.me/${telegramUsername}?text=${encodeURIComponent(message)}`;

            // Abre o Telegram em uma nova aba
            window.open(telegramUrl, '_blank');

            // Exibe um alerta de confirmação após o clique
            Swal.fire({
                icon: 'info',
                title: 'Redirecionando para o Telegram!',
                text: 'Você será levado ao chat de suporte. Por favor, envie a mensagem pré-preenchida para agilizar o atendimento.',
                position: 'center',
                showConfirmButton: true,
                confirmButtonText: 'Entendi'
            });
        }
    </script>

</body>
</html>