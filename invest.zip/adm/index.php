<?php
session_start();

// Verifica se o administrador está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
require_once '../servidor/database.php';

// Inicializa as variáveis de contagem
$totalDepositosPendentes = 0;
$totalSaquesPendentes = 0;

// Lógica para obter a contagem de depósitos pendentes
try {
    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $sqlDepositos = "SELECT COUNT(*) as total FROM transacoes_deposito WHERE status = 'pendente'";
        $resultDepositos = $conn->query($sqlDepositos);
        if ($resultDepositos) {
            $row = $resultDepositos->fetch_assoc();
            $totalDepositosPendentes = $row['total'];
        }
    }
} catch (Exception $e) {
    // Em caso de erro, a contagem permanece em 0
    error_log("Erro ao contar depósitos pendentes no index.php: " . $e->getMessage());
}

// Lógica para obter a contagem de saques pendentes
try {
    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $sqlSaques = "SELECT COUNT(*) as total FROM transacoes_retirada WHERE status = 'pendente'";
        $resultSaques = $conn->query($sqlSaques);
        if ($resultSaques) {
            $row = $resultSaques->fetch_assoc();
            $totalSaquesPendentes = $row['total'];
        }
    }
} catch (Exception $e) {
    // Em caso de erro, a contagem permanece em 0
    error_log("Erro ao contar saques pendentes no index.php: " . $e->getMessage());
}

// Fecha a conexão com o banco de dados, se estiver aberta
if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - Admin</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
        :root {
            --primary-color: #4CAF50; /* Green */
            --secondary-color: #2c3e50; /* Dark Blue-Gray */
            --accent-color: #FFA500; /* Orange-Gold */
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- Navbar Styling --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important; /* Lighter grey for links */
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
            position: relative;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e; /* Slightly darker background on hover/active */
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        .nav-item .badge {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 4px 8px;
            border-radius: 50%;
            font-size: 0.7em;
        }

        /* --- Main Content Container --- */
        .container {
            padding-top: 20px;
            padding-bottom: 20px;
        }

        h1 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 30px;
        }

        /* --- Card Styling --- */
        .card {
            margin: 15px; /* Adjusted margin for better spacing */
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden; /* Ensures rounded corners on image if any */
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.2);
        }
        .card-body {
            padding: 25px;
            text-align: center;
        }
        .card-title {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 1.25rem;
            margin-bottom: 10px;
        }
        .card-text {
            font-size: 2rem; /* Larger text for metrics */
            font-weight: 700;
        }
        .bg-primary { background-color: var(--primary-color) !important; }
        .bg-success { background-color: #28a745 !important; } /* Standard Bootstrap success green */
        .bg-warning { background-color: var(--accent-color) !important; }
        .bg-info { background-color: #17a2b8 !important; } /* Standard Bootstrap info blue */
        .text-white { color: var(--white) !important; }

        /* --- Chart Styling --- */
        .chart-container {
            margin: 30px auto;
            max-width: 90%; /* Responsive width */
            background-color: var(--white);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            min-height: 300px; /* Ensure a minimum height for the chart */
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* --- Mobile Responsive CSS --- */
        @media (max-width: 768px) {
            .container {
                padding-left: 15px;
                padding-right: 15px;
            }
            h1 {
                font-size: 2rem;
            }
            .card {
                margin: 10px 0; /* Adjust card margins for stacking */
            }
            .card-text {
                font-size: 1.8rem; /* Slightly smaller on mobile */
            }
            .chart-container {
                padding: 15px;
                min-height: 250px;
            }
            .navbar-nav {
                text-align: center; /* Center nav items in mobile */
            }
            .navbar-nav .nav-item {
                margin: 5px 0; /* Adjust margin for stacked nav items */
            }
        }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Painel Admin</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index">Início</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="usuarios">Usuários</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="transacoes">Transações</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="planos">Planos</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="configuracoes">Configurações</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="depositos">
                            Depósitos
                            <?php if ($totalDepositosPendentes > 0): ?>
                                <span class="badge bg-danger rounded-circle"><?= $totalDepositosPendentes ?></span>
                            <?php endif; ?>
                        </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="saques">
                            Saques
                            <?php if ($totalSaquesPendentes > 0): ?>
                                <span class="badge bg-danger rounded-circle"><?= $totalSaquesPendentes ?></span>
                            <?php endif; ?>
                        </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="niveis_vip">VIPs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Sair</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">
    <h1 class="text-center my-4">Dashboard de Visão Geral</h1>
    <div class="row justify-content-center"> <div class="col-md-3 col-sm-6">
        <div class="card text-white bg-primary">
          <div class="card-body">
            <h5 class="card-title">Total de Usuários</h5>
            <p id="total-usuarios" class="card-text">0</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="card text-white bg-success">
          <div class="card-body">
            <h5 class="card-title">Saldo Total</h5>
            <p id="saldo-total" class="card-text">R$ 0,00</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="card text-white bg-warning">
          <div class="card-body">
            <h5 class="card-title">Depósitos Pendentes</h5>
            <p id="depositos-pendentes" class="card-text">0</p>
          </div>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
        <div class="card text-white bg-info">
          <div class="card-body">
            <h5 class="card-title">Saques Pendentes</h5>
            <p id="saques-pendentes" class="card-text">0</p>
          </div>
        </div>
      </div>
      </div>

    <div class="chart-container">
      <canvas id="transacoesChart"></canvas>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    async function fetchDashboardData() {
      try {
        // Ensure your backend endpoint is correctly configured (e.g., dashboard_backend.php)
        const response = await axios.get('dashboard_backend.php');
        const data = response.data;
       
        document.getElementById('total-usuarios').innerText = data.totalUsuarios || 'N/A';
        document.getElementById('saldo-total').innerText = `R$ ${parseFloat(data.saldoTotal || 0).toFixed(2).replace('.', ',')}`;
        document.getElementById('depositos-pendentes').innerText = data.depositosPendentes || '0';
        document.getElementById('saques-pendentes').innerText = data.saquesPendentes || '0'; // Assuming you add this to your backend API

        // If you fetch "Planos Ativos" from your backend, uncomment and update this line
        // document.getElementById('planos-ativos').innerText = data.planosAtivos || '0';
       
        const ctx = document.getElementById('transacoesChart').getContext('2d');
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
            datasets: [{
              label: 'Transações Mensais',
              data: data.transacoesMensais || Array(12).fill(0), // Default to zeros if no data
              backgroundColor: 'rgba(76, 175, 80, 0.4)', /* Primary color with transparency */
              borderColor: 'var(--primary-color)',
              borderWidth: 2,
              pointBackgroundColor: 'var(--primary-color)',
              tension: 0.4,
              fill: true // Fill area under the line
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false, // Allow chart to take parent's dimensions
            plugins: {
              legend: {
                display: true,
                position: 'top',
                labels: {
                  font: {
                    family: 'Poppins'
                  },
                  color: 'var(--text-dark)'
                }
              },
              tooltip: {
                enabled: true,
                backgroundColor: 'rgba(44, 62, 80, 0.9)', // Secondary color for tooltip
                titleFont: {
                  family: 'Poppins',
                  weight: '600'
                },
                bodyFont: {
                  family: 'Poppins'
                },
                displayColors: false
              }
            },
            scales: {
              x: {
                title: {
                  display: true,
                  text: 'Meses',
                  font: {
                    family: 'Poppins',
                    weight: '500'
                  },
                  color: 'var(--secondary-color)'
                },
                ticks: {
                  font: {
                    family: 'Poppins'
                  },
                  color: 'var(--text-dark)'
                },
                grid: {
                  display: false // Hide x-axis grid lines
                }
              },
              y: {
                beginAtZero: true,
                title: {
                  display: true,
                  text: 'Quantidade de Transações',
                  font: {
                    family: 'Poppins',
                    weight: '500'
                  },
                  color: 'var(--secondary-color)'
                },
                ticks: {
                  font: {
                    family: 'Poppins'
                  },
                  color: 'var(--text-dark)'
                },
                grid: {
                  color: '#e0e0e0' // Lighter grid lines
                }
              }
            }
          }
        });

      } catch (error) {
        console.error('Erro ao buscar os dados do Dashboard:', error);
        Swal.fire({
          icon: 'error',
          title: 'Erro de Carregamento!',
          text: 'Não foi possível carregar os dados do Dashboard. Verifique a conexão com a API.',
          showConfirmButton: true
        });
      }
    }

    document.addEventListener('DOMContentLoaded', fetchDashboardData);
  </script>
</body>
</html>