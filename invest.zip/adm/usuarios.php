<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

require '../servidor/database.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #2c3e50;
            --accent-color: #FFA500;
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- Navbar Styling --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important;
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e;
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* --- Main Content Container --- */
        .container.mt-4 {
            padding-top: 15px;
            padding-bottom: 15px;
        }

        /* --- Table Container --- */
        .table-container {
            margin: 20px auto;
            max-width: 1400px;
            background-color: var(--white);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.6s ease-out forwards;
            opacity: 0;
            transform: translateY(15px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 25px;
            font-size: 1.5rem;
        }

        /* --- Search Input --- */
        #searchUser {
            font-size: 0.9rem;
            padding: 8px 12px;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        /* --- Table Styling --- */
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            font-size: 0.8rem;
        }
        .table thead th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: 600;
            padding: 10px 8px;
            border-bottom: none;
            vertical-align: middle;
            text-align: center;
            font-size: 0.8rem;
            white-space: nowrap;
            min-height: 40px;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .table tbody td {
            padding: 10px 8px;
            vertical-align: middle;
            text-align: center;
            border-top: 1px solid #dee2e6;
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            min-height: 45px;
            line-height: 1.4;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f7f9fc;
        }

        /* --- Compact Button Styles --- */
        .btn {
            font-weight: 500;
            padding: 4px 8px;
            border-radius: 4px;
            transition: all 0.2s ease;
            font-size: 0.75rem;
            margin: 1px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: #43a047;
            border-color: #43a047;
            transform: translateY(-1px);
        }
        .btn-warning {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            color: var(--text-dark);
        }
        .btn-warning:hover {
            background-color: #e69500;
            border-color: #e69500;
            transform: translateY(-1px);
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
            transform: translateY(-1px);
        }
        .btn-info {
            background-color: #17a2b8;
            border-color: #17a2b8;
            color: var(--white);
        }
        .btn-info:hover {
            background-color: #138496;
            border-color: #117a8b;
            transform: translateY(-1px);
        }
        .btn-sm {
            padding: 3px 6px;
            font-size: 0.7rem;
        }

        /* --- Modal Styling --- */
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            border: none;
        }
        .modal-header {
            background-color: var(--secondary-color);
            color: var(--white);
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            padding: 12px 20px;
            border-bottom: none;
        }
        .modal-title {
            font-weight: 600;
            font-size: 1.1rem;
        }
        .modal-body {
            padding: 20px;
            max-height: 70vh;
            overflow-y: auto;
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 12px 20px;
        }
        .form-label {
            font-weight: 500;
            color: var(--secondary-color);
            font-size: 0.9rem;
        }
        .form-control {
            border-radius: 6px;
            padding: 8px 10px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            font-size: 0.9rem;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(76, 175, 80, 0.25);
        }

        /* PIX Cards */
        .card {
            border-radius: 8px;
            border: 1px solid #e9ecef;
            margin-bottom: 10px;
        }
        .card-body {
            padding: 15px;
        }

        /* --- Mobile Responsive CSS --- */
        @media (max-width: 768px) {
            .table-container {
                padding: 15px;
                margin: 15px auto;
                max-width: 95%;
            }

            .table thead {
                display: none;
            }

            .table tbody, .table tr, .table td {
                display: block;
                width: 100%;
            }

            .table tr {
                margin-bottom: 15px;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                overflow: hidden;
                background: white;
            }

            .table td {
                text-align: right;
                padding-left: 50%;
                position: relative;
                white-space: normal;
                border: none;
                padding: 8px 15px;
            }

            .table td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: calc(50% - 20px);
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: 600;
                color: var(--secondary-color);
            }

            .table td:nth-of-type(1)::before { content: "ID"; }
            .table td:nth-of-type(2)::before { content: "Usuário"; }
            .table td:nth-of-type(3)::before { content: "Nome"; }
            .table td:nth-of-type(4)::before { content: "CPF"; }
            .table td:nth-of-type(5)::before { content: "Saldo Recarga"; }
            .table td:nth-of-type(6)::before { content: "Saldo Retirada"; }
            .table td:nth-of-type(7)::before { content: ""; }

            .table td:last-child {
                text-align: center;
                padding-top: 15px;
                padding-bottom: 15px;
                border-top: 1px solid #eee;
                padding-left: 15px;
            }

            .btn-group {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .btn-group .btn {
                width: 100%;
                padding: 8px 12px;
                font-size: 0.85rem;
            }

            h2 {
                font-size: 1.3rem;
                text-align: center;
            }

            .navbar-nav {
                text-align: center;
            }
            .navbar-nav .nav-item {
                margin: 5px 0;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-4">
        <h2 class="text-center mb-3">Gerenciar Usuários</h2>
        <div class="mb-3">
            <input type="text" class="form-control" id="searchUser" placeholder="Pesquisar por nome de usuário, nome completo ou ID..." oninput="filterUsers()">
        </div>
        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 5%">ID</th>
                            <th style="width: 15%">Usuário</th>
                            <th style="width: 20%">Nome</th>
                            <th style="width: 15%">CPF</th>
                            <th style="width: 12%">Saldo Recarga</th>
                            <th style="width: 12%">Saldo Retirada</th>
                            <th style="width: 21%">Ações</th>
                        </tr>
                    </thead>
                    <tbody id="user-table-body">
                        <tr>
                            <td colspan="7" class="text-center py-4">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Carregando...</span>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal Editar Usuário -->
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Editar Usuário</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="editUserId">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editUsername" class="form-label">Usuário</label>
                                <input type="text" class="form-control" id="editUsername" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editCpf" class="form-label">CPF</label>
                                <input type="text" class="form-control" id="editCpf" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editNomeCompleto" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="editNomeCompleto" required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editSaldoRecarga" class="form-label">Saldo de Recarga</label>
                                <input type="number" step="0.01" class="form-control" id="editSaldoRecarga" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editSaldoRetirada" class="form-label">Saldo de Retirada</label>
                                <input type="number" step="0.01" class="form-control" id="editSaldoRetirada" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="editPassword" class="form-label">Nova Senha (deixe em branco para não alterar)</label>
                            <input type="password" class="form-control" id="editPassword">
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Excluir Usuário -->
    <div class="modal fade" id="deleteUserModal" tabindex="-1" aria-labelledby="deleteUserModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteUserModalLabel">Excluir Usuário</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza de que deseja excluir este usuário? Esta ação é irreversível.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger btn-sm" id="confirmDeleteUserBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Gerenciar PIX -->
    <div class="modal fade" id="editPixModal" tabindex="-1" aria-labelledby="editPixModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editPixModalLabel">Gerenciar Chaves Pix</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="editPixUserId">
                    <h6 class="border-bottom pb-2 mb-3">Chaves Existentes</h6>
                    <div id="pix-keys-list">
                        <div class="text-center">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Carregando...</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let usersData = [];
        let userIdToDelete = null;

        async function fetchUsers() {
            try {
                const response = await axios.get('api_user.php');
                usersData = response.data;
                renderUsers(usersData);
            } catch (error) {
                console.error('Erro ao buscar usuários:', error);
                document.getElementById('user-table-body').innerHTML = 
                    '<tr><td colspan="7" class="text-center py-4 text-danger">Erro ao carregar usuários. Tente recarregar a página.</td></tr>';
            }
        }

        function renderUsers(users) {
            const tableBody = document.getElementById('user-table-body');
            tableBody.innerHTML = '';

            if (users.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum usuário encontrado.</td></tr>';
                return;
            }

            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td data-label="ID">${user.id}</td>
                    <td data-label="Usuário">${user.username}</td>
                    <td data-label="Nome Completo">${user.nome_completo || 'N/A'}</td>
                    <td data-label="CPF">${user.cpf || 'N/A'}</td>
                    <td data-label="Saldo Recarga">R$ ${parseFloat(user.saldo_recarga).toFixed(2).replace('.', ',')}</td>
                    <td data-label="Saldo Retirada">R$ ${parseFloat(user.saldo_retirada).toFixed(2).replace('.', ',')}</td>
                    <td data-label="">
                        <div class="btn-group">
                            <button class="btn btn-info btn-sm" onclick="showPixModal(${user.id})">PIX</button>
                            <button class="btn btn-warning btn-sm" onclick="editUser(${user.id})">Editar</button>
                            <button class="btn btn-danger btn-sm" onclick="showDeleteUserModal(${user.id})">Excluir</button>
                        </div>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        }

        function filterUsers() {
            const searchTerm = document.getElementById('searchUser').value.toLowerCase();
            const filteredUsers = usersData.filter(user =>
                user.username.toLowerCase().includes(searchTerm) ||
                (user.nome_completo && user.nome_completo.toLowerCase().includes(searchTerm)) ||
                String(user.id).includes(searchTerm) ||
                (user.cpf && user.cpf.includes(searchTerm))
            );
            renderUsers(filteredUsers);
        }

        function editUser(id) {
            const user = usersData.find(u => u.id === id);
            if (!user) return;

            document.getElementById('editUserId').value = user.id;
            document.getElementById('editUsername').value = user.username;
            document.getElementById('editNomeCompleto').value = user.nome_completo;
            document.getElementById('editCpf').value = user.cpf;
            document.getElementById('editSaldoRecarga').value = parseFloat(user.saldo_recarga).toFixed(2);
            document.getElementById('editSaldoRetirada').value = parseFloat(user.saldo_retirada).toFixed(2);
            document.getElementById('editPassword').value = '';

            const modal = new bootstrap.Modal(document.getElementById('editUserModal'));
            modal.show();
        }

        function showDeleteUserModal(id) {
            userIdToDelete = id;
            const modal = new bootstrap.Modal(document.getElementById('deleteUserModal'));
            modal.show();
        }

        async function showPixModal(userId) {
            document.getElementById('editPixUserId').value = userId;
            const pixKeysList = document.getElementById('pix-keys-list');
            pixKeysList.innerHTML = '<div class="text-center"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Carregando...</span></div></div>';

            try {
                const response = await axios.get(`api_pix.php?uid=${userId}`);
                const pixKeys = response.data;

                if (pixKeys.length === 0) {
                    pixKeysList.innerHTML = '<p class="text-center text-muted">Nenhuma chave Pix encontrada.</p>';
                } else {
                    pixKeysList.innerHTML = '';
                    pixKeys.forEach(key => {
                        const keyHtml = `
                            <div class="card">
                                <div class="card-body">
                                    <form onsubmit="handleEditPixForm(event, ${key.id}, ${userId})">
                                        <div class="row">
                                            <div class="col-md-6 mb-2">
                                                <label class="form-label">Chave Pix</label>
                                                <input type="text" class="form-control form-control-sm" id="chave_pix-${key.id}" value="${key.chave_pix}" required>
                                            </div>
                                            <div class="col-md-6 mb-2">
                                                <label class="form-label">CPF</label>
                                                <input type="text" class="form-control form-control-sm" id="cpf-${key.id}" value="${key.cpf}" required>
                                            </div>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Nome Completo</label>
                                            <input type="text" class="form-control form-control-sm" id="nome_completo-${key.id}" value="${key.nome_completo}" required>
                                        </div>
                                        <div class="d-flex gap-2 mt-3">
                                            <button type="submit" class="btn btn-primary btn-sm">Salvar</button>
                                            <button type="button" class="btn btn-danger btn-sm" onclick="deletePixKey(${key.id})">Excluir</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        `;
                        pixKeysList.innerHTML += keyHtml;
                    });
                }
            } catch (error) {
                console.error('Erro ao buscar chaves Pix:', error);
                pixKeysList.innerHTML = '<p class="text-danger text-center">Erro ao carregar chaves.</p>';
            }

            const modal = new bootstrap.Modal(document.getElementById('editPixModal'));
            modal.show();
        }

        async function handleEditPixForm(event, keyId, userId) {
            event.preventDefault();
            const novaChave = document.getElementById(`chave_pix-${keyId}`).value;
            const novoCpf = document.getElementById(`cpf-${keyId}`).value;
            const novoNome = document.getElementById(`nome_completo-${keyId}`).value;

            try {
                const response = await axios.put(`api_pix.php?id=${keyId}`, {
                    chave_pix: novaChave,
                    cpf: novoCpf,
                    nome_completo: novoNome
                });
                if (response.data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: 'Chave Pix atualizada.',
                        timer: 1500,
                        showConfirmButton: false
                    });
                    showPixModal(userId);
                } else {
                    Swal.fire('Erro!', response.data.message, 'error');
                }
            } catch (error) {
                Swal.fire('Erro!', 'Não foi possível atualizar a chave.', 'error');
            }
        }

        async function deletePixKey(keyId) {
            const result = await Swal.fire({
                title: 'Tem certeza?',
                text: "Você não poderá reverter isso!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Sim, excluir!',
                cancelButtonText: 'Cancelar'
            });

            if (result.isConfirmed) {
                try {
                    const response = await axios.delete(`api_pix.php?id=${keyId}`);
                    if (response.data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Excluído!',
                            text: 'A chave Pix foi excluída.',
                            timer: 1500,
                            showConfirmButton: false
                        });
                        const userId = document.getElementById('editPixUserId').value;
                        showPixModal(userId);
                    } else {
                        Swal.fire('Erro!', response.data.message, 'error');
                    }
                } catch (error) {
                    Swal.fire('Erro!', 'Não foi possível excluir a chave.', 'error');
                }
            }
        }

        // Form submit handlers
        document.getElementById('editUserForm').addEventListener('submit', async (event) => {
            event.preventDefault();
            
            const userData = {
                username: document.getElementById('editUsername').value,
                nome_completo: document.getElementById('editNomeCompleto').value,
                cpf: document.getElementById('editCpf').value,
                saldo_recarga: parseFloat(document.getElementById('editSaldoRecarga').value),
                saldo_retirada: parseFloat(document.getElementById('editSaldoRetirada').value)
            };

            const password = document.getElementById('editPassword').value;
            if (password) userData.password = password;

            try {
                const id = document.getElementById('editUserId').value;
                const response = await axios.put(`api_user.php?id=${id}`, userData);

                if (response.data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        fetchUsers();
                        bootstrap.Modal.getInstance(document.getElementById('editUserModal')).hide();
                    });
                } else {
                    Swal.fire('Erro!', response.data.message, 'error');
                }
            } catch (error) {
                Swal.fire('Erro!', 'Ocorreu um erro ao editar o usuário.', 'error');
            }
        });

        document.getElementById('confirmDeleteUserBtn').addEventListener('click', async () => {
            if (!userIdToDelete) return;

            try {
                const response = await axios.delete(`api_user.php?id=${userIdToDelete}`);
                if (response.data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        fetchUsers();
                        bootstrap.Modal.getInstance(document.getElementById('deleteUserModal')).hide();
                        userIdToDelete = null;
                    });
                } else {
                    Swal.fire('Erro!', response.data.message, 'error');
                }
            } catch (error) {
                Swal.fire('Erro!', 'Ocorreu um erro ao excluir o usuário.', 'error');
            }
        });

        document.addEventListener('DOMContentLoaded', fetchUsers);
    </script>
</body>
</html>