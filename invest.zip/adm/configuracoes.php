<?php
session_start();

// Verifica se o administrador está logado. Se não, redireciona.
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

// Inclui o arquivo de conexão com o banco de dados.
require '../servidor/database.php';

// Conecta ao banco de dados usando PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("Erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}

// Consulta para buscar todas as configurações (gerais)
$stmt = $pdo->query("SELECT * FROM configuracoes ORDER BY id ASC LIMIT 1");
$configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);

// Consulta para buscar as configurações da BSPaybr
$stmtGateway = $pdo->query("SELECT * FROM gateway_bspaybr WHERE id = 1 LIMIT 1");
$gatewayBspaybr = $stmtGateway->fetch(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #2c3e50;
            --accent-color: #FFA500;
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- Navbar Styling --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
            font-size: 1.1rem;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important;
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e;
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* --- Main Content Container --- */
        .container.mt-5 {
            padding-top: 20px;
            padding-bottom: 20px;
        }

        /* --- Config Sections --- */
        .config-card {
            background: var(--white);
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .config-header {
            background: var(--secondary-color);
            color: var(--white);
            padding: 15px 20px;
            font-weight: 600;
            font-size: 1.1rem;
        }

        .config-content {
            padding: 20px;
        }

        .config-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }

        .config-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid var(--primary-color);
        }

        .config-label {
            font-weight: 500;
            color: var(--secondary-color);
        }

        .config-value {
            font-weight: 600;
            color: var(--text-dark);
            word-break: break-word;
            text-align: right;
        }

        /* --- Desktop Table Styling --- */
        .desktop-table {
            margin: 30px auto;
            max-width: 1200px;
            background-color: var(--white);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            animation: fadeIn 0.8s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 30px;
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }
        .table thead th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: 600;
            padding: 12px 15px;
            border-bottom: none;
            vertical-align: middle;
            text-align: center;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f1f4f8;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }
        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }
        .gateway-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 12px;
            margin-top: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .gateway-info h4 {
            font-weight: 600;
            margin-bottom: 5px;
        }
        .gateway-info p {
            font-size: 0.9rem;
            color: #6c757d;
        }
        .gateway-info strong {
            color: var(--primary-color);
        }

        /* --- Mobile Layout (Hidden by default) --- */
        .mobile-layout {
            display: none;
        }

        .mobile-config-sections {
            padding: 10px;
        }

        .config-section {
            background: var(--white);
            border-radius: 12px;
            margin-bottom: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .section-header {
            background: var(--secondary-color);
            color: var(--white);
            padding: 12px 15px;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .section-content {
            padding: 0;
        }

        .mobile-config-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 15px;
            border-bottom: 1px solid #f1f1f1;
            font-size: 0.85rem;
        }

        .mobile-config-item:last-child {
            border-bottom: none;
        }

        .edit-button-container {
            background: #f8f9fa;
            padding: 15px;
            text-align: center;
        }

        .btn-edit-mobile {
            background: var(--accent-color);
            color: var(--text-dark);
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            width: 100%;
            max-width: 200px;
        }
        
        .bspaybr-link {
            font-size: 0.9rem;
            color: #007bff;
            text-decoration: underline;
            margin-top: 15px;
            display: block;
        }
        .bspaybr-link:hover {
            color: #0056b3;
        }
        .bspaybr-message {
            color: #212529;
            font-size: 0.9rem;
            margin-bottom: 10px;
        }

        /* --- Button Styles --- */
        .btn {
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 6px;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: #43a047;
            border-color: #43a047;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-warning {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            color: var(--text-dark);
        }
        .btn-warning:hover {
            background-color: #e69500;
            border-color: #e69500;
            transform: translateY(-1px);
        }

        /* --- Modal Styling --- */
        .modal-content {
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: none;
        }
        .modal-header {
            background-color: var(--secondary-color);
            color: var(--white);
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            padding: 15px 20px;
            border-bottom: none;
        }
        .modal-title {
            font-weight: 600;
            font-size: 1.25rem;
        }
        .modal-body {
            padding: 25px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-label {
            font-weight: 500;
            color: var(--secondary-color);
        }
        .form-control {
            border-radius: 8px;
            padding: 10px 12px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(76, 175, 80, 0.25);
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 15px 20px;
        }

        /* --- Mobile Responsive CSS --- */
        @media (max-width: 768px) {
            .desktop-table {
                display: none;
            }

            .mobile-layout {
                display: block;
            }

            .config-grid {
                grid-template-columns: 1fr;
            }

            h2 {
                font-size: 1.3rem;
                text-align: center;
                margin-bottom: 20px;
            }

            .navbar-brand {
                font-size: 1rem;
            }

            .navbar-collapse {
                margin-top: 10px;
            }

            .navbar-nav .nav-item {
                margin: 2px 0;
            }

            .navbar-nav .nav-link {
                padding: 8px 12px;
                margin: 0;
                border-radius: 6px;
                font-size: 0.9rem;
            }

            .modal-dialog {
                margin: 15px;
                max-width: calc(100% - 30px);
            }

            .modal-body {
                padding: 20px 15px;
            }

            .form-control {
                padding: 12px;
                font-size: 16px; /* Prevents zoom on iOS */
            }

            .btn-primary.w-100 {
                padding: 12px;
                font-size: 1rem;
            }

            .container.mt-5 {
                padding: 10px;
                margin-top: 1rem !important;
            }
        }

        @media (max-width: 480px) {
            .mobile-config-item {
                padding: 10px 12px;
                font-size: 0.8rem;
            }

            .config-label {
                max-width: 50%;
                font-size: 0.8rem;
            }

            .config-value {
                font-size: 0.8rem;
            }

            .section-header {
                padding: 10px 12px;
                font-size: 0.85rem;
            }

            h2 {
                font-size: 1.2rem;
                margin-bottom: 15px;
            }

            .btn-edit-mobile {
                padding: 10px 25px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="container mt-5">
        <h2>Configurações do Sistema</h2>
        
        <div class="desktop-table">
            <!-- Configurações do Site -->
            <div class="config-card">
                <div class="config-header">
                    Configurações do Site
                </div>
                <div class="config-content">
                    <div class="config-grid">
                        <div class="config-item">
                            <span class="config-label">Nome do Site:</span>
                            <span class="config-value"><?php echo htmlspecialchars($configuracoes['site_name'] ?? 'Não configurado'); ?></span>
                        </div>
                        <div class="config-item">
                            <span class="config-label">Título da Página:</span>
                            <span class="config-value"><?php echo htmlspecialchars($configuracoes['site_title'] ?? 'Não configurado'); ?></span>
                        </div>
                        <div class="config-item">
                            <span class="config-label">Banner Principal:</span>
                            <span class="config-value">
                                <?php if (!empty($configuracoes['banner_image'])): ?>
                                    <img src="<?php echo htmlspecialchars($configuracoes['banner_image']); ?>" style="max-width: 100px; height: auto; border-radius: 4px;">
                                <?php else: ?>
                                    Não configurado
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="config-item">
                            <span class="config-label">Check-in Título:</span>
                            <span class="config-value"><?php echo htmlspecialchars($configuracoes['checkin_title'] ?? 'Não configurado'); ?></span>
                        </div>
                        <div class="config-item">
                            <span class="config-label">Check-in Subtítulo:</span>
                            <span class="config-value"><?php echo htmlspecialchars($configuracoes['checkin_subtitle'] ?? 'Não configurado'); ?></span>
                        </div>
                        <div class="config-item">
                            <span class="config-label">Mensagens do Ticker:</span>
                            <span class="config-value">
                                <?php 
                                $messages = array_filter([
                                    $configuracoes['ticker_message_1'] ?? '',
                                    $configuracoes['ticker_message_2'] ?? '',
                                    $configuracoes['ticker_message_3'] ?? ''
                                ]);
                                echo count($messages) . ' mensagens configuradas';
                                ?>
                            </span>
                        </div>
                    </div>
                    <button class="btn btn-warning" onclick="editSiteConfig(<?php echo htmlspecialchars(json_encode($configuracoes), ENT_QUOTES, 'UTF-8'); ?>)">
                        Editar Configurações do Site
                    </button>
                </div>
            </div>

            <!-- Configurações Gerais -->
            <div class="config-card">
                <div class="config-header">
                    Configurações Gerais do Sistema
                </div>
                <div class="config-content">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Telegram</th>
                                <th>WhatsApp</th>
                                <th>Saque Mín.</th>
                                <th>Recarga Mín.</th>
                                <th>Taxa Saque (%)</th>
                                <th>Nível LV1 (%)</th>
                                <th>Nível LV2 (%)</th>
                                <th>Nível LV3 (%)</th>
                                <th>Saque Diário Máx.</th>
                                <th>Saque Máx. por Transação</th>
                                <th>Permitir Saque 24h</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($configuracoes): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($configuracoes['telegram']); ?></td>
                                    <td><?php echo htmlspecialchars($configuracoes['whatsapp']); ?></td>
                                    <td>R$ <?php echo number_format($configuracoes['saque_minimo'], 2, ',', '.'); ?></td>
                                    <td>R$ <?php echo number_format($configuracoes['recarga_minima'], 2, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($configuracoes['taxa_saque']); ?>%</td>
                                    <td><?php echo htmlspecialchars($configuracoes['lv1']); ?>%</td>
                                    <td><?php echo htmlspecialchars($configuracoes['lv2']); ?>%</td>
                                    <td><?php echo htmlspecialchars($configuracoes['lv3']); ?>%</td>
                                    <td>R$ <?php echo number_format($configuracoes['saque_diario_max'], 2, ',', '.'); ?></td>
                                    <td>R$ <?php echo number_format($configuracoes['saque_maximo_por_transacao'], 2, ',', '.'); ?></td>
                                    <td><?php echo ($configuracoes['permitir_saque_24h'] ? 'Sim' : 'Não'); ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" onclick="editConfig(<?php echo htmlspecialchars(json_encode($configuracoes), ENT_QUOTES, 'UTF-8'); ?>)">Editar</button>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="12" class="text-center py-4">Nenhuma configuração encontrada.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="gateway-section">
                <div class="gateway-info">
                    <h4>Gateway de Pagamento: <strong>BSPaybr</strong></h4>
                    <p>Client ID: <span><?php echo htmlspecialchars($gatewayBspaybr['client_id'] ?? 'Não configurado'); ?></span></p>
                    <p>Client Secret: <span><?php echo htmlspecialchars(substr($gatewayBspaybr['client_secret'] ?? '', 0, 5) . '...' ?? 'Não configurado'); ?></span></p>
                    <p>URL de Notificação: <span><?php echo htmlspecialchars($gatewayBspaybr['urlnoty'] ?? 'Não configurada'); ?></span></p>
                    <p class="bspaybr-message">
                        ? Precisa de uma conta na Bspaybr, valor de abertura 100 reais, 
                        <a href="https://bspaybr.com/register" class="bspaybr-link" target="_blank">Clique aqui</a>
                    </p>
                </div>
                <div class="gateway-actions">
                    <button class="btn btn-warning" onclick="editGateway(<?php echo htmlspecialchars(json_encode($gatewayBspaybr), ENT_QUOTES, 'UTF-8'); ?>)">Editar Gateway</button>
                </div>
            </div>
        </div>

        <div class="mobile-layout">
            <?php if ($configuracoes): ?>
                <div class="mobile-config-sections">
                    <!-- Configurações do Site - Mobile -->
                    <div class="config-section">
                        <div class="section-header">Configurações do Site</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Nome do Site</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['site_name'] ?? 'Não configurado'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Título da Página</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['site_title'] ?? 'Não configurado'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Check-in Título</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['checkin_title'] ?? 'Não configurado'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Check-in Subtítulo</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['checkin_subtitle'] ?? 'Não configurado'); ?></span>
                            </div>
                        </div>
                        <div class="edit-button-container">
                            <button class="btn-edit-mobile" onclick="editSiteConfig(<?php echo htmlspecialchars(json_encode($configuracoes), ENT_QUOTES, 'UTF-8'); ?>)">Editar Configurações do Site</button>
                        </div>
                    </div>

                    <div class="config-section">
                        <div class="section-header">Contatos de Suporte</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Telegram</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['telegram']); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">WhatsApp</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['whatsapp']); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="config-section">
                        <div class="section-header">Valores e Taxas</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Saque Mínimo</span>
                                <span class="config-value">R$ <?php echo number_format($configuracoes['saque_minimo'], 2, ',', '.'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Recarga Mínima</span>
                                <span class="config-value">R$ <?php echo number_format($configuracoes['recarga_minima'], 2, ',', '.'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Taxa de Saque</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['taxa_saque']); ?>%</span>
                            </div>
                        </div>
                    </div>

                    <div class="config-section">
                        <div class="section-header">Níveis VIP (%)</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Nível LV1</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['lv1']); ?>%</span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Nível LV2</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['lv2']); ?>%</span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Nível LV3</span>
                                <span class="config-value"><?php echo htmlspecialchars($configuracoes['lv3']); ?>%</span>
                            </div>
                        </div>
                    </div>

                    <div class="config-section">
                        <div class="section-header">Limites de Saque</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Saque Diário Máx.</span>
                                <span class="config-value">R$ <?php echo number_format($configuracoes['saque_diario_max'], 2, ',', '.'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Saque Máx. por Transação</span>
                                <span class="config-value">R$ <?php echo number_format($configuracoes['saque_maximo_por_transacao'], 2, ',', '.'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Permitir Saque 24h</span>
                                <span class="config-value"><?php echo ($configuracoes['permitir_saque_24h'] ? 'Sim' : 'Não'); ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="config-section">
                        <div class="section-header">Gateway BSPaybr</div>
                        <div class="section-content">
                            <div class="mobile-config-item">
                                <span class="config-label">Client ID</span>
                                <span class="config-value"><?php echo htmlspecialchars($gatewayBspaybr['client_id'] ?? 'Não configurado'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">Client Secret</span>
                                <span class="config-value"><?php echo htmlspecialchars(substr($gatewayBspaybr['client_secret'] ?? '', 0, 5) . '...' ?? 'Não configurado'); ?></span>
                            </div>
                            <div class="mobile-config-item">
                                <span class="config-label">URL de Notificação</span>
                                <span class="config-value"><?php echo htmlspecialchars($gatewayBspaybr['urlnoty'] ?? 'Não configurada'); ?></span>
                            </div>
                        </div>
                        <div class="edit-button-container">
                             <p class="bspaybr-message">
                                ? Precisa de uma conta na Bspaybr, valor de abertura 100 reais, 
                                <a href="https://bspaybr.com/register" class="bspaybr-link" target="_blank">Clique aqui</a>
                            </p>
                            <button class="btn-edit-mobile" onclick="editGateway(<?php echo htmlspecialchars(json_encode($gatewayBspaybr), ENT_QUOTES, 'UTF-8'); ?>)">Editar Gateway</button>
                        </div>
                    </div>

                    <div class="edit-button-container">
                        <button class="btn-edit-mobile" onclick="editConfig(<?php echo htmlspecialchars(json_encode($configuracoes), ENT_QUOTES, 'UTF-8'); ?>)">Editar Configurações Gerais</button>
                    </div>
                </div>
            <?php else: ?>
                <div class="config-section">
                    <div class="section-content">
                        <div style="text-align: center; padding: 30px; color: #666;">
                            Nenhuma configuração encontrada.
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Modal Configurações Gerais -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Editar Configurações Gerais</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm">
                        <input type="hidden" id="editId">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editTelegram" class="form-label">Telegram</label>
                                    <input type="text" class="form-control" id="editTelegram" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editWhatsapp" class="form-label">WhatsApp</label>
                                    <input type="text" class="form-control" id="editWhatsapp" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editSaqueMinimo" class="form-label">Saque Mínimo</label>
                                    <input type="number" step="0.01" class="form-control" id="editSaqueMinimo" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editRecargaMinima" class="form-label">Recarga Mínima</label>
                                    <input type="number" step="0.01" class="form-control" id="editRecargaMinima" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="editTaxaSaque" class="form-label">Taxa de Saque (%)</label>
                                    <input type="number" step="0.01" class="form-control" id="editTaxaSaque" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="editLv1" class="form-label">Nível LV1 (%)</label>
                                    <input type="number" step="0.01" class="form-control" id="editLv1" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="editLv2" class="form-label">Nível LV2 (%)</label>
                                    <input type="number" step="0.01" class="form-control" id="editLv2" required>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-3">
                                    <label for="editLv3" class="form-label">Nível LV3 (%)</label>
                                    <input type="number" step="0.01" class="form-control" id="editLv3" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editSaqueDiarioMax" class="form-label">Saque Diário Máximo por Usuário</label>
                                    <input type="number" step="0.01" class="form-control" id="editSaqueDiarioMax" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editSaqueMaximoPorTransacao" class="form-label">Saque Máximo por Transação</label>
                                    <input type="number" step="0.01" class="form-control" id="editSaqueMaximoPorTransacao" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="editPermitirSaque24h">
                                <label class="form-check-label" for="editPermitirSaque24h">Permitir Saques 24h (Ignorar horário restrito)</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Configurações do Site -->
    <div class="modal fade" id="editSiteModal" tabindex="-1" aria-labelledby="editSiteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editSiteModalLabel">Editar Configurações do Site</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editSiteForm">
                        <input type="hidden" id="editSiteId">
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editSiteName" class="form-label">Nome do Site (Logo)</label>
                                    <input type="text" class="form-control" id="editSiteName" required>
                                    <small class="form-text text-muted">Nome que aparece no cabeçalho</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editSiteTitle" class="form-label">Título da Página</label>
                                    <input type="text" class="form-control" id="editSiteTitle" required>
                                    <small class="form-text text-muted">Aparece na aba do navegador</small>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="editBannerImage" class="form-label">URL da Imagem do Banner</label>
                            <input type="url" class="form-control" id="editBannerImage" required>
                            <small class="form-text text-muted">URL da imagem principal do banner (750x200px recomendado)</small>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editFavicon" class="form-label">Favicon</label>
                                    <input type="text" class="form-control" id="editFavicon">
                                    <small class="form-text text-muted">Caminho para o ícone do site</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editCheckinButton" class="form-label">Texto do Botão Check-in</label>
                                    <input type="text" class="form-control" id="editCheckinButton" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editCheckinTitle" class="form-label">Título do Check-in</label>
                                    <input type="text" class="form-control" id="editCheckinTitle" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editCheckinSubtitle" class="form-label">Subtítulo do Check-in</label>
                                    <input type="text" class="form-control" id="editCheckinSubtitle" required>
                                </div>
                            </div>
                        </div>

                        <h6 class="mb-3">Mensagens do Banner Rolante:</h6>
                        <div class="mb-3">
                            <label for="editTickerMessage1" class="form-label">Mensagem 1</label>
                            <input type="text" class="form-control" id="editTickerMessage1" required>
                        </div>
                        <div class="mb-3">
                            <label for="editTickerMessage2" class="form-label">Mensagem 2</label>
                            <input type="text" class="form-control" id="editTickerMessage2" required>
                        </div>
                        <div class="mb-3">
                            <label for="editTickerMessage3" class="form-label">Mensagem 3</label>
                            <input type="text" class="form-control" id="editTickerMessage3" required>
                        </div>

                        <h6 class="mb-3">Configurações do Modal de Apresentação:</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalTitle" class="form-label">Título do Modal</label>
                                    <input type="text" class="form-control" id="editModalTitle">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalWelcome" class="form-label">Mensagem de Boas-vindas</label>
                                    <input type="text" class="form-control" id="editModalWelcome">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalBonusRegister" class="form-label">Bônus de Cadastro</label>
                                    <input type="text" class="form-control" id="editModalBonusRegister">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalDailyLogin" class="form-label">Login Diário</label>
                                    <input type="text" class="form-control" id="editModalDailyLogin">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalCommission" class="form-label">Comissão</label>
                                    <input type="text" class="form-control" id="editModalCommission">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editModalTelegram" class="form-label">Telegram</label>
                                    <input type="text" class="form-control" id="editModalTelegram">
                                </div>
                            </div>
                        </div>

                        <h6 class="mb-3">Check-in de Sucesso:</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editCheckinSuccessTitle" class="form-label">Título de Sucesso</label>
                                    <input type="text" class="form-control" id="editCheckinSuccessTitle">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="editCheckinSuccessMessage" class="form-label">Mensagem de Sucesso</label>
                                    <input type="text" class="form-control" id="editCheckinSuccessMessage">
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Salvar Configurações do Site</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal Gateway -->
    <div class="modal fade" id="editGatewayModal" tabindex="-1" aria-labelledby="editGatewayModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editGatewayModalLabel">Editar Gateway BSPaybr</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editGatewayForm">
                        <input type="hidden" id="editGatewayId" name="id">
                        <div class="mb-3">
                            <label for="editGatewayClientId" class="form-label">Client ID</label>
                            <input type="text" class="form-control" id="editGatewayClientId" name="client_id" required>
                        </div>
                        <div class="mb-3">
                            <label for="editGatewayClientSecret" class="form-label">Client Secret</label>
                            <input type="text" class="form-control" id="editGatewayClientSecret" name="client_secret" required>
                        </div>
                        <div class="mb-3">
                            <label for="editGatewayUrlNoty" class="form-label">URL de Notificação (Webhook)</label>
                            <input type="text" class="form-control" id="editGatewayUrlNoty" name="urlnoty" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Salvar Alterações do Gateway</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            let currentConfigId = null;
            let currentGatewayId = null;

            // Função para abrir o modal de configurações gerais
            window.editConfig = function(config) {
                currentConfigId = config.id;
                document.getElementById('editId').value = config.id;
                document.getElementById('editTelegram').value = config.telegram;
                document.getElementById('editWhatsapp').value = config.whatsapp;
                document.getElementById('editSaqueMinimo').value = config.saque_minimo;
                document.getElementById('editRecargaMinima').value = config.recarga_minima;
                document.getElementById('editTaxaSaque').value = config.taxa_saque;
                document.getElementById('editLv1').value = config.lv1;
                document.getElementById('editLv2').value = config.lv2;
                document.getElementById('editLv3').value = config.lv3;
                document.getElementById('editSaqueDiarioMax').value = config.saque_diario_max;
                document.getElementById('editSaqueMaximoPorTransacao').value = config.saque_maximo_por_transacao;
                document.getElementById('editPermitirSaque24h').checked = config.permitir_saque_24h == 1;
                
                const modal = new bootstrap.Modal(document.getElementById('editModal'));
                modal.show();
            }

            // Função para abrir o modal de configurações do site
            window.editSiteConfig = function(config) {
                currentConfigId = config.id;
                document.getElementById('editSiteId').value = config.id;
                document.getElementById('editSiteName').value = config.site_name || '';
                document.getElementById('editSiteTitle').value = config.site_title || '';
                document.getElementById('editBannerImage').value = config.banner_image || '';
                document.getElementById('editFavicon').value = config.favicon || '';
                document.getElementById('editCheckinTitle').value = config.checkin_title || '';
                document.getElementById('editCheckinSubtitle').value = config.checkin_subtitle || '';
                document.getElementById('editCheckinButton').value = config.checkin_button || '';
                document.getElementById('editTickerMessage1').value = config.ticker_message_1 || '';
                document.getElementById('editTickerMessage2').value = config.ticker_message_2 || '';
                document.getElementById('editTickerMessage3').value = config.ticker_message_3 || '';
                document.getElementById('editModalTitle').value = config.modal_title || '';
                document.getElementById('editModalWelcome').value = config.modal_welcome || '';
                document.getElementById('editModalBonusRegister').value = config.modal_bonus_register || '';
                document.getElementById('editModalDailyLogin').value = config.modal_daily_login || '';
                document.getElementById('editModalCommission').value = config.modal_commission || '';
                document.getElementById('editModalTelegram').value = config.modal_telegram || '';
                document.getElementById('editCheckinSuccessTitle').value = config.checkin_success_title || '';
                document.getElementById('editCheckinSuccessMessage').value = config.checkin_success_message || '';
                
                const modal = new bootstrap.Modal(document.getElementById('editSiteModal'));
                modal.show();
            }

            // Função para abrir o modal de credenciais do Gateway
            window.editGateway = function(gateway) {
                currentGatewayId = gateway.id || 1;
                document.getElementById('editGatewayId').value = currentGatewayId;
                document.getElementById('editGatewayClientId').value = gateway.client_id;
                document.getElementById('editGatewayClientSecret').value = gateway.client_secret;
                document.getElementById('editGatewayUrlNoty').value = gateway.urlnoty;

                const modal = new bootstrap.Modal(document.getElementById('editGatewayModal'));
                modal.show();
            }

            // Evento de submit para o formulário de configurações gerais
            document.getElementById('editForm').addEventListener('submit', function(event) {
                event.preventDefault();
                if (currentConfigId !== null) {
                    const updatedConfig = {
                        id: currentConfigId,
                        telegram: document.getElementById('editTelegram').value,
                        whatsapp: document.getElementById('editWhatsapp').value,
                        saque_minimo: parseFloat(document.getElementById('editSaqueMinimo').value),
                        recarga_minima: parseFloat(document.getElementById('editRecargaMinima').value),
                        taxa_saque: parseFloat(document.getElementById('editTaxaSaque').value),
                        lv1: parseFloat(document.getElementById('editLv1').value),
                        lv2: parseFloat(document.getElementById('editLv2').value),
                        lv3: parseFloat(document.getElementById('editLv3').value),
                        saque_diario_max: parseFloat(document.getElementById('editSaqueDiarioMax').value),
                        saque_maximo_por_transacao: parseFloat(document.getElementById('editSaqueMaximoPorTransacao').value),
                        permitir_saque_24h: document.getElementById('editPermitirSaque24h').checked ? 1 : 0
                    };
                    
                    axios.put('api_config.php', updatedConfig)
                        .then(response => {
                            if (response.data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Sucesso!',
                                    text: response.data.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Erro!',
                                    text: response.data.message,
                                    showConfirmButton: true
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Erro ao salvar configuração:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro de Requisição',
                                text: 'Ocorreu um erro ao salvar a configuração. Tente novamente.',
                                showConfirmButton: true
                            });
                        });
                }
            });

            // Evento de submit para o formulário de configurações do site
            document.getElementById('editSiteForm').addEventListener('submit', function(event) {
                event.preventDefault();
                if (currentConfigId !== null) {
                    const updatedSiteConfig = {
                        id: currentConfigId,
                        site_name: document.getElementById('editSiteName').value,
                        site_title: document.getElementById('editSiteTitle').value,
                        banner_image: document.getElementById('editBannerImage').value,
                        favicon: document.getElementById('editFavicon').value,
                        checkin_title: document.getElementById('editCheckinTitle').value,
                        checkin_subtitle: document.getElementById('editCheckinSubtitle').value,
                        checkin_button: document.getElementById('editCheckinButton').value,
                        ticker_message_1: document.getElementById('editTickerMessage1').value,
                        ticker_message_2: document.getElementById('editTickerMessage2').value,
                        ticker_message_3: document.getElementById('editTickerMessage3').value,
                        modal_title: document.getElementById('editModalTitle').value,
                        modal_welcome: document.getElementById('editModalWelcome').value,
                        modal_bonus_register: document.getElementById('editModalBonusRegister').value,
                        modal_daily_login: document.getElementById('editModalDailyLogin').value,
                        modal_commission: document.getElementById('editModalCommission').value,
                        modal_telegram: document.getElementById('editModalTelegram').value,
                        checkin_success_title: document.getElementById('editCheckinSuccessTitle').value,
                        checkin_success_message: document.getElementById('editCheckinSuccessMessage').value
                    };
                    
                    axios.put('api_site_config.php', updatedSiteConfig)
                        .then(response => {
                            if (response.data.success) {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Sucesso!',
                                    text: response.data.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Erro!',
                                    text: response.data.message,
                                    showConfirmButton: true
                                });
                            }
                        })
                        .catch(error => {
                            console.error('Erro ao salvar configurações do site:', error);
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro de Requisição',
                                text: 'Ocorreu um erro ao salvar as configurações do site. Tente novamente.',
                                showConfirmButton: true
                            });
                        });
                }
            });
            
            // Evento de submit para o formulário de credenciais do Gateway
            document.getElementById('editGatewayForm').addEventListener('submit', function(event) {
                event.preventDefault();
                
                const updatedGateway = {
                    id: document.getElementById('editGatewayId').value,
                    client_id: document.getElementById('editGatewayClientId').value,
                    client_secret: document.getElementById('editGatewayClientSecret').value,
                    urlnoty: document.getElementById('editGatewayUrlNoty').value
                };

                axios.put('api_gateway.php', updatedGateway)
                .then(response => {
                    if (response.data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso!',
                            text: response.data.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: response.data.message,
                            showConfirmButton: true
                        });
                    }
                })
                .catch(error => {
                    console.error('Erro ao salvar credenciais do gateway:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro de Requisição',
                        text: 'Ocorreu um erro ao salvar as credenciais. Tente novamente.',
                        showConfirmButton: true
                    });
                });
            });
        });
    </script>
</body>
</html>