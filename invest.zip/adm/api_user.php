<?php

header('Content-Type: application/json');
require '../servidor/database.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Erro ao conectar ao banco de dados: ' . $e->getMessage()]);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $stmt = $pdo->prepare('SELECT id, username, nome_completo, cpf, saldo_recarga, saldo_retirada FROM usuarios WHERE id = ?');
            $stmt->execute([$_GET['id']]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode($usuario);
        } else {
            $stmt = $pdo->query('SELECT id, username, nome_completo, cpf, saldo_recarga, saldo_retirada FROM usuarios');
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($usuarios);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['username'], $data['password'], $data['nome_completo'], $data['cpf'])) {
            echo json_encode(['error' => 'Campos obrigatórios: username, password, nome_completo, cpf']);
            exit;
        }
        $stmt = $pdo->prepare('INSERT INTO usuarios (username, password, nome_completo, cpf, saldo_recarga, saldo_retirada, id_patrocinador, codigo_convite, total_investido) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([
            $data['username'],
            password_hash($data['password'], PASSWORD_BCRYPT),
            $data['nome_completo'],
            $data['cpf'],
            $data['saldo_recarga'] ?? 0.00,
            $data['saldo_retirada'] ?? 0.00,
            $data['id_patrocinador'] ?? null,
            $data['codigo_convite'] ?? null,
            $data['total_investido'] ?? 0.00
        ]);
        echo json_encode(['success' => 'Usuário criado com sucesso']);
        break;

    case 'PUT':
        if (!isset($_GET['id'])) {
            echo json_encode(['error' => 'ID do usuário é necessário']);
            exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        
        // CORREÇÃO: Incluindo nome_completo e cpf na lista de campos a serem atualizados
        $fields = [
            'username' => $data['username'] ?? null,
            'nome_completo' => $data['nome_completo'] ?? null,
            'cpf' => $data['cpf'] ?? null,
            'saldo_recarga' => $data['saldo_recarga'] ?? null,
            'saldo_retirada' => $data['saldo_retirada'] ?? null,
            'id_patrocinador' => $data['id_patrocinador'] ?? null,
            'codigo_convite' => $data['codigo_convite'] ?? null,
            'total_investido' => $data['total_investido'] ?? null,
        ];

        $setClause = [];
        $params = [];

        foreach ($fields as $key => $value) {
            if ($value !== null) {
                $setClause[] = "$key = ?";
                $params[] = $value;
            }
        }

        if (isset($data['password']) && !empty($data['password'])) {
            $setClause[] = "password = ?";
            $params[] = password_hash($data['password'], PASSWORD_BCRYPT);
        }

        if (empty($setClause)) {
            echo json_encode(['error' => 'Nenhum dado para atualizar']);
            exit;
        }

        $setClause = implode(', ', $setClause);
        $params[] = $_GET['id'];

        $stmt = $pdo->prepare("UPDATE usuarios SET $setClause WHERE id = ?");
        $stmt->execute($params);

        echo json_encode(['success' => true, 'message' => 'Usuário atualizado com sucesso']);
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            echo json_encode(['error' => 'ID do usuário é necessário']);
            exit;
        }
        $stmt = $pdo->prepare('DELETE FROM usuarios WHERE id = ?');
        $stmt->execute([$_GET['id']]);
        echo json_encode(['success' => true, 'message' => 'Usuário excluído com sucesso']);
        break;

    default:
        echo json_encode(['error' => 'Método HTTP não suportado']);
        break;
}