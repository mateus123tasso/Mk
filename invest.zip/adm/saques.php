<?php
session_start();

// Define o arquivo de log específico para saques.php
define('LOG_FILE_SAQUES', __DIR__ . '/saques.log');

/**
 * Função para registrar mensagens no log do saques.php.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_log_saques($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(LOG_FILE_SAQUES, $log_entry, FILE_APPEND);
}

// Removendo o log de início de requisição GET, pois ele é desnecessário
// write_log_saques("Início da requisição para saques.php. Método: " . $_SERVER['REQUEST_METHOD'], 'DEBUG');

// Verifica se o administrador está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['admin_logged_in'])) {
    write_log_saques("Tentativa de acesso não autenticado a saques.php. Redirecionando.", 'INFO');
    header("Location: login.html"); // Ajuste o caminho conforme sua estrutura real
    exit();
}
write_log_saques("Administrador autenticado. Processando requisição.", 'INFO');

// Inclui o arquivo de conexão com o banco de dados e as credenciais da PixUp.
require_once '../servidor/database.php';

// Verifica se a conexão com o banco de dados foi estabelecida.
if (!isset($conn) || $conn->connect_error) {
    $error_message = "Falha na conexão com o banco de dados: " . ($conn->connect_error ?? 'Erro desconhecido');
    write_log_saques($error_message, 'CRITICAL');
    die("Erro interno do servidor. Por favor, tente novamente mais tarde.");
}

// Configura o fuso horário para o log
date_default_timezone_set('America/Fortaleza');

// Variável para armazenar mensagens de feedback para o usuário
$feedback_message = '';
$feedback_type = ''; // 'success' ou 'error'
$novoStatus = ''; // Para o frontend saber o novo status

// Flag para identificar se a requisição é AJAX
$is_ajax_request = isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

// --- Lógica para responder a requisições GET de status (para o polling JavaScript) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_statuses') {
    $ids = $_GET['ids'] ?? '';
    $idArray = array_map('intval', array_filter(explode(',', $ids)));

    if (!empty($idArray)) {
        $placeholders = implode(',', array_fill(0, count($idArray), '?'));
        $sql = "SELECT id, status FROM transacoes_retirada WHERE id IN ($placeholders)";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $types = str_repeat('i', count($idArray));
            $stmt->bind_param($types, ...$idArray);
            $stmt->execute();
            $result = $stmt->get_result();
            $updatedStatuses = [];
            while ($row = $result->fetch_assoc()) {
                $updatedStatuses[] = $row;
            }
            $stmt->close();
            
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'statuses' => $updatedStatuses]);
            exit();
        } else {
            write_log_saques("Erro ao preparar consulta de status para polling: " . $conn->error, 'ERROR');
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao preparar consulta.']);
            exit();
        }
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'statuses' => []]);
        exit();
    }
}
// --- Fim da Lógica de Polling GET ---


// --- Início da Lógica de Processamento de Ações (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    write_log_saques("Requisição POST recebida. Ação: " . ($_POST['action'] ?? 'N/A') . ". Transaction ID: " . ($_POST['transaction_id'] ?? 'N/A'), 'DEBUG');

    $id = $_POST['transaction_id'] ?? null;
    $action = $_POST['action'] ?? null;

    if ($id === null || $action === null) {
        $feedback_message = 'Dados inválidos para a ação.';
        $feedback_type = 'error';
        write_log_saques("Erro: Dados POST inválidos para ação. ID: " . var_export($id, true) . ", Ação: " . var_export($action, true), 'WARNING');
    } else {
        $conn->begin_transaction();
        write_log_saques("Transação DB iniciada para ID: {$id}, Ação: {$action}", 'DEBUG');

        try {
            $sqlTransacao = "SELECT tr.usuario_id, tr.valor_retirada, tr.chave_pix, tr.status AS current_status, tr.total_recebido,
                             u.cpf, u.nome_completo, u.saldo_recarga
                             FROM transacoes_retirada tr
                             JOIN usuarios u ON tr.usuario_id = u.id
                             WHERE tr.id = ? FOR UPDATE";
            $stmtTransacao = $conn->prepare($sqlTransacao);

            if (!$stmtTransacao) {
                $error_msg = "Erro ao preparar consulta de transação: " . $conn->error;
                write_log_saques($error_msg, 'ERROR');
                throw new Exception('Erro ao preparar a consulta da transação: ' . $conn->error);
            }

            $stmtTransacao->bind_param("i", $id);
            $stmtTransacao->execute();
            $resultTransacao = $stmtTransacao->get_result();

            if ($resultTransacao->num_rows === 0) {
                write_log_saques("Transação ID {$id} não encontrada no DB.", 'WARNING');
                throw new Exception('Transação não encontrada.');
            }

            $transacao = $resultTransacao->fetch_assoc();
            $usuarioId = $transacao['usuario_id'];
            $valorRetirada = $transacao['valor_retirada'];
            $chavePix = $transacao['chave_pix'];
            $cpfUsuario = $transacao['cpf'];
            $nomeCompletoUsuario = $transacao['nome_completo'];
            $statusAtualDB = $transacao['current_status'];
            $totalRecebido = $transacao['total_recebido'];
            $stmtTransacao->close();
            write_log_saques("Dados da transação ID {$id} obtidos. Status atual: {$statusAtualDB}", 'DEBUG');

            $message = '';
            $novoStatus = $statusAtualDB;

            switch ($action) {
                case 'solicit_bspaybr':
                    write_log_saques("Ação: Iniciando solicitação de pagamento BSPay BR para saque ID {$id}.", 'INFO');

                    if ($statusAtualDB !== 'pendente' && $statusAtualDB !== 'cancelada' && $statusAtualDB !== 'processando_bspaybr') {
                        throw new Exception("Esta transação não pode ser processada pela BSPay BR no status atual: {$statusAtualDB}.");
                    }
                    
                    $stmt = $conn->prepare("SELECT client_id, client_secret, urlnoty FROM gateway_bspaybr WHERE id = 1 LIMIT 1");
                    $stmt->execute();
                    $gatewayCreds = $stmt->get_result()->fetch_assoc();
                    $stmt->close();
                    
                    if (!$gatewayCreds || empty($gatewayCreds['client_id']) || empty($gatewayCreds['client_secret'])) {
                        throw new Exception("Credenciais da BSPay BR não configuradas no banco de dados.");
                    }
                    
                    $CLIENT_ID_BSPAYBR = $gatewayCreds['client_id'];
                    $CLIENT_SECRET_BSPAYBR = $gatewayCreds['client_secret'];
                    $BSPAYBR_URL_API = 'https://bspaybr.com/v3/pix/payment';
                    $BSPAYBR_WEBHOOK_URL_SAQUE = $gatewayCreds['urlnoty'];
                    
                    $externalId = "saque_" . $id;

                    $payload = [
                        'client_id' => $CLIENT_ID_BSPAYBR,
                        'client_secret' => $CLIENT_SECRET_BSPAYBR,
                        'nome' => $nomeCompletoUsuario,
                        'cpf' => $cpfUsuario,
                        'valor' => number_format($totalRecebido, 2, '.', ''),
                        'chave_pix' => $chavePix,
                        'urlnoty' => $BSPAYBR_WEBHOOK_URL_SAQUE,
                        'external_id' => $externalId
                    ];
                    
                    write_log_saques("Chamando BSPay BR PIX Payment para saque ID {$id}. Dados: " . json_encode($payload), 'DEBUG');

                    $ch = curl_init($BSPAYBR_URL_API);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/x-www-form-urlencoded',
                        'User-Agent: SeuApp/1.0'
                    ]);
                    
                    $response = curl_exec($ch);
                    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curl_error = curl_error($ch);
                    curl_close($ch);

                    write_log_saques("Resposta BSPay BR PIX Payment para saque ID {$id}. HTTP: {$httpCode}. Erro cURL: '{$curl_error}'. Resposta: " . ($response ?: 'Vazio'), 'DEBUG');

                    if ($curl_error) {
                        throw new Exception("Erro de comunicação com a API BSPay BR (cURL Error): " . $curl_error);
                    }

                    $apiResponse = json_decode($response, true);
                    
                    if ($httpCode === 200 && isset($apiResponse['statusCode']) && $apiResponse['statusCode'] === 200) {
                        $novoStatus = 'processando_bspaybr';
                        $feedback_type = 'success';
                        $message = "Solicitação de pagamento PIX enviada à BSPay BR com sucesso! Status: Em Processamento (Aguardando Webhook).";
                        write_log_saques("Transação ID {$id} enviada para BSPay BR com sucesso. Status 'processando_bspaybr'.", 'INFO');
                        
                        $bspaybrTransactionId = $apiResponse['transactionId'] ?? null;
                        
                        $sqlUpdateTransaction = "UPDATE transacoes_retirada SET status = ?, data_envio_pixup = NOW()";
                        
                        if ($bspaybrTransactionId) {
                            $sqlUpdateTransaction .= ", bspaybr_payment_id = ?, external_id = ?";
                            $stmtUpdateTransaction = $conn->prepare($sqlUpdateTransaction . " WHERE id = ?");
                            $stmtUpdateTransaction->bind_param("sssi", $novoStatus, $bspaybrTransactionId, $externalId, $id);
                        } else {
                            write_log_saques("Aviso: BSPay BR não retornou 'transactionId' na resposta de sucesso para o saque ID {$id}. O webhook precisará usar o external_id '{$externalId}' como referência.", 'WARNING');
                            
                            $sqlUpdateTransaction = "UPDATE transacoes_retirada SET status = ?, data_envio_pixup = NOW(), external_id = ? WHERE id = ?";
                            $stmtUpdateTransaction = $conn->prepare($sqlUpdateTransaction);
                            $stmtUpdateTransaction->bind_param("ssi", $novoStatus, $externalId, $id);
                        }

                        if (!$stmtUpdateTransaction->execute()) {
                            throw new Exception("Erro ao atualizar o status da transação para 'processando_bspaybr': " . $conn->error);
                        }
                        $stmtUpdateTransaction->close();
                        write_log_saques("Status da transação ID {$id} atualizado para '{$novoStatus}'. bspaybr_payment_id salvo: " . ($bspaybrTransactionId ?? 'N/A'), 'INFO');
                        
                    } else {
                        $errorMessage = isset($apiResponse['message']) ? $apiResponse['message'] : 'Erro desconhecido na API BSPay BR.';
                        
                        $novoStatus = 'estornado';
                        
                        $sqlEstornarSaldo = "UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?";
                        $stmtEstornarSaldo = $conn->prepare($sqlEstornarSaldo);
                        if (!$stmtEstornarSaldo) {
                            throw new Exception("Erro ao preparar estorno de saldo: " . $conn->error);
                        }
                        $stmtEstornarSaldo->bind_param("di", $valorRetirada, $usuarioId);
                        $stmtEstornarSaldo->execute();
                        $stmtEstornarSaldo->close();
                        
                        write_log_saques("Saldo de R$ {$valorRetirada} estornado para usuário ID {$usuarioId} (saque {$id}) devido a falha na solicitação BSPayBR.", 'INFO');
                        
                        throw new Exception("Falha ao solicitar pagamento PIX à BSPay BR: " . $errorMessage . ". O saque foi estornado e o status atualizado para 'estornado'.");
                    }
                    break;
                
                case 'mark_paid_manual':
                    $novoStatus = 'pago';
                    write_log_saques("Ação: Marcar como pago MANUALMENTE saque ID {$id}. Novo status proposto: {$novoStatus}.", 'INFO');
                    if ($statusAtualDB !== 'pendente' && $statusAtualDB !== 'cancelada' && $statusAtualDB !== 'processando_bspaybr') {
                        throw new Exception("Esta transação não pode ser marcada como paga manualmente no status atual: {$statusAtualDB}.");
                    }
                    $message = "Transação marcada como paga manualmente com sucesso!";
                    $feedback_type = 'success';
                    break;

                case 'reject':
                    $novoStatus = 'cancelada';
                    write_log_saques("Ação: Recusar saque ID {$id}. Novo status proposto: {$novoStatus}.", 'INFO');
                    if ($statusAtualDB === 'pago' || $statusAtualDB === 'concluída' || $statusAtualDB === 'estornado') {
                        throw new Exception("Esta transação não pode ser recusada no status atual: {$statusAtualDB}. Use 'Estornar Pedido' se precisar devolver o saldo.");
                    }
                    $message = "Saque recusado. O status foi alterado para 'cancelada'. Se necessário, use a opção 'Estornar Pedido' para devolver o saldo ao usuário.";
                    $feedback_type = 'success';
                    break;

                case 'refund_withdrawal':
                    write_log_saques("Ação: Estornar saldo para saque ID {$id}.", 'INFO');
                    if ($statusAtualDB === 'pago' || $statusAtualDB === 'concluída' || $statusAtualDB === 'estornado') {
                        throw new Exception("Não é possível estornar o saldo de um saque que já foi pago ou já foi estornado. Isso exigiria uma transação inversa manual.");
                    }
                    
                    $sqlEstornarSaldo = "UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?";
                    $stmtEstornarSaldo = $conn->prepare($sqlEstornarSaldo);
                    
                    if (!$stmtEstornarSaldo) {
                        $error_msg = "Erro ao preparar estorno de saldo: " . $conn->error;
                        write_log_saques($error_msg, 'ERROR');
                        throw new Exception('Erro ao preparar estorno de saldo: ' . $conn->error);
                    }
                    $stmtEstornarSaldo->bind_param("di", $valorRetirada, $usuarioId);
                    if (!$stmtEstornarSaldo->execute()) {
                        $error_msg = "Erro ao estornar saldo do usuário ID {$usuarioId} para saque {$id}: " . $stmtEstornarSaldo->error;
                        write_log_saques($error_msg, 'ERROR');
                        throw new Exception('Erro ao estornar o saldo do usuário: ' . $stmtEstornarSaldo->error);
                    }
                    $stmtEstornarSaldo->close();
                    write_log_saques("Saldo de R$ {$valorRetirada} estornado para usuário ID {$usuarioId} (saque {$id}) via 'Estornar Pedido'.", 'INFO');
                    
                    $novoStatus = 'estornado';
                    $message = "Saldo de R$ {$valorRetirada} estornado para o usuário ID {$usuarioId}. Status da transação: 'estornado'.";
                    $feedback_type = 'success';
                    break;

                case 'delete':
                    write_log_saques("Ação: Deletar saque ID {$id}.", 'INFO');
                    if ($statusAtualDB === 'pago' || $statusAtualDB === 'concluída') {
                        throw new Exception("Não é possível deletar um saque que já foi pago. Se precisar, use 'Estornar Pedido' e depois delete a transação 'estornada'.");
                    }
                    
                    $sqlDelete = "DELETE FROM transacoes_retirada WHERE id = ?";
                    $stmtDelete = $conn->prepare($sqlDelete);
                    if (!$stmtDelete) {
                        throw new Exception("Erro ao preparar DELETE de transação: " . $conn->error);
                    }
                    $stmtDelete->bind_param("i", $id);
                    $stmtDelete->execute();
                    if ($stmtDelete->affected_rows === 0) {
                        throw new Exception("Falha ao deletar transação ID {$id}. Nenhuma linha afetada. Talvez já tenha sido deletada?");
                    }
                    $stmtDelete->close();
                    write_log_saques("Saque ID {$id} deletado do banco de dados.", 'INFO');
                    $feedback_type = 'success';
                    $message = "Saque deletado com sucesso. Lembre-se: o saldo do usuário NÃO foi estornado por esta ação. Use 'Estornar Pedido' se precisar ajustar o saldo ANTES de deletar.";
                    break;
                
                case 'edit_transaction':
                    $new_valor_retirada = $_POST['valor_retirada'] ?? null;
                    $new_taxa_cobrada = $_POST['taxa_cobrada'] ?? null;
                    $new_total_recebido = $_POST['total_recebido'] ?? null;
                    
                    if (empty($new_valor_retirada) || empty($new_taxa_cobrada) || empty($new_total_recebido)) {
                        throw new Exception("Dados de edição incompletos.");
                    }
                    
                    if ($statusAtualDB !== 'pendente' && $statusAtualDB !== 'cancelada') {
                        throw new Exception("Não é possível editar uma transação no status atual: {$statusAtualDB}.");
                    }
                    
                    $sqlUpdate = "UPDATE transacoes_retirada SET valor_retirada = ?, taxa_cobrada = ?, total_recebido = ? WHERE id = ?";
                    $stmtUpdate = $conn->prepare($sqlUpdate);
                    if (!$stmtUpdate) {
                        throw new Exception("Erro ao preparar a atualização da transação: " . $conn->error);
                    }
                    
                    $stmtUpdate->bind_param("dddi", $new_valor_retirada, $new_taxa_cobrada, $new_total_recebido, $id);
                    
                    if (!$stmtUpdate->execute()) {
                        throw new Exception("Erro ao atualizar a transação ID {$id}: " . $stmtUpdate->error);
                    }
                    $stmtUpdate->close();
                    
                    $novoStatus = $statusAtualDB; // O status não muda com a edição
                    $feedback_type = 'success';
                    $message = "Transação ID {$id} editada com sucesso!";
                    write_log_saques("Transação ID {$id} editada. Novos valores: Retirada={$new_valor_retirada}, Taxa={$new_taxa_cobrada}, Total={$new_total_recebido}.", 'INFO');
                    break;

                default:
                    write_log_saques("Ação inválida fornecida: {$action} para saque ID {$id}.", 'WARNING');
                    throw new Exception('Ação inválida fornecida.');
            }

            if ($action !== 'delete' && $action !== 'edit_transaction') {
                $sqlStatus = "UPDATE transacoes_retirada SET status = ?";
                if ($action === 'solicit_bspaybr') {
                    $sqlStatus .= ", data_envio_pixup = NOW()";
                } elseif ($action === 'mark_paid_manual') {
                    $sqlStatus .= ", data_confirmacao = NOW()";
                } elseif ($action === 'reject' || $action === 'refund_withdrawal') {
                    $sqlStatus .= ", data_cancelamento = NOW()";
                }
                $sqlStatus .= " WHERE id = ?";
                
                $stmtStatus = $conn->prepare($sqlStatus);

                if (!$stmtStatus) {
                    $error_msg = "Erro ao preparar atualização de status da transação: " . $conn->error;
                    write_log_saques($error_msg, 'ERROR');
                    throw new Exception('Erro ao preparar atualização de status da transação: ' . $conn->error);
                }

                $stmtStatus->bind_param("si", $novoStatus, $id);

                if (!$stmtStatus->execute()) {
                    $error_msg = "Erro ao atualizar status da transação ID {$id} para '{$novoStatus}': " . $stmtStatus->error;
                    write_log_saques($error_msg, 'ERROR');
                    throw new Exception('Erro ao atualizar o status da transação: ' . $stmtStatus->error);
                }

                $stmtStatus->close();
                write_log_saques("Status da transação ID {$id} atualizado para '{$novoStatus}'.", 'INFO');
            }

            $conn->commit();
            write_log_saques("Transação DB comitada para saque ID {$id}.", 'INFO');

        } catch (Exception $e) {
            $conn->rollback();
            write_log_saques("ERRO na lógica de saque (POST) - ID: {$id}. Ação: {$action}. Mensagem: " . $e->getMessage(), 'ERROR');
            $feedback_message = 'Erro ao processar a transação: ' . $e->getMessage();
            $feedback_type = 'error';
        }
    }

    if ($is_ajax_request) {
        header('Content-Type: application/json');
        echo json_encode([
            'feedback_type' => $feedback_type,
            'feedback_message' => $feedback_message,
            'status_updated_to' => $novoStatus
        ]);
        exit();
    }
}
// --- Fim da Lógica de Processamento de Ações (POST) ---

// --- Lógica de Carregamento de Transações para Exibição ---
$transacoes = [];
$totalSaquesPagos = 0;
$totalSaquesPendentes = 0;

try {
    write_log_saques("Iniciando carregamento de transações para exibição.", 'DEBUG');
    $sql = "SELECT tr.*, u.cpf, u.nome_completo, u.saldo_recarga
             FROM transacoes_retirada tr
             JOIN usuarios u ON tr.usuario_id = u.id
             ORDER BY FIELD(tr.status, 'pendente', 'processando_bspaybr', 'cancelada', 'estornado', 'pago', 'concluída') ASC, tr.id DESC";
    $result = $conn->query($sql);

    if (!$result) {
        write_log_saques("Erro na consulta SQL para carregar transações: " . $conn->error, 'ERROR');
        throw new Exception('Erro na consulta ao banco de dados: ' . $conn->error);
    }

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $transacoes[] = $row;

            if ($row['status'] == 'pago' || $row['status'] == 'concluída') {
                $totalSaquesPagos += $row['total_recebido'];
            } elseif ($row['status'] == 'pendente' || $row['status'] == 'processando_bspaybr') {
                $totalSaquesPendentes++;
            }
        }
        write_log_saques("Carregadas " . count($transacoes) . " transações para exibição. Total pagos: R$ " . $totalSaquesPagos . ", Pendentes: " . $totalSaquesPendentes, 'INFO');
    } else {
        write_log_saques("Nenhuma transação de retirada encontrada no DB.", 'INFO');
    }
} catch (Exception $e) {
    write_log_saques("Erro ao carregar transações para exibição: " . $e->getMessage(), 'ERROR');
    $feedback_message = 'Erro ao carregar transações. Por favor, tente novamente mais tarde.';
    $feedback_type = 'error';
} finally {
    if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Transações de Retirada - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* MUDANÇA: Estilo para o tema verde */
        :root {
            --primary-green: #28a745;
            --primary-blue: #007bff;
            --primary-red: #dc3545;
            --primary-orange: #fd7e14;
            --dark-bg: #343a40;
            --light-bg: #f8f9fa;
            --white: #ffffff;
            --text-dark: #212529;
            --text-light: #e9ecef;
            --text-muted: #6c757d;
            --shadow-light: rgba(0, 0, 0, 0.08);
            --shadow-medium: rgba(0, 0, 0, 0.15);
            --border-color: #dee2e6;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .navbar {
            background-color: var(--dark-bg) !important;
            box-shadow: 0 2px 10px var(--shadow-light);
            border-bottom: 3px solid var(--primary-green);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
            font-size: 1.5rem;
        }
        .navbar-nav .nav-link {
            color: var(--text-light) !important;
            transition: all 0.3s ease;
            border-radius: 8px;
            margin: 0 8px;
            padding: 10px 18px;
            font-weight: 500;
            position: relative; /* Adiciona posição relativa para o badge */
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: var(--primary-green);
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(40, 167, 69, 0.3);
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        /* Estilo para o badge de notificação */
        .nav-item .badge {
            position: absolute;
            top: 5px;
            right: 5px;
            padding: 4px 8px;
            border-radius: 50%;
            font-size: 0.7em;
        }

        .container {
            flex-grow: 1;
            padding-top: 30px;
            padding-bottom: 30px;
        }
        
        /* NOVO: Estilos para o painel de resumo */
        .summary-panel {
            display: flex;
            justify-content: space-around;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
            background-color: var(--white);
            border-radius: 12px;
            box-shadow: 0 4px 15px var(--shadow-medium);
            margin-bottom: 30px;
        }
        .summary-item {
            text-align: center;
            padding: 10px 15px;
            border-radius: 8px;
            flex: 1 1 200px; /* Flexbox para responsividade */
        }
        .summary-item.paid {
            background-color: #e6f4e6; /* Cor de fundo para itens pagos */
            border: 1px solid #c3e6c3;
        }
        .summary-item.pending {
            background-color: #fff3e0; /* Cor de fundo para itens pendentes */
            border: 1px solid #ffcc80;
        }
        .summary-item h4 {
            font-size: 1.2rem;
            color: var(--text-dark);
            margin-bottom: 5px;
        }
        .summary-item p {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            color: var(--primary-green);
        }
        .summary-item.pending p {
            color: var(--primary-orange);
        }


        .table-container {
            margin: 30px auto;
            max-width: 1300px;
            background-color: var(--white);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px var(--shadow-medium);
            animation: fadeIn 0.8s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1 {
            color: var(--dark-bg);
            font-weight: 700;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2.5rem;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.05);
        }

        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            margin-bottom: 0;
        }
        .table thead th {
            background-color: var(--primary-blue);
            color: var(--white);
            font-weight: 600;
            padding: 15px 20px;
            border-bottom: none;
            vertical-align: middle;
            text-align: center;
            border-radius: 8px 8px 0 0;
            font-size: 0.95rem;
            text-transform: uppercase;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
            border-bottom: 1px solid var(--border-color);
        }
        .table tbody tr:last-child {
            border-bottom: none;
        }
        .table tbody tr:hover {
            background-color: #f0f4f7;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
        }
        .table tbody td {
            padding: 15px 20px;
            vertical-align: middle;
            text-align: center;
            border-top: none;
            font-size: 0.9rem;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f4f7f9;
        }

        .btn {
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px var(--shadow-light);
            margin: 3px;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px var(--shadow-light);
        }

        .btn-warning {
            background-color: var(--primary-orange);
            border-color: var(--primary-orange);
            color: var(--white);
        }
        .btn-warning:hover {
            background-color: #e66b0e;
            border-color: #e66b0e;
        }
        .btn-success-bspaybr { /* MUDANÇA: Novo seletor */
            background-color: var(--primary-green);
            border-color: var(--primary-green);
            color: var(--white);
        }
        .btn-success-bspaybr:hover { /* MUDANÇA: Novo seletor */
            background-color: #218838;
            border-color: #1e7e34;
        }
        .btn-manual-paid {
            background-color: #6f42c1;
            border-color: #6f42c1;
            color: var(--white);
        }
        .btn-manual-paid:hover {
            background-color: #5a3597;
            border-color: #5a3597;
        }

        .btn-danger {
            background-color: var(--primary-red);
            border-color: var(--primary-red);
            color: var(--white);
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }

        .btn-secondary {
            background-color: var(--text-muted);
            border-color: var(--text-muted);
            color: var(--white);
        }
        .btn-secondary:hover {
            background-color: #5c636a;
            border-color: #565e64;
        }

        .btn-sm {
            padding: 6px 12px;
            font-size: 0.8rem;
            border-radius: 6px;
        }
        .btn-reactivate {
            background-color: #007bff;
            border-color: #007bff;
            color: var(--white);
        }
        .btn-reactivate:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .btn-delete {
            background-color: #6c757d;
            border-color: #6c757d;
            color: var(--white);
        }
        .btn-delete:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-refund {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }
        .btn-refund:hover {
            background-color: #e0a800;
            border-color: #d39e00;
        }

        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.75em;
            text-transform: uppercase;
            color: var(--white);
            display: inline-block;
            min-width: 90px;
        }

        .status-pendente {
            background-color: var(--primary-orange);
            color: var(--white);
        }
        .status-processando_bspaybr { /* MUDANÇA: Seletor novo */
            background-color: #00bcd4;
            color: var(--white);
        }
        .status-concluida {
            background-color: var(--primary-blue);
            color: var(--white);
        }
        .status-pago {
            background-color: var(--primary-green);
            color: var(--white);
        }
        .status-cancelada,
        .status-recusada {
            background-color: var(--primary-red);
            color: var(--white);
        }
        .status-estornado {
            background-color: #6c757d;
            color: var(--white);
        }
        .status-default {
            background-color: var(--text-muted);
            color: var(--white);
        }

        .modal-content {
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.25);
            border: none;
            overflow: hidden;
        }
        .modal-header {
            background-color: var(--primary-blue);
            color: var(--white);
            border-bottom: none;
            padding: 20px 25px;
            position: relative;
        }
        .modal-title {
            font-weight: 700;
            font-size: 1.5rem;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        .btn-close {
            filter: invert(1);
            opacity: 0.8;
            transition: opacity 0.2s ease;
        }
        .btn-close:hover {
            opacity: 1;
        }
        .modal-body {
            padding: 25px;
            font-size: 0.95rem;
            line-height: 1.6;
        }
        .modal-body p {
            margin-bottom: 10px;
        }
        .modal-body strong {
            color: var(--dark-bg);
        }
        .modal-footer {
            border-top: 1px solid var(--border-color);
            padding: 15px 25px;
            background-color: #f0f4f7;
        }
        .modal-footer .btn {
            min-width: 100px;
        }

        @media (max-width: 768px) {
            .table-container {
                padding: 15px;
                margin: 15px auto;
                max-width: 98%;
            }
            h1 {
                font-size: 2rem;
                margin-bottom: 20px;
            }
            .summary-panel {
                flex-direction: column;
            }
            .summary-item {
                width: 100%;
            }
            .table thead {
                display: none;
            }
            .table tbody, .table tr, .table td {
                display: block;
                width: 100%;
            }
            .table tr {
                margin-bottom: 15px;
                border: 1px solid var(--border-color);
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.05);
                background-color: var(--white);
            }
            .table td {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 12px 15px;
                border-top: none;
                border-bottom: 1px dashed #eee;
                text-align: right;
            }
            .table td:last-child {
                border-bottom: none;
            }
            .table td::before {
                content: attr(data-label);
                flex-basis: 45%;
                text-align: left;
                font-weight: 600;
                color: var(--dark-bg);
                padding-right: 10px;
                box-sizing: border-box;
                white-space: normal;
            }
            .table td:nth-of-type(7)::before { content: ""; }
            .table td:nth-of-type(7) {
                justify-content: center;
                border-top: 1px solid var(--border-color);
                padding-top: 15px;
            }

            .btn-group-actions {
                display: flex;
                flex-direction: column;
                gap: 10px;
                width: 100%;
            }
            .btn-group-actions .btn {
                width: 100%;
            }
            .navbar-nav {
                text-align: center;
            }
            .navbar-nav .nav-item {
                margin: 5px 0;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="saques">
                            Saques
                            <?php if ($totalSaquesPendentes > 0): ?>
                                <span class="badge bg-danger ms-2"><?= $totalSaquesPendentes ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1 class="text-center my-4">Gerenciar Transações de Retirada</h1>

        <?php if ($feedback_message && !$is_ajax_request): ?>
            <div class="alert alert-<?= $feedback_type === 'success' ? 'success' : 'danger' ?> alert-dismissible fade show" role="alert">
                <?= htmlspecialchars($feedback_message) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="summary-panel">
            <div class="summary-item paid">
                <h4>Total de Saques Pagos</h4>
                <p>R$ <?= number_format($totalSaquesPagos, 2, ',', '.') ?></p>
            </div>
            <div class="summary-item pending">
                <h4>Saques Pendentes</h4>
                <p><?= $totalSaquesPendentes ?></p>
            </div>
        </div>
        
        <div class="table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuário</th>
                        <th>CPF</th>
                        <th>Valor Retirada</th>
                        <th>Taxa Cobrada</th>
                        <th>Total Recebido</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="transaction-table-body">
                    <?php if (empty($transacoes)): ?>
                        <tr><td colspan="8" class="text-center py-4 text-muted">Nenhuma transação de retirada encontrada.</td></tr>
                    <?php else: ?>
                        <?php foreach ($transacoes as $transaction): ?>
                            <?php
                            $statusBadgeClass = 'status-default';
                            switch ($transaction['status']) {
                                case 'pendente':
                                    $statusBadgeClass = 'status-pendente';
                                    break;
                                case 'processando_bspaybr':
                                    $statusBadgeClass = 'status-processando_bspaybr';
                                    break;
                                case 'concluída':
                                    $statusBadgeClass = 'status-concluida';
                                    break;
                                case 'pago':
                                    $statusBadgeClass = 'status-pago';
                                    break;
                                case 'cancelada':
                                case 'recusada':
                                    $statusBadgeClass = 'status-cancelada';
                                    break;
                                case 'estornado':
                                    $statusBadgeClass = 'status-estornado';
                                    break;
                                default:
                                    $statusBadgeClass = 'status-default';
                                    break;
                            }
                            ?>
                            <tr id="transaction-row-<?= htmlspecialchars($transaction['id']) ?>">
                                <td data-label="ID" data-value="<?= htmlspecialchars($transaction['id']) ?>"><?= htmlspecialchars($transaction['id']) ?></td>
                                <td data-label="Usuário ID">
                                    <strong><?= htmlspecialchars($transaction['nome_completo'] ?: 'N/A') ?></strong><br>
                                    <small class="text-muted">ID: <?= htmlspecialchars($transaction['usuario_id'] ?: 'N/A') ?></small>
                                </td>
                                <td data-label="CPF"><?= htmlspecialchars($transaction['cpf'] ?: 'N/A') ?></td>
                                <td data-label="Valor Retirada">R$ <?= number_format($transaction['valor_retirada'], 2, ',', '.') ?></td>
                                <td data-label="Taxa Cobrada">R$ <?= number_format($transaction['taxa_cobrada'], 2, ',', '.') ?></td>
                                <td data-label="Total Recebido">R$ <?= number_format($transaction['total_recebido'], 2, ',', '.') ?></td>
                                <td data-label="Status"><span class="status-badge <?= $statusBadgeClass ?>"><?= htmlspecialchars(str_replace('_', ' ', $transaction['status'])) ?></span></td>
                                <td data-label="Ações">
                                    <div class="btn-group-actions">
                                        <?php
                                        $valorRetirada = number_format($transaction['valor_retirada'], 2, ',', '.');
                                        $totalRecebido = number_format($transaction['total_recebido'], 2, ',', '.');
                                        
                                        $msgRecusar = "Você tem certeza que deseja RECUSAR esta transação? O status será alterado para cancelado, SEM estornar o saldo (para estorno use \"Estornar Pedido\").";
                                        $msgEstornar = "Você tem certeza que deseja ESTORNAR o valor de <strong>R$ {$valorRetirada}</strong> para o usuário? Isso devolverá o saldo para a conta de recarga do usuário e o status da transação será \"estornado\".";
                                        $msgDeletar = "Você tem certeza que deseja DELETAR esta transação? Essa ação é IRREVERSÍVEL. Certifique-se de que o saldo do usuário já foi tratado (estornado ou pago) antes de deletar.";
                                        $msgMarcarPagoManual = "Esta ação deve ser usada APENAS se o pagamento PIX foi realizado POR FORA do sistema. Você confirma que o pagamento foi feito e deseja marcar como PAGO? (Nenhum saldo será debitado/estornado).";
                                        $msgSolicitarBspaybr = "Você está prestes a INICIAR a transferência PIX de <strong>R$ {$totalRecebido}</strong> via BSPay BR. Confirma?";
                                        $msgReativarPagarBspaybr = "Você tem certeza que deseja REATIVAR e tentar novamente o pagamento PIX de <strong>R$ {$totalRecebido}</strong> via BSPay BR? (Nenhum saldo será debitado/estornado, pois já foi tratado no cancelamento/criação).";
                                        $msgReativarMarcarManual = "Você tem certeza que deseja REATIVAR e marcar esta transação como paga manualmente? (Nenhum saldo será debitado/estornado).";
                                        
                                        $msgRecusar = htmlspecialchars(json_encode($msgRecusar), ENT_QUOTES, 'UTF-8');
                                        $msgEstornar = htmlspecialchars(json_encode($msgEstornar), ENT_QUOTES, 'UTF-8');
                                        $msgDeletar = htmlspecialchars(json_encode($msgDeletar), ENT_QUOTES, 'UTF-8');
                                        $msgMarcarPagoManual = htmlspecialchars(json_encode($msgMarcarPagoManual), ENT_QUOTES, 'UTF-8');
                                        $msgSolicitarBspaybr = htmlspecialchars(json_encode($msgSolicitarBspaybr), ENT_QUOTES, 'UTF-8');
                                        $msgReativarPagarBspaybr = htmlspecialchars(json_encode($msgReativarPagarBspaybr), ENT_QUOTES, 'UTF-8');
                                        $msgReativarMarcarManual = htmlspecialchars(json_encode($msgReativarMarcarManual), ENT_QUOTES, 'UTF-8');
                                        
                                        $canTakeAction = in_array($transaction['status'], ['pendente', 'processando_bspaybr', 'cancelada']);
                                        $isFinalStatus = in_array($transaction['status'], ['pago', 'concluída', 'estornado']);
                                        ?>

                                        <?php if ($transaction['status'] === 'pendente' || $transaction['status'] === 'processando_bspaybr'): ?>
                                            <button class="btn btn-success-bspaybr btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'solicit_bspaybr', 'Solicitar Pagamento BSPay BR?', <?= $msgSolicitarBspaybr ?>, '#28a745', 'Sim, Solicitar Pagamento!')">
                                                Pagar BSPay BR
                                            </button>
                                            <button class="btn btn-manual-paid btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'mark_paid_manual', 'Marcar como Pago (Manual)', <?= $msgMarcarPagoManual ?>, '#6f42c1', 'Sim, Marcar Manualmente!')">
                                                Marcar Pago (Manual)
                                            </button>
                                            <button class="btn btn-danger btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'reject', 'Confirmar Recusa?', <?= $msgRecusar ?>, '#dc3545', 'Sim, Recusar!')">
                                                Recusar
                                            </button>
                                            <button class="btn btn-refund btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'refund_withdrawal', 'Confirmar Estorno?', <?= $msgEstornar ?>, '#ffc107', 'Sim, Estornar Pedido!')">
                                                Estornar Pedido
                                            </button>
                                            <button class="btn btn-primary btn-sm"
                                                    onclick="openEditModal(<?= htmlspecialchars(json_encode($transaction)) ?>)">
                                                Editar Saque
                                            </button>
                                        <?php elseif ($transaction['status'] === 'cancelada'): ?>
                                            <button class="btn btn-reactivate btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'solicit_bspaybr', 'Reativar e Solicitar Pagamento BSPay BR?', <?= $msgReativarPagarBspaybr ?>, '#007bff', 'Sim, Reativar e Pagar!')">
                                                Reativar e Pagar BSPay BR
                                            </button>
                                            <button class="btn btn-manual-paid btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'mark_paid_manual', 'Reativar e Marcar como Pago (Manual)', <?= $msgReativarMarcarManual ?>, '#6f42c1', 'Sim, Reativar e Marcar Manualmente!')">
                                                Reativar e Marcar Manual
                                            </button>
                                            <button class="btn btn-refund btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'refund_withdrawal', 'Confirmar Estorno?', <?= $msgEstornar ?>, '#ffc107', 'Sim, Estornar Pedido!')">
                                                Estornar Pedido
                                            </button>
                                            <button class="btn btn-delete btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'delete', 'Confirmar Exclusão?', <?= $msgDeletar ?>, '#6c757d', 'Sim, Deletar!')">
                                                Deletar
                                            </button>
                                        <?php elseif ($transaction['status'] === 'estornado'): ?>
                                            <span class="badge bg-secondary status-estornado">Saldo Devolvido</span>
                                            <button class="btn btn-delete btn-sm"
                                                    onclick="confirmAction(<?= htmlspecialchars($transaction['id']) ?>, 'delete', 'Confirmar Exclusão?', 'Esta transação já foi estornada. Você tem certeza que deseja DELETAR este registro do histórico? Essa ação é IRREVERSÍVEL.', '#6c757d', 'Sim, Deletar!')">
                                                Deletar
                                            </button>
                                        <?php else: ?>
                                            <span class="badge bg-secondary status-default">Ações finalizadas</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="transactionModal" tabindex="-1" aria-labelledby="transactionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="transactionModalLabel">Detalhes da Transação</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="transactionDetails">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                    <button type="button" class="btn btn-success-bspaybr" id="solicitBspaybrBtn"
                                            onclick="handleSolicitBspaybr(this.dataset.transactionId)">
                        Solicitar Pagamento BSPay BR
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editTransactionModal" tabindex="-1" aria-labelledby="editTransactionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editTransactionForm" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editTransactionModalLabel">Editar Saque #<span id="edit-transaction-id-title"></span></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit_transaction">
                        <input type="hidden" name="transaction_id" id="edit-transaction-id">
                        
                        <div class="mb-3">
                            <label for="edit-valor-retirada" class="form-label">Valor Retirada</label>
                            <input type="number" class="form-control" id="edit-valor-retirada" name="valor_retirada" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-taxa-cobrada" class="form-label">Taxa Cobrada</label>
                            <input type="number" class="form-control" id="edit-taxa-cobrada" name="taxa_cobrada" step="0.01" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit-total-recebido" class="form-label">Total Recebido</label>
                            <input type="number" class="form-control" id="edit-total-recebido" name="total_recebido" step="0.01" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mapeamento de status para classes de badge
        function getStatusBadgeClass(status) {
            switch (status) {
                case 'pendente': return 'status-pendente';
                case 'processando_bspaybr': return 'status-processando_bspaybr';
                case 'concluída': return 'status-concluida';
                case 'pago': return 'status-pago';
                case 'cancelada':
                case 'recusada': return 'status-cancelada';
                case 'estornado': return 'status-estornado';
                default: return 'status-default';
            }
        }

        function openEditModal(transaction) {
            document.getElementById('edit-transaction-id-title').innerText = transaction.id;
            document.getElementById('edit-transaction-id').value = transaction.id;
            document.getElementById('edit-valor-retirada').value = parseFloat(transaction.valor_retirada).toFixed(2);
            document.getElementById('edit-taxa-cobrada').value = parseFloat(transaction.taxa_cobrada).toFixed(2);
            document.getElementById('edit-total-recebido').value = parseFloat(transaction.total_recebido).toFixed(2);
            
            const modal = new bootstrap.Modal(document.getElementById('editTransactionModal'));
            modal.show();
        }

        document.getElementById('edit-valor-retirada').addEventListener('input', updateTotals);
        document.getElementById('edit-taxa-cobrada').addEventListener('input', updateTotals);

        function updateTotals() {
            const valorRetirada = parseFloat(document.getElementById('edit-valor-retirada').value) || 0;
            const taxaCobrada = parseFloat(document.getElementById('edit-taxa-cobrada').value) || 0;
            const totalRecebido = valorRetirada - taxaCobrada;
            document.getElementById('edit-total-recebido').value = totalRecebido.toFixed(2);
        }

        async function confirmAction(transactionId, action, title, text, confirmButtonColor, confirmButtonText) {
            const result = await Swal.fire({
                title: title,
                html: text,
                icon: (action === 'reject' || action === 'delete' || action === 'refund_withdrawal') ? 'warning' : 'info',
                showCancelButton: true,
                confirmButtonColor: confirmButtonColor,
                cancelButtonColor: '#6c757d',
                confirmButtonText: confirmButtonText,
                cancelButtonText: 'Cancelar'
            });

            if (result.isConfirmed) {
                Swal.fire({
                    title: 'Processando...',
                    html: 'Por favor, aguarde.',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });

                try {
                    const formData = new FormData();
                    formData.append('action', action);
                    formData.append('transaction_id', transactionId);

                    const response = await fetch('saques.php', {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });

                    if (!response.ok) {
                        const errorText = await response.text();
                        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                    }

                    const data = await response.json();

                    Swal.close();
                    if (data.feedback_type === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso!',
                            html: data.feedback_message,
                            showConfirmButton: true,
                            timer: 2500
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            html: data.feedback_message,
                            showConfirmButton: true,
                        });
                    }
                } catch (error) {
                    console.error('Erro na requisição AJAX:', error);
                    Swal.close();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro de comunicação!',
                        html: 'Não foi possível se comunicar com o servidor ou ocorreu um erro inesperado. Detalhes: ' + error.message,
                        showConfirmButton: true,
                    });
                }
            }
        }
        
        document.getElementById('editTransactionForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const transactionId = formData.get('transaction_id');
            const valorRetirada = parseFloat(formData.get('valor_retirada'));
            const taxaCobrada = parseFloat(formData.get('taxa_cobrada'));
            const totalRecebido = parseFloat(formData.get('total_recebido'));
            
            if (totalRecebido <= 0) {
                 Swal.fire('Atenção', 'O valor total recebido deve ser maior que zero.', 'warning');
                 return;
            }
            
            Swal.fire({
                title: 'Confirmar Edição?',
                html: `Você tem certeza que deseja editar os valores do saque #${transactionId}?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Sim, Salvar!',
                cancelButtonText: 'Cancelar'
            }).then(async (result) => {
                if (result.isConfirmed) {
                     Swal.fire({
                         title: 'Salvando...',
                         allowOutsideClick: false,
                         didOpen: () => { Swal.showLoading(); }
                     });
                    
                    try {
                        const response = await fetch('saques.php', {
                            method: 'POST',
                            body: formData,
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        });
                        
                        if (!response.ok) {
                            const errorText = await response.text();
                            throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                        }

                        const data = await response.json();
                        
                        Swal.close();
                        if (data.feedback_type === 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Sucesso!',
                                html: data.feedback_message,
                                showConfirmButton: true,
                                timer: 2500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro!',
                                html: data.feedback_message,
                                showConfirmButton: true,
                            });
                        }
                    } catch (error) {
                        console.error('Erro na requisição AJAX:', error);
                        Swal.close();
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro de comunicação!',
                            html: 'Não foi possível se comunicar com o servidor ou ocorreu um erro inesperado. Detalhes: ' + error.message,
                            showConfirmButton: true,
                        });
                    }
                }
            });
            const modalElement = document.getElementById('editTransactionModal');
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (modalInstance) {
                modalInstance.hide();
            }
        });

        function handleSolicitBspaybr(transactionId) {
            const transactionRowElement = document.getElementById(`transaction-row-${transactionId}`);
            let totalRecebido = '0,00';
            let currentStatus = 'unknown';

            if (transactionRowElement) {
                const totalRecebidoCell = transactionRowElement.querySelector('td[data-label="Total Recebido"]');
                if (totalRecebidoCell) {
                    totalRecebido = totalRecebidoCell.innerText.replace('R$ ', '');
                }
                const statusSpan = transactionRowElement.querySelector('td[data-label="Status"] .status-badge');
                if (statusSpan) {
                    currentStatus = statusSpan.innerText.toLowerCase().replace(/ /g, '_');
                }
            }

            let message;
            if (currentStatus === 'cancelada') {
                message = `Você tem certeza que deseja REATIVAR e tentar novamente o pagamento PIX de <strong>R$ ${totalRecebido}</strong> via BSPay BR? (Nenhum saldo será debitado/estornado, pois já foi tratado no cancelamento/criação).`;
            } else {
                message = `Você está prestes a INICIAR a transferência PIX de <strong>R$ ${totalRecebido}</strong> via BSPay BR.<br>Este valor sairá da SUA conta BSPay BR.<br>O status da transação será atualizado APENAS após o retorno do webhook da BSPay BR. Confirma?`;
            }

            confirmAction(
                transactionId,
                'solicit_bspaybr',
                'Confirmar Pagamento BSPay BR?',
                message,
                '#28a745',
                'Sim, Solicitar Pagamento!'
            );
            const modalElement = document.getElementById('transactionModal');
            const modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (modalInstance) {
                modalInstance.hide();
            }
        }
        
        function checkAndRefreshProcessingTransactions() {
            console.log('Iniciando verificação de transações em processamento...');
            const processingStatusBadges = document.querySelectorAll('.status-processando_bspaybr');

            if (processingStatusBadges.length === 0) {
                console.log('Nenhuma transação "processando_bspaybr" encontrada para verificar. Parando verificação.');
                return;
            }

            const transactionIdsToFetch = [];
            processingStatusBadges.forEach(badge => {
                const row = badge.closest('tr');
                const idCell = row.querySelector('td[data-label="ID"]');
                if (idCell && idCell.dataset.value) {
                    transactionIdsToFetch.push(idCell.dataset.value);
                }
            });

            if (transactionIdsToFetch.length === 0) {
                console.log('IDs de transações em processamento não encontrados. Parando verificação.');
                return;
            }

            console.log('Consultando status para IDs:', transactionIdsToFetch);

            fetch(`saques.php?action=get_statuses&ids=${transactionIdsToFetch.join(',')}`, {
                method: 'GET',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.success && data.statuses) {
                    let statusChanged = false;
                    data.statuses.forEach(updatedTransaction => {
                        const rowElement = document.getElementById(`transaction-row-${updatedTransaction.id}`);
                        if (rowElement) {
                            const statusSpan = rowElement.querySelector('td[data-label="Status"] .status-badge');
                            
                            if (statusSpan && updatedTransaction.status !== statusSpan.innerText.toLowerCase().replace(/ /g, '_')) {
                                console.log(`Status da transação ${updatedTransaction.id} mudou de "${statusSpan.innerText}" para "${updatedTransaction.status}".`);
                                statusChanged = true;
                            }
                        }
                    });

                    if (statusChanged) {
                        console.log('Pelo menos um status mudou. Recarregando a página para refletir as alterações e botões.');
                        location.reload();
                    } else {
                        console.log('Nenhum status mudou na última verificação.');
                    }
                } else {
                    console.error('Erro na resposta de status do servidor:', data.message || 'Erro desconhecido.');
                }
            })
            .catch(error => {
                console.error('Erro durante a consulta de status (polling):', error);
            });
        }

        setInterval(checkAndRefreshProcessingTransactions, 10000);
        document.addEventListener('DOMContentLoaded', checkAndRefreshProcessingTransactions);

        <?php if ($feedback_message && !$is_ajax_request): ?>
            Swal.fire({
                icon: '<?= $feedback_type ?>',
                title: '<?= $feedback_type === 'success' ? 'Sucesso!' : 'Erro!' ?>',
                html: '<?= nl2br(htmlspecialchars($feedback_message)) ?>',
                showConfirmButton: true,
                timer: <?= $feedback_type === 'success' ? '2500' : 'false' ?>
            });
        <?php endif; ?>
    </script>
</body>
</html>