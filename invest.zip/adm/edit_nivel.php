<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

require '../servidor/database.php';

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se os dados foram enviados via POST
    if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // Ler os dados JSON enviados no corpo da requisição
        $data = json_decode(file_get_contents('php://input'), true);

        // Obter os dados de atualização
        $id = $data['id'];
        $nivel = $data['nivel'];
        $investimento_minimo = $data['investimento_minimo'];
        $imagem = $data['imagem'];

        // Atualizar o nível VIP no banco de dados
        $stmt = $pdo->prepare("UPDATE niveis_vip SET nivel = :nivel, investimento_minimo = :investimento_minimo, imagem = :imagem WHERE id = :id");
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':nivel', $nivel);
        $stmt->bindParam(':investimento_minimo', $investimento_minimo);
        $stmt->bindParam(':imagem', $imagem);
        $stmt->execute();

        echo json_encode(['message' => 'Nível VIP atualizado com sucesso.']);
    } else {
        echo json_encode(['message' => 'Método inválido.']);
    }
} catch (PDOException $e) {
    echo json_encode(['message' => 'Erro ao atualizar o nível VIP: ' . $e->getMessage()]);
}
?>
