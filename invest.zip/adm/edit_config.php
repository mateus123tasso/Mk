<?php
require '../servidor/database.php';

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        // Lê os dados JSON do corpo da requisição
        $data = json_decode(file_get_contents('php://input'), true);

        $id = $data['id'];
        $telegram = $data['telegram'];
        $whatsapp = $data['whatsapp'];
        $saque_minimo = $data['saque_minimo'];
        $recarga_minima = $data['recarga_minima'];
        $taxa_saque = $data['taxa_saque']; // Novo campo
        $lv1 = $data['lv1']; // Novo campo
        $lv2 = $data['lv2']; // Novo campo
        $lv3 = $data['lv3']; // Novo campo

        // Atualiza a configuração no banco de dados
        $stmt = $pdo->prepare("UPDATE configuracoes SET 
            telegram = :telegram, 
            whatsapp = :whatsapp, 
            saque_minimo = :saque_minimo, 
            recarga_minima = :recarga_minima,
            taxa_saque = :taxa_saque, 
            lv1 = :lv1, 
            lv2 = :lv2, 
            lv3 = :lv3 
            WHERE id = :id");

        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':telegram', $telegram);
        $stmt->bindParam(':whatsapp', $whatsapp);
        $stmt->bindParam(':saque_minimo', $saque_minimo);
        $stmt->bindParam(':recarga_minima', $recarga_minima);
        $stmt->bindParam(':taxa_saque', $taxa_saque); // Novo campo
        $stmt->bindParam(':lv1', $lv1); // Novo campo
        $stmt->bindParam(':lv2', $lv2); // Novo campo
        $stmt->bindParam(':lv3', $lv3); // Novo campo

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Configuração atualizada com sucesso.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao atualizar a configuração.']);
        }
    }

} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao conectar ao banco de dados: ' . $e->getMessage()]);
}
?>
