<?php
session_start(); // Inicia a sessão (se não estiver iniciada) para poder manipulá-la.

// Destruir todas as variáveis de sessão
$_SESSION = array();

// Se a sessão for baseada em cookies, destrói o cookie de sessão.
// Isso irá expirar o cookie, não apenas remover os dados da sessão.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destruir a sessão.
session_destroy();

// Redireciona o usuário para a página de login (ou home, se não houver login dedicado)
header("Location: /"); // Redireciona para a raiz do seu site
exit(); // Garante que o script pare de executar após o redirecionamento
?>