<?php
require '../servidor/database.php'; // Inclui as configurações e credenciais

header('Content-Type: application/json'); // Define o tipo de conteúdo da resposta como JSON

$method = $_SERVER['REQUEST_METHOD']; // Pega o método HTTP da requisição

switch ($method) {
    case 'GET':
        // Lógica para obter todas as transações de retirada, incluindo dados do usuário
        $sql = "SELECT tr.*, u.cpf, u.nome_completo, u.saldo_recarga
                FROM transacoes_retirada tr
                JOIN usuarios u ON tr.usuario_id = u.id
                ORDER BY FIELD(tr.status, 'pendente', 'concluída', 'pago', 'cancelada') ASC, tr.id DESC";
        $result = $conn->query($sql);
        $transacoes = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $transacoes[] = $row;
            }
            echo json_encode($transacoes);
        } else {
            echo json_encode([]);
        }
        break;

    case 'PUT':
        // Lógica para atualizar o status de uma transação de retirada
        $data = json_decode(file_get_contents("php://input"), true); // Pega os dados JSON do corpo da requisição

        if (!isset($data['id'], $data['status'])) {
            echo json_encode(['success' => false, 'message' => 'Dados inválidos. Certifique-se de enviar id e status.']);
            http_response_code(400); // Bad Request
            exit;
        }

        $id = $data['id'];
        $novoStatus = $data['status'];

        // Inicia uma transação no banco de dados para garantir que as operações sejam atômicas
        $conn->begin_transaction();

        try {
            // Obtém os detalhes da transação e do usuário, bloqueando a linha para evitar concorrência
            $sqlTransacao = "SELECT tr.usuario_id, tr.valor_retirada, tr.chave_pix, tr.status AS current_status, 
                                     u.cpf, u.nome_completo, u.saldo_recarga 
                             FROM transacoes_retirada tr
                             JOIN usuarios u ON tr.usuario_id = u.id
                             WHERE tr.id = ? FOR UPDATE";
            $stmtTransacao = $conn->prepare($sqlTransacao);

            if (!$stmtTransacao) {
                throw new Exception('Erro ao preparar a consulta da transação: ' . $conn->error);
            }

            $stmtTransacao->bind_param("i", $id);
            $stmtTransacao->execute();
            $resultTransacao = $stmtTransacao->get_result();

            if ($resultTransacao->num_rows === 0) {
                throw new Exception('Transação não encontrada.');
            }

            $transacao = $resultTransacao->fetch_assoc();
            $usuarioId = $transacao['usuario_id'];
            $valorRetirada = $transacao['valor_retirada'];
            $chavePix = $transacao['chave_pix'];
            $cpfUsuario = $transacao['cpf'];
            $nomeCompletoUsuario = $transacao['nome_completo'];
            $saldoAtualUsuario = $transacao['saldo_recarga'];
            $statusAtualDB = $transacao['current_status'];

            $stmtTransacao->close();

            // Evita que transações já processadas sejam alteradas novamente
            if ($statusAtualDB !== 'pendente' && $statusAtualDB !== 'concluída') {
                throw new Exception('Esta transação já foi processada ou não pode ser alterada. Status atual: ' . $statusAtualDB);
            }

            $message = ''; // Mensagem de sucesso padrão

            // Lógica para APROVAR (status: 'concluída')
            if ($novoStatus === 'concluída') {
                if ($statusAtualDB !== 'pendente') {
                    throw new Exception('Apenas transações pendentes podem ser aprovadas.');
                }

                // Verifica e debita o valor do saque do saldo do usuário
                if ($saldoAtualUsuario < $valorRetirada) {
                    throw new Exception("Saldo insuficiente do usuário (R$ " . number_format($saldoAtualUsuario, 2, ',', '.') . ") para aprovar o saque de R$ " . number_format($valorRetirada, 2, ',', '.') . ".");
                }

                $novoSaldo = $saldoAtualUsuario - $valorRetirada;
                $sqlDebitarSaldo = "UPDATE usuarios SET saldo_recarga = ? WHERE id = ?";
                $stmtDebitarSaldo = $conn->prepare($sqlDebitarSaldo);
                if (!$stmtDebitarSaldo) {
                    throw new Exception('Erro ao preparar débito de saldo: ' . $conn->error);
                }
                $stmtDebitarSaldo->bind_param("di", $novoSaldo, $usuarioId);
                if (!$stmtDebitarSaldo->execute()) {
                    throw new Exception('Erro ao debitar o saldo do usuário: ' . $stmtDebitarSaldo->error);
                }
                $stmtDebitarSaldo->close();

                // Chama a API da BSPayBR para realizar a transferência PIX
                $apiUrl = 'https://bspaybr.com/v3/pix/payment';
                $postData = [
                    'client_id' => BSPAYBR_CLIENT_ID,         // Puxando do database.php
                    'client_secret' => BSPAYBR_CLIENT_SECRET, // Puxando do database.php
                    'nome' => $nomeCompletoUsuario,            // Nome do destinatário (o usuário que vai receber o dinheiro)
                    'cpf' => $cpfUsuario,                      // CPF do destinatário (o usuário)
                    'valor' => $valorRetirada,                 // Valor do saque
                    'chave_pix' => $chavePix,                  // Chave PIX do destinatário (o usuário)
                    'urlnoty' => 'https://seuservidor.com/webhook/pix-transferencia' // URL de callback para a BSPayBR
                ];

                error_log("DEBUG: Enviando para BSPayBR (Transferência PIX): " . json_encode($postData));

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $apiUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/x-www-form-urlencoded']);

                $response = curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $curl_error = curl_error($ch);
                curl_close($ch);

                error_log("DEBUG: Resposta BSPayBR (Transferência PIX) - HTTP {$httpCode}. Erro cURL: '{$curl_error}'. Resposta: " . ($response ?: 'Vazio'));

                if ($curl_error) {
                    $conn->rollback(); // Reverte o débito em caso de erro de comunicação
                    throw new Exception("Erro de comunicação com a API BSPayBR: " . $curl_error);
                }

                $apiResponse = json_decode($response, true);

                // Verifica a resposta da API da BSPayBR
                if ($httpCode === 200 && isset($apiResponse[0]['statusCode']) && $apiResponse[0]['statusCode'] == 200) {
                    $message = "Saque aprovado e transferência PIX iniciada com sucesso via BSPayBR. O status final será atualizado pelo Webhook.";
                    // OPCIONAL: Armazenar o transactionId da BSPayBR na sua tabela 'transacoes_retirada'
                } else {
                    $conn->rollback(); // Reverte o débito se a BSPayBR recusar ou falhar
                    $errorMessage = isset($apiResponse[0]['message']) ? $apiResponse[0]['message'] : 'Erro desconhecido na API BSPayBR.';
                    error_log("ERRO: Falha ao iniciar PIX pela BSPayBR para saque {$id}. Mensagem: {$errorMessage}. Saldo estornado.");
                    throw new Exception("Falha ao iniciar transferência PIX: " . $errorMessage . " O valor foi estornado para o usuário.");
                }

            } elseif ($novoStatus === 'pago') {
                // Lógica para MARCAR COMO PAGO (manual, assume que o PIX já foi creditado)
                if ($statusAtualDB !== 'concluída') {
                    throw new Exception('Apenas transações com status "concluída" podem ser marcadas como "pago".');
                }
                $message = "Transação marcada como paga com sucesso!";

            } elseif ($novoStatus === 'cancelada') {
                // Lógica para RECUSAR (estorna o valor para o usuário)
                if ($statusAtualDB !== 'pendente') {
                    throw new Exception('Esta transação não está pendente para ser cancelada. Status atual: ' . $statusAtualDB);
                }
                $sqlEstornarSaldo = "UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?";
                $stmtEstornarSaldo = $conn->prepare($sqlEstornarSaldo);
                if (!$stmtEstornarSaldo) {
                    throw new Exception('Erro ao preparar estorno de saldo: ' . $conn->error);
                }
                $stmtEstornarSaldo->bind_param("di", $valorRetirada, $usuarioId);
                if (!$stmtEstornarSaldo->execute()) {
                    throw new Exception('Erro ao estornar o saldo do usuário: ' . $stmtEstornarSaldo->error);
                }
                $stmtEstornarSaldo->close();
                $message = "Saque recusado e valor estornado para o usuário.";
            } else {
                throw new Exception('Status de atualização inválido fornecido.');
            }

            // Atualiza o status da transação na sua tabela 'transacoes_retirada'
            $sqlStatus = "UPDATE transacoes_retirada SET status = ? WHERE id = ?";
            $stmtStatus = $conn->prepare($sqlStatus);

            if (!$stmtStatus) {
                throw new Exception('Erro ao preparar atualização de status da transação: ' . $conn->error);
            }

            $stmtStatus->bind_param("si", $novoStatus, $id);

            if (!$stmtStatus->execute()) {
                throw new Exception('Erro ao atualizar o status da transação: ' . $stmtStatus->error);
            }

            $stmtStatus->close();

            $conn->commit(); // Confirma a transação no banco de dados
            echo json_encode(['success' => true, 'message' => $message]);

        } catch (Exception $e) {
            $conn->rollback(); // Reverte todas as operações em caso de erro
            error_log("Erro na API de Saques (PUT) - ID: {$id}. Mensagem: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            http_response_code(500); // Internal Server Error
        }

        break;

    default:
        http_response_code(405); // Método não permitido
        echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
        break;
}

$conn->close(); // Fecha a conexão com o banco de dados
?>