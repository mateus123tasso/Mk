<?php
header('Content-Type: application/json');

require '../servidor/database.php';

$conn = new mysqli($host, $username_db, $password_db, $dbname);
if ($conn->connect_error) {
    echo json_encode(['error' => 'Falha na conexão com o banco']);
    exit();
}

$totalUsuarios = $conn->query("SELECT COUNT(*) as total FROM usuarios")->fetch_assoc();
$saldoTotal = $conn->query("SELECT SUM(saldo_recarga + saldo_retirada) as total FROM usuarios")->fetch_assoc();
$transacoesPendentes = $conn->query("SELECT COUNT(*) as total FROM depositos WHERE status = 'pendente'")->fetch_assoc();
$planosAtivos = $conn->query("SELECT COUNT(*) as total FROM planos")->fetch_assoc();

$queryTransacoesMensais = "
    SELECT MONTH(data_transacao) AS mes, COUNT(*) AS total
    FROM (
        SELECT data_transacao FROM transacoes_retirada
        UNION ALL
        SELECT transaction_date FROM depositos
        UNION ALL
        SELECT data_transacao FROM transacoes
    ) AS todas_transacoes
    WHERE YEAR(data_transacao) = YEAR(CURDATE())
    GROUP BY MONTH(data_transacao)
    ORDER BY mes ASC
";
$resultTransacoesMensais = $conn->query($queryTransacoesMensais);

$transacoesMensais = array_fill(0, 12, 0);
if ($resultTransacoesMensais) {
    while ($row = $resultTransacoesMensais->fetch_assoc()) {
        $transacoesMensais[$row['mes'] - 1] = (int)$row['total'];
    }
}

echo json_encode([
    'totalUsuarios' => $totalUsuarios['total'] ?? 0,
    'saldoTotal' => $saldoTotal['total'] ?? 0,
    'transacoesPendentes' => $transacoesPendentes['total'] ?? 0,
    'planosAtivos' => $planosAtivos['total'] ?? 0,
    'transacoesMensais' => $transacoesMensais
]);

$conn->close();
