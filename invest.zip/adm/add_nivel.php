<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

require '../servidor/database.php';

header('Content-Type: application/json');

try {
    // Conectar ao banco de dados
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se os dados foram enviados via POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        // Recuperar os dados do corpo da requisição
        $data = json_decode(file_get_contents('php://input'), true);

        // Garantir que os dados são válidos e não nulos
        $nivel = isset($data['nivel']) ? (int)$data['nivel'] : null;
        $investimento_minimo = isset($data['investimento_minimo']) ? $data['investimento_minimo'] : null;
        $imagem = isset($data['imagem']) ? $data['imagem'] : null;

        // Verificar se todos os campos necessários foram preenchidos
        if ($nivel === null || $investimento_minimo === null || $imagem === null) {
            echo json_encode(['message' => 'Todos os campos são obrigatórios.']);
            exit();
        }

        // Inserir no banco de dados
        $stmt = $pdo->prepare("INSERT INTO niveis_vip (nivel, investimento_minimo, imagem) VALUES (:nivel, :investimento_minimo, :imagem)");
        $stmt->bindParam(':nivel', $nivel);
        $stmt->bindParam(':investimento_minimo', $investimento_minimo);
        $stmt->bindParam(':imagem', $imagem);
        $stmt->execute();

        echo json_encode(['message' => 'Novo nível VIP adicionado com sucesso.']);
    } else {
        echo json_encode(['message' => 'Método inválido.']);
    }
} catch (PDOException $e) {
    echo json_encode(['message' => 'Erro ao adicionar o nível VIP: ' . $e->getMessage()]);
}
?>
