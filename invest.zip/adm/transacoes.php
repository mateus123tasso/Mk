<?php
require '../servidor/database.php'; // Garante que o caminho para database.php esteja correto

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Consulta para buscar todas as transações
    $stmt = $pdo->query("SELECT * FROM transacoes ORDER BY data_transacao DESC");
    $transacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Registra o erro e exibe uma mensagem amigável ao usuário
    error_log("Database connection error: " . $e->getMessage());
    die("Erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registros de Transações - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4CAF50; /* Green */
            --secondary-color: #2c3e50; /* Dark Blue-Gray */
            --accent-color: #FFA500; /* Orange-Gold */
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
            line-height: 1.6; /* Melhora a legibilidade */
        }

        /* --- Estilização da Navbar --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important; /* Cinza mais claro para links */
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e; /* Fundo ligeiramente mais escuro no hover/ativo */
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* --- Contêiner de Conteúdo Principal --- */
        .container.mt-5 {
            padding-top: 20px;
            padding-bottom: 20px;
        }

        /* --- Contêiner da Tabela --- */
        .table-container {
            margin: 30px auto;
            max-width: 1200px; /* Largura máxima aumentada para tabelas mais largas */
            background-color: var(--white);
            padding: 25px;
            border-radius: 12px; /* Cantos mais arredondados */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* Sombra proeminente */
            animation: fadeIn 0.8s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 30px; /* Garante bom espaçamento abaixo do cabeçalho */
        }

        /* --- Estilização da Tabela --- */
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }
        .table thead th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: 600;
            padding: 12px 15px;
            border-bottom: none; /* Remove a borda padrão do bootstrap */
            vertical-align: middle;
            text-align: center;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f1f4f8; /* Efeito de hover claro */
            transform: translateY(-2px); /* Leve elevação no hover */
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
        }
        .table tbody td {
            padding: 12px 15px; /* Preenchimento aumentado para melhor espaçamento */
            vertical-align: middle;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f7f9fc; /* Faixa mais clara para linhas ímpares */
        }

        /* --- Estilos de Botão (mantidos para consistência) --- */
        .btn {
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 6px;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        /* --- Estilo para frase específica que não deve quebrar (em telas grandes) --- */
        .transaction-description {
            white-space: nowrap; /* Tenta manter a frase inteira em uma linha */
            overflow: hidden;    /* Esconde qualquer excesso de conteúdo */
            text-overflow: ellipsis; /* Adiciona "..." se o texto for cortado */
            display: inline-block; /* Necessário para que overflow e text-overflow funcionem em span */
            max-width: 100%; /* Garante que não ultrapasse o limite do pai */
        }

        /* --- CSS Responsivo para Celulares --- */
        @media (max-width: 768px) {
            /* Ajustes para telas menores */
            .table-container {
                padding: 15px;
                margin: 15px auto;
                max-width: 95%; /* Ocupa mais largura em telas menores */
            }

            .table thead {
                display: none; /* Esconde os cabeçalhos da tabela em telas pequenas */
            }

            .table tbody, .table tr, .table td {
                display: block; /* Faz com que as linhas e células da tabela se comportem como blocos */
                width: 100%; /* Ocupa a largura total */
            }

            .table tr {
                margin-bottom: 15px;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                overflow: hidden; /* Garante que os cantos arredondados sejam visíveis */
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }

            .table td {
                /* Make td a flex container */
                display: flex;
                align-items: center; /* Vertically align content */
                justify-content: space-between; /* Push label to left, content to right */
                padding: 10px 15px; /* Consistent padding */
                position: relative; /* Needed for ::before */
                white-space: normal; /* Allow text to wrap naturally */
                border: none; /* Remove individual cell borders */
                text-align: right; /* Default align for value */
            }

            /* Style for the label (::before pseudo-element) */
            .table td::before {
                content: attr(data-label); /* Usa data-label para o rótulo */
                flex-shrink: 0; /* Prevents the label from shrinking */
                width: 100px; /* Give the label a fixed width */
                text-align: left;
                font-weight: 600;
                color: var(--secondary-color);
                padding-right: 10px; /* Space between label and value */
                box-sizing: border-box; /* Include padding in width */
                white-space: nowrap; /* Keep label on one line */
                overflow: hidden; /* Hide overflow if label is too long */
                text-overflow: ellipsis; /* Add ellipsis if label is truncated */
                /* Remove absolute positioning and transforms as flexbox handles layout */
                position: static;
                transform: none;
            }

            /* Style for the actual transaction description text on mobile */
            .table td .transaction-description {
                white-space: normal; /* Allows text to wrap on mobile */
                overflow: visible;   /* Ensures all text is visible */
                text-overflow: clip; /* Removes ellipsis on mobile */
                display: block;      /* Makes it a block element to properly wrap */
                flex-grow: 1; /* Allows the description to take up remaining space */
                text-align: right; /* Aligns description text to the right */
            }

            /* Rótulos específicos para cada coluna */
            .table td:nth-of-type(1)::before { content: "ID"; }
            .table td:nth-of-type(2)::before { content: "ID do Usuário"; }
            .table td:nth-of-type(3)::before { content: "Tipo"; }
            .table td:nth-of-type(4)::before { content: "Valor"; }
            .table td:nth-of-type(5)::before { content: "Data da Transação"; }
            .table td:nth-of-type(6)::before { content: "Descrição"; }

            .navbar-nav {
                text-align: center; /* Centraliza itens de navegação no celular */
            }
            .navbar-nav .nav-item {
                margin: 5px 0; /* Ajusta a margem para itens de navegação empilhados */
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Registros de Transações</h2>
        <div class="table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ID do Usuário</th>
                        <th>Tipo</th>
                        <th>Valor</th>
                        <th>Data da Transação</th>
                        <th>Descrição</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($transacoes): ?>
                        <?php foreach ($transacoes as $transacao): ?>
                            <tr>
                                <td data-label="ID"><?php echo htmlspecialchars($transacao['id']); ?></td>
                                <td data-label="ID do Usuário"><?php echo htmlspecialchars($transacao['usuario_id']); ?></td>
                                <td data-label="Tipo"><?php echo htmlspecialchars($transacao['tipo']); ?></td>
                                <td data-label="Valor">R$ <?php echo number_format($transacao['valor'], 2, ',', '.'); ?></td>
                                <td data-label="Data da Transação"><?php echo htmlspecialchars($transacao['data_transacao']); ?></td>
                                <td data-label="Descrição">
                                    <span class="transaction-description">
                                        <?php echo htmlspecialchars($transacao['descricao']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-4">Nenhuma transação encontrada.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>