<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

require '../servidor/database.php';

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar se os dados foram enviados via GET
    if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Obter o id do nível VIP a ser excluído
        $data = $_GET['id'] ?? null;

        if ($data) {
            $stmt = $pdo->prepare("DELETE FROM planos WHERE id = :id");
            $stmt->bindParam(':id', $data, PDO::PARAM_INT);
            $stmt->execute();

            echo json_encode(['message' => 'Nível VIP excluído com sucesso.']);
        } else {
            echo json_encode(['message' => 'ID não fornecido.']);
        }
    } else {
        echo json_encode(['message' => 'Método inválido.']);
    }
} catch (PDOException $e) {
    echo json_encode(['message' => 'Erro ao excluir o nível VIP: ' . $e->getMessage()]);
}
?>
