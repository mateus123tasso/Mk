<?php
session_start();

// Ensure admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

require '../servidor/database.php'; // Ensure the path to database.php is correct

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("SET NAMES 'utf8mb4'"); // Ensure proper character encoding
} catch (PDOException $e) {
    error_log("Database connection error: " . $e->getMessage());
    die("Erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}

// Handle AJAX requests (Add, Edit, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json'); // Set header for AJAX response

    $action = $_POST['action'];

    switch ($action) {
        case 'add':
            $nivel = $_POST['nivel'] ?? null;
            $investimento_minimo = $_POST['investimento_minimo'] ?? null;
            $imagem = $_POST['imagem'] ?? null;

            if (empty($nivel) || !is_numeric($investimento_minimo) || empty($imagem)) {
                echo json_encode(['success' => false, 'message' => 'Dados incompletos ou inválidos para adicionar o nível VIP.']);
                exit();
            }

            try {
                $stmt = $pdo->prepare("INSERT INTO niveis_vip (nivel, investimento_minimo, imagem) VALUES (?, ?, ?)");
                $stmt->execute([$nivel, $investimento_minimo, $imagem]);
                echo json_encode(['success' => true, 'message' => 'Nível VIP adicionado com sucesso!']);
            } catch (PDOException $e) {
                error_log("Error adding VIP level: " . $e->getMessage());
                if ($e->getCode() == '23000') { // SQLSTATE for Integrity Constraint Violation
                    echo json_encode(['success' => false, 'message' => 'Erro: Já existe um nível VIP com este número.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Erro ao adicionar nível VIP: ' . $e->getMessage()]);
                }
            }
            break;

        case 'edit':
            $id = $_POST['id'] ?? null;
            $nivel = $_POST['nivel'] ?? null;
            $investimento_minimo = $_POST['investimento_minimo'] ?? null;
            $imagem = $_POST['imagem'] ?? null;

            if (empty($id) || empty($nivel) || !is_numeric($investimento_minimo) || empty($imagem)) {
                echo json_encode(['success' => false, 'message' => 'Dados incompletos ou inválidos para atualizar o nível VIP.']);
                exit();
            }

            try {
                $stmt = $pdo->prepare("UPDATE niveis_vip SET nivel = ?, investimento_minimo = ?, imagem = ? WHERE id = ?");
                $stmt->execute([$nivel, $investimento_minimo, $imagem, $id]);

                if ($stmt->rowCount()) {
                    echo json_encode(['success' => true, 'message' => 'Nível VIP atualizado com sucesso!']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Nível VIP não encontrado ou nenhum dado para atualizar.']);
                }
            } catch (PDOException $e) {
                error_log("Error updating VIP level: " . $e->getMessage());
                if ($e->getCode() == '23000') {
                    echo json_encode(['success' => false, 'message' => 'Erro: Já existe um nível VIP com este número.']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar nível VIP: ' . $e->getMessage()]);
                }
            }
            break;

        case 'delete':
            $id = $_POST['id'] ?? null; // For DELETE via POST with form data

            if (empty($id)) {
                echo json_encode(['success' => false, 'message' => 'ID do nível VIP não fornecido.']);
                exit();
            }

            try {
                $stmt = $pdo->prepare("DELETE FROM niveis_vip WHERE id = ?");
                $stmt->execute([$id]);

                if ($stmt->rowCount()) {
                    echo json_encode(['success' => true, 'message' => 'Nível VIP excluído com sucesso!']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Nível VIP não encontrado.']);
                }
            } catch (PDOException $e) {
                error_log("Error deleting VIP level: " . $e->getMessage());
                echo json_encode(['success' => false, 'message' => 'Erro ao excluir nível VIP: ' . $e->getMessage()]);
            }
            break;

        default:
            echo json_encode(['success' => false, 'message' => 'Ação não reconhecida.']);
            break;
    }
    exit(); // Important to exit after handling AJAX request
}

// If it's not an AJAX request, proceed to load the HTML and display the table
try {
    $stmt = $pdo->query("SELECT * FROM niveis_vip ORDER BY nivel ASC");
    $niveis = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Database query error: " . $e->getMessage());
    die("Erro ao carregar dados dos níveis VIP. Por favor, tente novamente mais tarde.");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Níveis VIP - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4CAF50; /* Green */
            --secondary-color: #2c3e50; /* Dark Blue-Gray */
            --accent-color: #FFA500; /* Orange-Gold */
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- Navbar Styling --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important; /* Lighter grey for links */
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e; /* Slightly darker background on hover/active */
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* --- Main Content Container --- */
        .container.mt-5 {
            padding-top: 20px;
            padding-bottom: 20px;
        }

        /* --- Table Container --- */
        .table-container {
            margin: 30px auto;
            max-width: 1200px; /* Increased max-width for wider tables */
            background-color: var(--white);
            padding: 25px;
            border-radius: 12px; /* More rounded corners */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* Prominent shadow */
            animation: fadeIn 0.8s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 30px;
        }

        /* --- Table Styling --- */
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }
        .table thead th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: 600;
            padding: 12px 15px;
            border-bottom: none; /* Remove default bootstrap border */
            vertical-align: middle;
            text-align: center;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f1f4f8; /* Light hover effect */
            transform: translateY(-2px); /* Slight lift on hover */
            box-shadow: 0 4px 10px rgba(0,0,0,0.05); /* More sophisticated hover shadow */
        }
        .table tbody td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f7f9fc; /* Lighter stripe for odd rows */
        }

        /* --- Button Styles --- */
        .btn {
            font-weight: 500;
            padding: 8px 15px;
            border-radius: 6px;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: #43a047;
            border-color: #43a047;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-success { /* Added for the "Adicionar Novo Nível" button */
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-success:hover {
            background-color: #43a047;
            border-color: #43a047;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-warning {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            color: var(--text-dark); /* Ensure text is visible on orange */
        }
        .btn-warning:hover {
            background-color: #e69500;
            border-color: #e69500;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-danger {
            background-color: #dc3545; /* Bootstrap red */
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .btn-sm {
            padding: 5px 10px;
            font-size: 0.85rem;
        }

        /* --- Modal Styling --- */
        .modal-content {
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border: none;
        }
        .modal-header {
            background-color: var(--secondary-color);
            color: var(--white);
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            padding: 15px 20px;
            border-bottom: none;
        }
        .modal-title {
            font-weight: 600;
            font-size: 1.25rem;
        }
        .modal-body {
            padding: 25px;
        }
        .form-label {
            font-weight: 500;
            color: var(--secondary-color);
        }
        .form-control {
            border-radius: 8px;
            padding: 10px 12px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(76, 175, 80, 0.25);
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 15px 20px;
        }

        /* --- Image Styling in Table --- */
        .table img {
            max-width: 60px; /* Slightly larger for better visibility */
            height: auto;
            border-radius: 8px; /* Slightly rounded images */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }


        /* --- Mobile Responsive CSS --- */
        @media (max-width: 768px) {
            /* Adjustments for smaller screens */
            .table-container {
                padding: 15px;
                margin: 15px auto;
                max-width: 95%; /* Make it take more width on smaller screens */
            }

            .table thead {
                display: none; /* Hide table headers on small screens */
            }

            .table tbody, .table tr, .table td {
                display: block; /* Make table rows and cells behave like blocks */
                width: 100%; /* Take full width */
            }

            .table tr {
                margin-bottom: 15px;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                overflow: hidden; /* Ensure rounded corners are visible */
                box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            }

            .table td {
                /* Use flexbox for horizontal alignment within the cell */
                display: flex;
                align-items: center; /* Vertically align items */
                justify-content: space-between; /* Puts label on left, content to right */
                padding: 10px 15px; /* Consistent padding */
                position: relative; /* Needed for ::before */
                white-space: normal; /* Allow text to wrap */
                border: none; /* Remove individual cell borders */
            }

            .table td::before {
                content: attr(data-label); /* Use data-label for the label */
                flex-shrink: 0; /* Prevents the label from shrinking */
                width: 130px; /* **Adjusted width for labels to give more space** */
                text-align: left;
                font-weight: 600;
                color: var(--secondary-color);
                padding-right: 10px; /* Space between label and value */
                box-sizing: border-box; /* Include padding in width */
                white-space: nowrap; /* Keep label on one line */
                overflow: hidden; /* Hide overflow if label is too long */
                text-overflow: ellipsis; /* Add ellipsis if label is truncated */
                /* Remove absolute positioning and transforms as flexbox handles layout */
                position: static;
                transform: none;
            }

            /* Ensure the actual content takes up remaining space and aligns right */
            .table td:not(:last-child) { /* Apply to all except the last (actions) column */
                text-align: right; /* Aligns data to the right */
            }
            .table td:last-child {
                justify-content: center; /* Center buttons horizontally */
            }

            /* Specific labels for each column */
            .table td:nth-of-type(1)::before { content: "Nível"; }
            .table td:nth-of-type(2)::before { content: "Investimento Mín."; }
            .table td:nth-of-type(3)::before { content: "Imagem"; }
            .table td:nth-of-type(4)::before { content: ""; } /* Removed content for "Ações" column */

            .table td:last-child {
                text-align: center; /* Center action buttons */
                padding-top: 15px;
                padding-bottom: 15px;
                border-top: 1px solid #eee; /* Add a top border for actions */
                /* padding-left reset handled by flexbox */
            }

            .btn-group-actions { /* New class for action buttons container */
                display: flex;
                flex-direction: column;
                gap: 10px; /* Space between buttons */
            }
            .btn-group-actions .btn {
                width: 100%; /* Full width buttons */
            }

            .mb-3.text-center { /* Center the add new plan button */
                text-align: center !important;
            }
            .navbar-nav {
                text-align: center; /* Center nav items in mobile */
            }
            .navbar-nav .nav-item {
                margin: 5px 0; /* Adjust margin for stacked nav items */
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="niveis_vip">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Gerenciar Níveis VIP</h2>

        <div class="text-end mb-3">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addModal">Adicionar Novo Nível</button>
        </div>

        <div class="table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nível</th>
                        <th>Investimento Mínimo</th>
                        <th>Imagem</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($niveis): ?>
                        <?php foreach ($niveis as $nivel): ?>
                            <tr>
                                <td data-label="Nível"><?php echo htmlspecialchars($nivel['nivel']); ?></td>
                                <td data-label="Investimento Mínimo">R$ <?php echo number_format($nivel['investimento_minimo'], 2, ',', '.'); ?></td>
                                <td data-label="Imagem"><img src="<?php echo htmlspecialchars($nivel['imagem']); ?>" alt="Imagem do Nível"></td>
                                <td data-label="">
                                    <div class="btn-group-actions">
                                        <button class="btn btn-warning btn-sm" onclick="editNivel(<?php echo htmlspecialchars(json_encode($nivel), ENT_QUOTES, 'UTF-8'); ?>)">Editar</button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteNivel(<?php echo $nivel['id']; ?>)">Excluir</button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center py-4">Nenhum nível VIP encontrado.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addModalLabel">Adicionar Novo Nível VIP</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addForm">
                        <input type="hidden" name="action" value="add"> <div class="mb-3">
                            <label for="addNivel" class="form-label">Nível</label>
                            <input type="number" class="form-control" id="addNivel" name="nivel" required>
                        </div>
                        <div class="mb-3">
                            <label for="addInvestimentoMinimo" class="form-label">Investimento Mínimo (R$)</label>
                            <input type="number" step="0.01" class="form-control" id="addInvestimentoMinimo" name="investimento_minimo" required>
                        </div>
                        <div class="mb-3">
                            <label for="addImagem" class="form-label">URL da Imagem</label>
                            <input type="text" class="form-control" id="addImagem" name="imagem" placeholder="Ex: https://seusite.com/imagens/vip1.png" required oninput="previewImage('addImagem', 'addImagemPreview')">
                            <small class="form-text text-muted">A imagem será exibida abaixo.</small>
                            <img id="addImagemPreview" src="" alt="Prévia da Imagem" style="max-width: 100%; height: auto; margin-top: 10px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: none;">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Adicionar Nível</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Editar Nível VIP</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm">
                        <input type="hidden" name="action" value="edit"> <input type="hidden" id="editId" name="id">
                        <div class="mb-3">
                            <label for="editNivel" class="form-label">Nível</label>
                            <input type="number" class="form-control" id="editNivel" name="nivel" required>
                        </div>
                        <div class="mb-3">
                            <label for="editInvestimentoMinimo" class="form-label">Investimento Mínimo (R$)</label>
                            <input type="number" step="0.01" class="form-control" id="editInvestimentoMinimo" name="investimento_minimo" required>
                        </div>
                        <div class="mb-3">
                            <label for="editImagem" class="form-label">URL da Imagem</label>
                            <input type="text" class="form-control" id="editImagem" name="imagem" required oninput="previewImage('editImagem', 'editImagemPreview')">
                            <small class="form-text text-muted">A imagem será exibida abaixo.</small>
                            <img id="editImagemPreview" src="" alt="Prévia da Imagem" style="max-width: 100%; height: auto; margin-top: 10px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: none;">
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Excluir Nível VIP</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza de que deseja excluir este nível VIP? Esta ação é irreversível.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        let currentNivelId = null; // Stores the ID of the VIP level being edited/deleted

        /**
         * Populates the edit modal with VIP level data and shows it.
         * @param {object} nivel - The VIP level object from the database.
         */
        window.editNivel = function(nivel) { // Make it global to be called from onclick
            currentNivelId = nivel.id;
            document.getElementById('editId').value = nivel.id;
            document.getElementById('editNivel').value = nivel.nivel;
            document.getElementById('editInvestimentoMinimo').value = nivel.investimento_minimo;
            document.getElementById('editImagem').value = nivel.imagem;

            // Set and display image preview for edit modal
            previewImage('editImagem', 'editImagemPreview');

            const modal = new bootstrap.Modal(document.getElementById('editModal'));
            modal.show();
        };

        /**
         * Sets the VIP level ID for deletion and shows the confirmation modal.
         * @param {number} id - The ID of the VIP level to be deleted.
         */
        window.deleteNivel = function(id) { // Make it global
            currentNivelId = id;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        };

        /**
         * Shows a preview of the image based on the URL input.
         * @param {string} inputId - The ID of the input field (e.g., 'addImagem').
         * @param {string} imgId - The ID of the image element (e.g., 'addImagemPreview').
         */
        window.previewImage = function(inputId, imgId) {
            const input = document.getElementById(inputId);
            const img = document.getElementById(imgId);
            const url = input.value;

            if (url) {
                img.src = url;
                img.style.display = 'block'; // Show the image
                img.onerror = function() { // Handle broken image links
                    img.style.display = 'none';
                    console.warn(`Could not load image from URL: ${url}`);
                };
            } else {
                img.style.display = 'none'; // Hide if input is empty
                img.src = ''; // Clear the image source
            }
        };

        // Handle submission of the add new level form
        document.getElementById('addForm').addEventListener('submit', async function(event) {
            event.preventDefault();

            const formData = new FormData(this); // Get form data automatically, including the hidden 'action' field

            try {
                // Now we send the request to the same PHP file
                const response = await axios.post('niveis_vip.php', formData);

                if (response.data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso!',
                        text: response.data.message,
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        location.reload(); // Reload the page to show the new level
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro!',
                        text: response.data.message,
                        showConfirmButton: true
                    });
                }
            } catch (error) {
                console.error('Erro ao adicionar o nível VIP:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Erro de Requisição',
                    text: 'Ocorreu um erro ao adicionar o nível VIP. Tente novamente.',
                    showConfirmButton: true
                });
            }
        });

        // Handle submission of the edit form
        document.getElementById('editForm').addEventListener('submit', async function(event) {
            event.preventDefault();

            if (currentNivelId !== null) {
                const formData = new FormData(this); // Get form data, including hidden 'action' and 'id'

                try {
                    // Now we send the request to the same PHP file
                    const response = await axios.post('niveis_vip.php', formData);

                    if (response.data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso!',
                            text: response.data.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            const editModalInstance = bootstrap.Modal.getInstance(document.getElementById('editModal'));
                            if (editModalInstance) editModalInstance.hide(); // Hide modal
                            location.reload(); // Reload the page to show updates
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: response.data.message,
                            showConfirmButton: true
                        });
                    }
                } catch (error) {
                    console.error('Erro ao atualizar o nível VIP:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro de Requisição',
                        text: 'Ocorreu um erro ao atualizar o nível VIP. Tente novamente.',
                        showConfirmButton: true
                    });
                }
            }
        });

        // Handle confirmation of VIP level deletion
        document.getElementById('confirmDeleteBtn').addEventListener('click', async function() {
            if (currentNivelId !== null) {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('id', currentNivelId);

                try {
                    // Now we send the request to the same PHP file
                    const response = await axios.post('niveis_vip.php', formData);

                    if (response.data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Sucesso!',
                            text: response.data.message,
                            showConfirmButton: false,
                            timer: 1500
                        }).then(() => {
                            location.reload(); // Reload the page to show the updated list
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: response.data.message,
                            showConfirmButton: true
                        });
                    }
                } catch (error) {
                    console.error('Erro ao excluir o nível VIP:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro de Requisição',
                        text: 'Ocorreu um erro ao excluir o nível VIP. Tente novamente.',
                        showConfirmButton: true
                    });
                }
            }
        });

        // Add event listeners to clear modal previews when modals are hidden
        document.getElementById('addModal').addEventListener('hidden.bs.modal', function () {
            document.getElementById('addImagemPreview').style.display = 'none';
            document.getElementById('addImagemPreview').src = '';
            document.getElementById('addForm').reset(); // Reset form fields
        });

        document.getElementById('editModal').addEventListener('hidden.bs.modal', function () {
            document.getElementById('editImagemPreview').style.display = 'none';
            document.getElementById('editImagemPreview').src = '';
            document.getElementById('editForm').reset(); // Reset form fields
        });
    </script>
</body>
</html>