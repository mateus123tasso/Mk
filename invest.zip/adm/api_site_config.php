<?php
session_start();

// 1. Verifique a autenticação do administrador
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['success' => false, 'message' => 'Acesso negado. Faça login como administrador.']);
    exit();
}

// Inclua o arquivo de conexão com o banco de dados
require '../servidor/database.php';

// Define o cabeçalho para resposta JSON
header('Content-Type: application/json');

// 2. Receba os dados da requisição PUT
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// 3. Verifique se os dados necessários foram recebidos
$required_fields = [
    'id', 'site_name', 'site_title', 'banner_image', 'favicon', 
    'checkin_title', 'checkin_subtitle', 'checkin_button',
    'ticker_message_1', 'ticker_message_2', 'ticker_message_3'
];

foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty(trim($data[$field]))) {
        http_response_code(400); // Bad Request
        echo json_encode(['success' => false, 'message' => "Campo obrigatório '$field' está vazio ou ausente."]);
        exit();
    }
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 4. Prepare e execute a atualização no banco de dados
    $stmt = $pdo->prepare("UPDATE configuracoes SET
        site_name = :site_name,
        site_title = :site_title,
        banner_image = :banner_image,
        favicon = :favicon,
        checkin_title = :checkin_title,
        checkin_subtitle = :checkin_subtitle,
        checkin_button = :checkin_button,
        ticker_message_1 = :ticker_message_1,
        ticker_message_2 = :ticker_message_2,
        ticker_message_3 = :ticker_message_3,
        modal_title = :modal_title,
        modal_welcome = :modal_welcome,
        modal_bonus_register = :modal_bonus_register,
        modal_daily_login = :modal_daily_login,
        modal_commission = :modal_commission,
        modal_telegram = :modal_telegram,
        checkin_success_title = :checkin_success_title,
        checkin_success_message = :checkin_success_message
        WHERE id = :id");

    // 5. Bind dos parâmetros
    $stmt->bindParam(':site_name', $data['site_name']);
    $stmt->bindParam(':site_title', $data['site_title']);
    $stmt->bindParam(':banner_image', $data['banner_image']);
    $stmt->bindParam(':favicon', $data['favicon']);
    $stmt->bindParam(':checkin_title', $data['checkin_title']);
    $stmt->bindParam(':checkin_subtitle', $data['checkin_subtitle']);
    $stmt->bindParam(':checkin_button', $data['checkin_button']);
    $stmt->bindParam(':ticker_message_1', $data['ticker_message_1']);
    $stmt->bindParam(':ticker_message_2', $data['ticker_message_2']);
    $stmt->bindParam(':ticker_message_3', $data['ticker_message_3']);
    
    // Campos opcionais do modal (podem estar vazios)
    $modal_title = $data['modal_title'] ?? '';
    $modal_welcome = $data['modal_welcome'] ?? '';
    $modal_bonus_register = $data['modal_bonus_register'] ?? '';
    $modal_daily_login = $data['modal_daily_login'] ?? '';
    $modal_commission = $data['modal_commission'] ?? '';
    $modal_telegram = $data['modal_telegram'] ?? '';
    $checkin_success_title = $data['checkin_success_title'] ?? '';
    $checkin_success_message = $data['checkin_success_message'] ?? '';
    
    $stmt->bindParam(':modal_title', $modal_title);
    $stmt->bindParam(':modal_welcome', $modal_welcome);
    $stmt->bindParam(':modal_bonus_register', $modal_bonus_register);
    $stmt->bindParam(':modal_daily_login', $modal_daily_login);
    $stmt->bindParam(':modal_commission', $modal_commission);
    $stmt->bindParam(':modal_telegram', $modal_telegram);
    $stmt->bindParam(':checkin_success_title', $checkin_success_title);
    $stmt->bindParam(':checkin_success_message', $checkin_success_message);
    
    $stmt->bindParam(':id', $data['id'], PDO::PARAM_INT);

    $stmt->execute();

    // 6. Verifique se alguma linha foi afetada
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Configurações do site atualizadas com sucesso!']);
    } else {
        // Pode acontecer se o ID não existir ou se os dados não mudaram
        echo json_encode(['success' => false, 'message' => 'Nenhuma alteração foi feita ou a configuração não foi encontrada.']);
    }

} catch (PDOException $e) {
    // Em caso de erro no banco de dados
    error_log("Erro ao atualizar configurações do site no DB: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao salvar configurações do site.']);
}

$pdo = null; // Fecha a conexão PDO
?>