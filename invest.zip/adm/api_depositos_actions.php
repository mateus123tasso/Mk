<?php
session_start();
header('Content-Type: application/json');

require '../servidor/database.php'; // Caminho para a conexão com o banco de dados

// Função para retornar um erro JSON
function returnError($message, $httpCode = 400) {
    http_response_code($httpCode);
    echo json_encode(['success' => false, 'message' => $message]);
    exit();
}

// Verifica se o administrador está logado
if (!isset($_SESSION['admin_logged_in'])) {
    returnError("Acesso negado. Administrador não autenticado.", 403);
}

// Lógica para lidar com as diferentes ações (aprovar, excluir)
$request_method = $_SERVER['REQUEST_METHOD'];

// Para requisições de aprovação (PUT)
if ($request_method === 'PUT') {
    // Lê o corpo da requisição JSON
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['action']) || !isset($data['id'])) {
        returnError("Ação ou ID do depósito ausente na requisição.", 400);
    }

    $deposit_id = $data['id'];
    $action = $data['action'];

    if ($action === 'approve') {
        try {
            $pdo->beginTransaction();

            // 1. Busca os detalhes do depósito para obter o user_id e o valor
            $stmt = $pdo->prepare("SELECT user_id, amount, status FROM depositos WHERE id = ?");
            $stmt->execute([$deposit_id]);
            $deposit = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$deposit) {
                $pdo->rollBack();
                returnError("Depósito não encontrado.", 404);
            }

            if ($deposit['status'] !== 'pendente') {
                $pdo->rollBack();
                returnError("Este depósito já foi processado e não pode ser aprovado.", 409);
            }

            // 2. Atualiza o status do depósito para 'aprovado'
            $stmt_update_deposit = $pdo->prepare("UPDATE depositos SET status = 'aprovado' WHERE id = ?");
            $stmt_update_deposit->execute([$deposit_id]);

            // 3. Credita o valor do depósito no saldo do usuário
            // CORREÇÃO AQUI: o saldo agora é adicionado na coluna `saldo_recarga`
            $stmt_update_user_balance = $pdo->prepare("UPDATE usuarios SET saldo_recarga = saldo_recarga + ? WHERE id = ?");
            $stmt_update_user_balance->execute([$deposit['amount'], $deposit['user_id']]);

            $pdo->commit();
            
            echo json_encode(['success' => true, 'message' => 'Depósito aprovado e saldo do usuário atualizado com sucesso.']);

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro ao aprovar depósito: " . $e->getMessage());
            returnError("Erro interno ao processar a aprovação.", 500);
        }
    }
    
} elseif ($request_method === 'DELETE') {
    // Lógica para exclusão
    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['id'])) {
        returnError("ID do depósito ausente na requisição.", 400);
    }
    
    $deposit_id = $data['id'];

    try {
        // Exclui o registro do depósito do banco de dados
        $stmt_delete = $pdo->prepare("DELETE FROM depositos WHERE id = ?");
        $stmt_delete->execute([$deposit_id]);

        if ($stmt_delete->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Depósito excluído com sucesso.']);
        } else {
            returnError("Depósito não encontrado ou já excluído.", 404);
        }
        
    } catch (PDOException $e) {
        error_log("Erro ao excluir depósito: " . $e->getMessage());
        returnError("Erro interno ao processar a exclusão.", 500);
    }
} else {
    returnError("Método de requisição não suportado.", 405);
}

?>