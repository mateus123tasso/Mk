<?php
// Inclua o arquivo de conexão com o banco de dados
require '../servidor/database.php';

// Configure os cabeçalhos para permitir CORS e requisições JSON
header('Content-Type: application/json');

// Obtém o método da requisição (GET, POST, PUT, DELETE)
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        // Lógica para buscar chaves Pix de um usuário
        if (isset($_GET['uid'])) {
            $userId = $_GET['uid'];
            // CORREÇÃO: Usando a tabela `carteiras`
            $stmt = $pdo->prepare("SELECT id, chave_pix, cpf, nome_completo FROM carteiras WHERE uid = ?");
            $stmt->execute([$userId]);
            $keys = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($keys);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID do usuário não fornecido.']);
        }
        break;

    case 'POST':
        // Lógica para adicionar uma nova chave Pix
        $data = json_decode(file_get_contents('php://input'), true);
        $uid = $data['uid'] ?? null;
        $chave_pix = $data['chave_pix'] ?? null;
        $cpf = $data['cpf'] ?? null;
        $nome_completo = $data['nome_completo'] ?? null;

        if ($uid && $chave_pix && $cpf && $nome_completo) {
            // CORREÇÃO: Usando a tabela `carteiras`
            $stmt = $pdo->prepare("INSERT INTO carteiras (uid, chave_pix, cpf, nome_completo) VALUES (?, ?, ?, ?)");
            $success = $stmt->execute([$uid, $chave_pix, $cpf, $nome_completo]);
            if ($success) {
                echo json_encode(['success' => true, 'message' => 'Chave Pix adicionada com sucesso.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Erro ao adicionar chave Pix.']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Dados incompletos.']);
        }
        break;

    case 'PUT':
        // Lógica para editar uma chave Pix existente
        $data = json_decode(file_get_contents('php://input'), true);
        $keyId = $_GET['id'] ?? null;
        $chave_pix = $data['chave_pix'] ?? null;
        $cpf = $data['cpf'] ?? null;
        $nome_completo = $data['nome_completo'] ?? null;

        if ($keyId && $chave_pix && $cpf && $nome_completo) {
            // CORREÇÃO: Usando a tabela `carteiras`
            $stmt = $pdo->prepare("UPDATE carteiras SET chave_pix = ?, cpf = ?, nome_completo = ? WHERE id = ?");
            $success = $stmt->execute([$chave_pix, $cpf, $nome_completo, $keyId]);
            if ($success) {
                echo json_encode(['success' => true, 'message' => 'Chave Pix atualizada com sucesso.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Erro ao atualizar chave Pix.']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Dados incompletos ou ID não fornecido.']);
        }
        break;

    case 'DELETE':
        // Lógica para excluir uma chave Pix
        $keyId = $_GET['id'] ?? null;
        if ($keyId) {
            // CORREÇÃO: Usando a tabela `carteiras`
            $stmt = $pdo->prepare("DELETE FROM carteiras WHERE id = ?");
            $success = $stmt->execute([$keyId]);
            if ($success) {
                echo json_encode(['success' => true, 'message' => 'Chave Pix excluída com sucesso.']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Erro ao excluir chave Pix.']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID da chave não fornecido.']);
        }
        break;

    default:
        // Método não permitido
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Método não permitido.']);
        break;
}
?>