<?php

session_start();

// Define o fuso horário para o horário de Brasília
date_default_timezone_set('America/Sao_Paulo');

// Verifica se o administrador está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['admin_logged_in'])) {
 header("Location: login.html"); // Altere para o caminho real da sua página de login
 exit();
}

// Inclui o arquivo de conexão com o banco de dados
// Certifique-se de que o caminho para 'database.php' está correto.
require '../servidor/database.php';

try {
 // Conecta ao banco de dados usando PDO
 $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
 $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $stmt = $pdo->query("SELECT * FROM configuracoes ORDER BY id ASC LIMIT 1");
 $configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
 // Em caso de erro na conexão, registra o erro e exibe uma mensagem amigável
 error_log("Database connection error on deposits page: " . $e->getMessage());
 die("Erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Gerenciar Depósitos - Admin</title>
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
 <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
 <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
 <style>
  :root {
   --primary-color: #4CAF50; /* Green */
   --secondary-color: #2c3e50; /* Dark Blue-Gray */
   --accent-color: #FFA500; /* Orange-Gold */
   --light-bg: #eef2f6;
   --white: #ffffff;
   --text-dark: #333;
   --text-light: #ecf0f1;
  }

  body {
   font-family: 'Poppins', sans-serif;
   background-color: var(--light-bg);
   color: var(--text-dark);
  }

  /* --- Navbar Styling --- */
  .navbar {
   background-color: var(--secondary-color) !important;
   box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }
  .navbar-brand {
   font-family: 'Montserrat', sans-serif;
   font-weight: 700;
   letter-spacing: 1px;
   color: var(--text-light) !important;
  }
  .navbar-nav .nav-link {
   color: #bdc3c7 !important; /* Lighter grey for links */
   transition: color 0.3s ease, background-color 0.3s ease;
   border-radius: 5px;
   margin: 0 5px;
   padding: 8px 15px;
  }
  .navbar-nav .nav-link:hover,
  .navbar-nav .nav-link.active {
   color: var(--white) !important;
   background-color: #34495e; /* Slightly darker background on hover/active */
  }
  .navbar-toggler {
   border-color: rgba(255, 255, 255, 0.2);
  }
  .navbar-toggler-icon {
   background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
  }

  /* --- Main Content Container --- */
  .container {
   padding-top: 20px;
   padding-bottom: 20px;
  }

  /* --- Summary Panel Styling --- */
  .summary-panel {
   background-color: var(--white);
   padding: 20px;
   border-radius: 12px;
   box-shadow: 0 4px 15px rgba(0,0,0,0.1);
   margin-bottom: 30px;
   display: flex;
   justify-content: space-around;
   text-align: center;
  }
  .summary-item {
   flex-grow: 1;
   padding: 0 10px;
  }
  .summary-item h4 {
   font-size: 1.2rem;
   color: var(--secondary-color);
   margin-bottom: 5px;
   font-weight: 600;
  }
  .summary-item p {
   font-size: 1rem;
   margin: 0;
   color: var(--text-dark);
  }

  /* --- Table Container --- */
  .table-container {
   margin: 30px auto;
   max-width: 1200px; /* Increased max-width for wider tables */
   background-color: var(--white);
   padding: 25px;
   border-radius: 12px; /* More rounded corners */
   box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* Prominent shadow */
   animation: fadeIn 0.8s ease-out forwards;
   opacity: 0;
   transform: translateY(20px);
  }

  @keyframes fadeIn {
   to {
    opacity: 1;
    transform: translateY(0);
   }
  }

  h1 {
   color: var(--secondary-color);
   font-weight: 600;
   margin-bottom: 30px;
  }

  /* --- Table Styling --- */
  .table {
   border-collapse: separate;
   border-spacing: 0;
   width: 100%;
  }
  .table thead th {
   background-color: var(--secondary-color);
   color: var(--white);
   font-weight: 600;
   padding: 12px 15px;
   border-bottom: none; /* Remove default bootstrap border */
   vertical-align: middle;
   text-align: center;
  }
  .table tbody tr {
   background-color: var(--white);
   transition: background-color 0.2s ease, transform 0.2s ease;
  }
  .table tbody tr:hover {
   background-color: #f1f4f8; /* Light hover effect */
   transform: translateY(-2px); /* Slight lift on hover */
   box-shadow: 0 4px 10px rgba(0,0,0,0.05);
  }
  .table tbody td {
   padding: 12px 15px;
   vertical-align: middle;
   text-align: center;
   border-top: 1px solid #dee2e6;
  }
  .table-striped tbody tr:nth-of-type(odd) {
   background-color: #f7f9fc; /* Lighter stripe for odd rows */
  }

  /* --- Button Styles --- */
  .btn {
   font-weight: 500;
   padding: 8px 15px;
   border-radius: 6px;
   transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
   box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  }
  .btn-primary {
   background-color: var(--primary-color);
   border-color: var(--primary-color);
  }
  .btn-primary:hover {
   background-color: #43a047;
   border-color: #43a047;
   transform: translateY(-1px);
   box-shadow: 0 4px 10px rgba(0,0,0,0.2);
  }
  .btn-success {
   background-color: #28a745;
   border-color: #28a745;
  }
  .btn-success:hover {
   background-color: #218838;
   border-color: #1e7e34;
   transform: translateY(-1px);
   box-shadow: 0 4px 10px rgba(0,0,0,0.2);
  }
  .btn-danger {
   background-color: #dc3545; /* Bootstrap red */
   border-color: #dc3545;
  }
  .btn-danger:hover {
   background-color: #c82333;
   border-color: #bd2130;
   transform: translateY(-1px);
  }
  .btn-secondary {
   background-color: #6c757d;
   border-color: #6c757d;
  }
  .btn-secondary:hover {
   background-color: #5c636a;
   border-color: #565e64;
   transform: translateY(-1px);
  }
  .btn-sm {
   padding: 5px 10px;
   font-size: 0.85rem;
  }

  /* --- Status Badges --- */
  .status-badge {
   padding: 5px 10px;
   border-radius: 5px;
   font-weight: 600;
   font-size: 0.8em;
   text-transform: uppercase;
   color: var(--white); /* Texto branco para todos os badges por padrão */
  }
  /* CORRIGIDO: Status 'pago' adicionado para garantir o fundo verde */
  .status-aprovado, .status-pago {
   background-color: #28a745; /* Bootstrap Green */
  }
  .status-pendente {
   background-color: #ffc107; /* Bootstrap Yellow/Orange */
   color: var(--text-dark); /* Dark text for contrast on yellow */
  }
  .status-recusado {
   background-color: #dc3545; /* Bootstrap Red */
  }
 
  /* --- Mobile Responsive CSS --- */
  @media (max-width: 768px) {
   .table-container {
    padding: 15px;
    margin: 15px auto;
    max-width: 95%;
   }
   .table thead {
    display: none;
   }
   .table tbody, .table tr, .table td {
    display: block;
    width: 100%;
   }
   .table tr {
    margin-bottom: 15px;
    border: 1px solid #dee2e6;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
   }
   .table td {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 15px;
    position: relative;
    white-space: normal;
    border: none;
   }
   .table td::before {
    content: attr(data-label);
    flex-shrink: 0;
    width: 120px;
    text-align: left;
    font-weight: 600;
    color: var(--secondary-color);
    padding-right: 10px;
    box-sizing: border-box;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    position: static;
    transform: none;
   }
   .table td:not(:last-child) {
    text-align: right;
   }
   .table td:last-child {
    justify-content: center;
    padding-top: 15px;
    padding-bottom: 15px;
    border-top: 1px solid #eee;
   }
   .btn-group-actions {
    display: flex;
    flex-direction: column;
    gap: 10px;
   }
   .btn-group-actions .btn {
    width: 100%;
   }
   .mb-3.text-end {
    text-align: center !important;
   }
   .navbar-nav {
    text-align: center;
   }
   .navbar-nav .nav-item {
    margin: 5px 0;
   }
  }
 </style>
</head>

<body>
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
   <a class="navbar-brand" href="#">Painel Admin</a>
   <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
   </button>
   <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav ms-auto">
     <li class="nav-item">
      <a class="nav-link" href="index">Início</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="usuarios">Usuários</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="transacoes">Transações</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="planos">Planos</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="configuracoes">Configurações</a>
     </li>
     <li class="nav-item">
      <a class="nav-link active" aria-current="page" href="depositos">Depósitos</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="saques">Saques</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="niveis_vip">VIPs</a>
     </li>
     <li class="nav-item">
      <a class="nav-link" href="logout.php">Sair</a>
     </li>
    </ul>
   </div>
  </div>
 </nav>

 <div class="container">
  <h1 class="text-center my-4">Gerenciar Depósitos</h1>
 
  <div class="summary-panel" id="summary-panel">
     </div>

  <div class="table-container">
   <table class="table table-striped">
    <thead>
     <tr>
      <th>ID</th>
      <th>Usuário</th>
      <th>CPF</th>
      <th>Valor Depositado</th>
      <th>Data da Transação</th>
      <th>Status</th>
      <th>Ações</th>
     </tr>
    </thead>
    <tbody id="deposit-table-body">
    </tbody>
   </table>
  </div>
 </div>

 <div class="modal fade" id="depositModal" tabindex="-1" aria-labelledby="depositModalLabel" aria-hidden="true">
  <div class="modal-dialog">
   <div class="modal-content">
    <div class="modal-header">
     <h5 class="modal-title" id="depositModalLabel">Detalhes do Depósito</h5>
     <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
     <div id="depositDetails">
     </div>
    </div>
    <div class="modal-footer">
     <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
     </div>
   </div>
  </div>
 </div>

 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

 <script>
  let depositsData = []; // Armazena todos os dados de depósitos

  // Função para buscar depósitos do servidor
  async function fetchDeposits() {
   try {
    // Endpoint para buscar depósitos (AJUSTE SE NECESSÁRIO)
    const response = await axios.get('api_depositos.php');
    depositsData = response.data;
    renderDeposits(depositsData);
    updateSummaryPanel(depositsData); // Chama a nova função para atualizar o painel de resumo
   } catch (error) {
    console.error('Erro ao buscar depósitos:', error);
    Swal.fire({
     icon: 'error',
     title: 'Erro de Requisição',
     text: 'Ocorreu um erro ao buscar os depósitos. Tente novamente mais tarde.',
     showConfirmButton: true
    });
   }
  }

  // Nova função para calcular e mostrar o resumo dos depósitos
  function updateSummaryPanel(deposits) {
   const summaryPanel = document.getElementById('summary-panel');
  
   let totalPaidValue = 0;
   let pendingDepositsCount = 0;

   deposits.forEach(deposit => {
    if (deposit.status === 'pago' || deposit.status === 'aprovado') {
     totalPaidValue += parseFloat(deposit.amount);
    } else if (deposit.status === 'pendente') {
     pendingDepositsCount++;
    }
   });

   summaryPanel.innerHTML = `
    <div class="summary-item">
     <h4>Valor Total de Depósitos Pagos</h4>
     <p>R$ ${totalPaidValue.toFixed(2).replace('.', ',')}</p>
    </div>
    <div class="summary-item">
     <h4>Total de Depósitos Pendentes</h4>
     <p>${pendingDepositsCount}</p>
    </div>
   `;
  }

  // Função para renderizar os depósitos na tabela
  function renderDeposits(deposits) {
   const tableBody = document.getElementById('deposit-table-body');
   tableBody.innerHTML = '';

   if (!deposits || deposits.length === 0) {
    // CORRIGIDO: Colspan ajustado para 7 colunas
    tableBody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Nenhum depósito encontrado.</td></tr>';
    return;
   }

   deposits.forEach(deposit => {
    const row = document.createElement('tr');
    let statusClass = '';
    switch (deposit.status) {
     case 'aprovado':
      statusClass = 'status-aprovado';
      break;
     // CORRIGIDO: Adiciona o case 'pago' para garantir que a cor seja verde
     case 'pago':
      statusClass = 'status-pago';
      break;
     case 'pendente':
      statusClass = 'status-pendente';
      break;
     case 'recusado':
      statusClass = 'status-recusado';
      break;
     default:
      statusClass = 'status-badge';
    }

        // Cria um objeto de data a partir do valor do banco de dados
        const dateFromDB = new Date(deposit.transaction_date);

        // Subtrai 3 horas (3 * 60 * 60 * 1000 milissegundos) da data
        const adjustedDate = new Date(dateFromDB.getTime() - (3 * 60 * 60 * 1000));
       
        // Formata a data ajustada
        const formattedDate = adjustedDate.toLocaleString('pt-BR', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });
       
    row.innerHTML = `
     <td data-label="ID">${deposit.id}</td>
     <td data-label="Usuário">
      <strong>${deposit.nome_completo || 'N/A'}</strong><br>
      <small class="text-muted">ID: ${deposit.user_id || 'N/A'}</small>
     </td>
     <td data-label="CPF">${deposit.cpf || 'N/A'}</td>
     <td data-label="Valor Depositado">R$ ${parseFloat(deposit.amount).toFixed(2).replace('.', ',')}</td>
     <td data-label="Data Transação">${formattedDate || 'N/A'}</td>
     <td data-label="Status"><span class="status-badge ${statusClass}">${deposit.status}</span></td>
     <td data-label="">
      <div class="btn-group-actions">
       ${(deposit.status === 'pendente') ?
        `<button class="btn btn-sm btn-success" onclick="approveDeposit(${deposit.id})">Aprovar</button>
        <button class="btn btn-sm btn-danger" onclick="deleteDeposit(${deposit.id})">Excluir</button>`
        : (deposit.status === 'aprovado' || deposit.status === 'pago' || deposit.status === 'recusado' ?
        // CORRIGIDO: Adiciona o status 'pago' para a verificação
        `<button class="btn btn-sm btn-danger" onclick="deleteDeposit(${deposit.id})">Excluir</button>`
        : `<span class="badge bg-secondary">Ação não disponível</span>`)
       }
      </div>
     </td>
    `;
    tableBody.appendChild(row);
   });
  }

  // Função para aprovar o depósito
  async function approveDeposit(id) {
   Swal.fire({
    title: 'Você tem certeza?',
    text: "Você irá aprovar este depósito e creditar o valor no saldo do usuário!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Sim, aprovar!',
    cancelButtonText: 'Cancelar'
   }).then(async (result) => {
    if (result.isConfirmed) {
     try {
      const response = await axios.put('api_depositos_actions.php', {
       action: 'approve',
       id: id
      });

      if (response.data.success) {
       Swal.fire('Aprovado!', response.data.message, 'success');
       fetchDeposits(); // Recarrega a tabela e o painel de resumo
      } else {
       Swal.fire('Erro!', response.data.message, 'error');
      }
     } catch (error) {
      Swal.fire('Erro!', 'Não foi possível aprovar o depósito.', 'error');
      console.error('Erro ao aprovar depósito:', error);
     }
    }
   });
  }
 
  // Função para excluir o depósito
  async function deleteDeposit(id) {
   Swal.fire({
    title: 'Você tem certeza?',
    text: "Esta ação não pode ser desfeita! O depósito será excluído permanentemente.",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Sim, excluir!',
    cancelButtonText: 'Cancelar'
   }).then(async (result) => {
    if (result.isConfirmed) {
     try {
      const response = await axios.delete('api_depositos_actions.php', {
       data: { id: id }
      });

      if (response.data.success) {
       Swal.fire('Excluído!', response.data.message, 'success');
       fetchDeposits(); // Recarrega a tabela e o painel de resumo
      } else {
       Swal.fire('Erro!', response.data.message, 'error');
      }
     } catch (error) {
      Swal.fire('Erro!', 'Não foi possível excluir o depósito.', 'error');
      console.error('Erro ao excluir depósito:', error);
     }
    }
   });
  }
 
  // Carrega os depósitos quando a página é carregada
  document.addEventListener('DOMContentLoaded', fetchDeposits);
 </script>
</body>

</html>