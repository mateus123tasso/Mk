<?php
// Ensure session is started before any output
session_start();

// Include database connection
require '../servidor/database.php';

header('Content-Type: application/json');

// Adiciona cabeçalhos para permitir requisições de métodos diferentes (CORS)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

// Define o caminho para a pasta de imagens dos planos
$uploadDir = '../planosimg/';

// Define o arquivo de log específico para a API de planos
define('LOG_FILE_API_PLAN', __DIR__ . '/api_plan.log');

/**
 * Função para registrar mensagens no log da API de planos.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_log_api_plan($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(LOG_FILE_API_PLAN, $log_entry, FILE_APPEND);
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    write_log_api_plan("Conexão com o banco de dados estabelecida com sucesso.", 'INFO');

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Lógica unificada para ADICIONAR ou EDITAR um plano
        write_log_api_plan("Requisição POST recebida. Dados: " . json_encode($_POST), 'DEBUG');

        $id = $_POST['id'] ?? null;
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];
        $receitaTotal = $_POST['receitaTotal'];
        $receitaDiaria = $_POST['receitaDiaria'];
        $diasDeReceita = $_POST['diasDeReceita'];
        $limite = $_POST['limite'];
        $vip = $_POST['vip'];
        $newImageName = null;

        // Lógica de upload de imagem
        if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['imagem']['tmp_name'];
            $fileName = basename($_FILES['imagem']['name']);
            $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            $newImageName = md5(time() . $fileName) . '.' . $fileExtension;
            $destPath = $uploadDir . $newImageName;

            if (!move_uploaded_file($fileTmpPath, $destPath)) {
                write_log_api_plan("Erro ao mover a imagem para {$destPath}.", 'ERROR');
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Erro ao mover a imagem.']);
                exit();
            }
            write_log_api_plan("Imagem carregada com sucesso: {$newImageName}.", 'INFO');
        }

        if ($id) {
            // Lógica de EDIÇÃO de plano
            $query = "UPDATE planos SET nome = :nome, preco = :preco, receitaTotal = :receitaTotal, receitaDiaria = :receitaDiaria, diasDeReceita = :diasDeReceita, limite = :limite, vip = :vip";
            
            if ($newImageName) {
                $query .= ", imagem = :imagem";
                $stmt = $pdo->prepare("SELECT imagem FROM planos WHERE id = :id");
                $stmt->bindParam(':id', $id);
                $stmt->execute();
                $oldImage = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($oldImage && !empty($oldImage['imagem'])) {
                    $oldImagePath = $uploadDir . $oldImage['imagem'];
                    if (file_exists($oldImagePath)) {
                        unlink($oldImagePath); // Deleta a imagem antiga do servidor
                        write_log_api_plan("Imagem antiga '{$oldImage['imagem']}' deletada.", 'INFO');
                    }
                }
            }

            $query .= " WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':preco', $preco);
            $stmt->bindParam(':receitaTotal', $receitaTotal);
            $stmt->bindParam(':receitaDiaria', $receitaDiaria);
            $stmt->bindParam(':diasDeReceita', $diasDeReceita);
            $stmt->bindParam(':limite', $limite);
            $stmt->bindParam(':vip', $vip);
            if ($newImageName) {
                $stmt->bindParam(':imagem', $newImageName);
            }

            if ($stmt->execute()) {
                write_log_api_plan("Plano ID {$id} atualizado com sucesso.", 'INFO');
                echo json_encode(['success' => true, 'message' => 'Plano atualizado com sucesso.']);
            } else {
                write_log_api_plan("Erro ao atualizar plano ID {$id}. Erro: " . json_encode($stmt->errorInfo()), 'ERROR');
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Erro ao atualizar o plano.']);
            }

        } else {
            // Lógica de CRIAÇÃO de plano
            $query = "INSERT INTO planos (nome, preco, receitaTotal, receitaDiaria, diasDeReceita, limite, vip, imagem) VALUES (:nome, :preco, :receitaTotal, :receitaDiaria, :diasDeReceita, :limite, :vip, :imagem)";
            $stmt = $pdo->prepare($query);
            
            $stmt->bindParam(':nome', $nome);
            $stmt->bindParam(':preco', $preco);
            $stmt->bindParam(':receitaTotal', $receitaTotal);
            $stmt->bindParam(':receitaDiaria', $receitaDiaria);
            $stmt->bindParam(':diasDeReceita', $diasDeReceita);
            $stmt->bindParam(':limite', $limite);
            $stmt->bindParam(':vip', $vip);
            $stmt->bindParam(':imagem', $newImageName);

            if ($stmt->execute()) {
                write_log_api_plan("Plano '{$nome}' criado com sucesso.", 'INFO');
                echo json_encode(['success' => true, 'message' => 'Plano criado com sucesso.']);
            } else {
                write_log_api_plan("Erro ao criar o plano. Erro: " . json_encode($stmt->errorInfo()), 'ERROR');
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Erro ao criar o plano.']);
            }
        }
    } elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        // Lógica para EXCLUIR um plano
        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            write_log_api_plan("Requisição DELETE recebida para o plano ID {$id}.", 'DEBUG');
            
            $stmt = $pdo->prepare("SELECT imagem FROM planos WHERE id = :id");
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $plano = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($plano && !empty($plano['imagem'])) {
                $imagePath = $uploadDir . $plano['imagem'];
                if (file_exists($imagePath)) {
                    unlink($imagePath); // Deleta a imagem do servidor
                    write_log_api_plan("Imagem '{$plano['imagem']}' do plano ID {$id} deletada.", 'INFO');
                }
            }

            $stmt = $pdo->prepare("DELETE FROM planos WHERE id = :id");
            $stmt->bindParam(':id', $id);

            if ($stmt->execute()) {
                if ($stmt->rowCount() > 0) {
                    write_log_api_plan("Plano ID {$id} excluído com sucesso.", 'INFO');
                    echo json_encode(['success' => true, 'message' => 'Plano excluído com sucesso.']);
                } else {
                    write_log_api_plan("Tentativa de excluir plano ID {$id}, mas não foi encontrado.", 'WARNING');
                    echo json_encode(['success' => false, 'message' => 'Plano não encontrado.']);
                }
            } else {
                write_log_api_plan("Erro ao excluir o plano ID {$id}. Erro: " . json_encode($stmt->errorInfo()), 'ERROR');
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Erro ao excluir o plano.']);
            }
        } else {
            write_log_api_plan("Tentativa de DELETE sem ID. Parâmetro ausente.", 'WARNING');
            http_response_code(400); // Bad Request
            echo json_encode(['success' => false, 'message' => 'ID do plano não fornecido.']);
        }
    } else {
        write_log_api_plan("Método de requisição não suportado: " . $_SERVER['REQUEST_METHOD'], 'WARNING');
        http_response_code(405); // Method Not Allowed
        echo json_encode(['success' => false, 'message' => 'Método de requisição não suportado.']);
    }
} catch (PDOException $e) {
    write_log_api_plan("Erro fatal no banco de dados: " . $e->getMessage(), 'CRITICAL');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor.']);
}