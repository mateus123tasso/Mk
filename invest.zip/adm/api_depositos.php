<?php
// Inclui o arquivo de conexão com o banco de dados
require '../servidor/database.php';

header('Content-Type: application/json');

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Retorna um erro JSON se a conexão com o banco de dados falhar
    echo json_encode(['status' => 'error', 'message' => 'Erro na conexão: ' . $e->getMessage()]);
    exit();
}

function sendError($message) {
    // Função para retornar um erro JSON e encerrar o script
    echo json_encode(['status' => 'error', 'message' => $message]);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        
        // Consulta para um único depósito com informações do usuário
        $sql = "SELECT d.*, u.nome_completo, u.cpf 
                FROM depositos d
                JOIN usuarios u ON d.user_id = u.id
                WHERE d.id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        
        $deposito = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($deposito) {
            echo json_encode($deposito);
        } else {
            // Retorna um objeto vazio se um depósito específico não for encontrado
            echo json_encode((object)[]);
        }

    } else {
        // Bloco de código para retornar todos os depósitos
        // CORREÇÃO: Consulta SQL foi alterada para juntar as tabelas
        // 'depositos' (d) e 'usuarios' (u) para obter o nome e o CPF
        $sql = "SELECT d.*, u.nome_completo, u.cpf 
                FROM depositos d
                JOIN usuarios u ON d.user_id = u.id
                ORDER BY d.id DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute();

        $depositos = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode($depositos);
    }
}

$pdo = null;
?>