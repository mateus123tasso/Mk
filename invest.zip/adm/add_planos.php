<?php

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html"); // Redirect to admin login if not logged in
    exit();
}

// Make sure this path is correct relative to planos.php
require '../servidor/database.php'; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Function to handle image upload
function uploadFoto($file) {
    // IMPORTANT: Define the base directory for uploads relative to your web root.
    // Assuming 'static' is in the public web directory, accessible by the browser.
    // Make sure the 'uploads/planos' directory exists within your 'static' folder
    // and is writable by the web server (permissions 0755 or 0777 are common).
    $uploadDir = __DIR__ . '/../static/uploads/planos/'; // Physical path on the server

    // Create the directory if it doesn't exist
    if (!is_dir($uploadDir)) {
        if (!mkdir($uploadDir, 0755, true)) { // Use 0755 for directories
            throw new Exception('Failed to create upload directory: ' . $uploadDir);
        }
    }

    // Generate a unique file name to prevent conflicts
    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    // Ensure the file extension is valid to prevent security issues
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array(strtolower($fileExtension), $allowedExtensions)) {
        throw new Exception('Tipo de arquivo não permitido. Por favor, envie uma imagem (jpg, jpeg, png, gif, webp).');
    }

    $fileName = uniqid('plan_') . '.' . $fileExtension; // Prepend 'plan_' for clarity
    $filePath = $uploadDir . $fileName;

    // Move the uploaded file to the desired directory
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        // Return the web-accessible path relative to the domain root
        // This is the path that should be saved in the database
        return 'static/uploads/planos/' . $fileName; 
    } else {
        // Check for specific upload errors
        $error = $file['error'];
        $errorMessage = 'Erro desconhecido ao fazer upload.';
        switch ($error) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                $errorMessage = 'O arquivo é muito grande.';
                break;
            case UPLOAD_ERR_PARTIAL:
                $errorMessage = 'O arquivo foi enviado apenas parcialmente.';
                break;
            case UPLOAD_ERR_NO_FILE:
                $errorMessage = 'Nenhum arquivo foi enviado.';
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $errorMessage = 'Pasta temporária ausente.';
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $errorMessage = 'Falha ao gravar o arquivo em disco.';
                break;
            case UPLOAD_ERR_EXTENSION:
                $errorMessage = 'Uma extensão PHP interrompeu o upload do arquivo.';
                break;
        }
        throw new Exception('Falha ao fazer upload da imagem: ' . $errorMessage);
    }
}

// Check if the form was submitted (this block handles the AJAX request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json'); // Ensure JSON header is sent
    try {
        // Collect form data
        $nome = $_POST['nome'] ?? '';
        $preco = $_POST['preco'] ?? 0.00;
        $receitaTotal = $_POST['receitaTotal'] ?? 0.00;
        $receitaDiaria = $_POST['receitaDiaria'] ?? 0.00;
        $diasDeReceita = $_POST['diasDeReceita'] ?? 0;
        $limite = $_POST['limite'] ?? 1;
        $vip = $_POST['vip'] ?? '';

        $caminhoFoto = null; // Initialize to null

        // Handle image upload
        if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
            $caminhoFoto = uploadFoto($_FILES['foto']);
        } else {
            // Throw an exception if no file or an error occurred during upload
            throw new Exception('Nenhuma imagem enviada ou ocorreu um erro no upload.');
        }

        // Prepare the SQL query for insertion
        // Confirm 'image_url' is the correct column name in your 'planos' table
        $stmt = $pdo->prepare(
            "INSERT INTO planos (nome, image_url, preco, receitaTotal, receitaDiaria, diasDeReceita, limite, vip) 
            VALUES (:nome, :image_url, :preco, :receitaTotal, :receitaDiaria, :diasDeReceita, :limite, :vip)"
        );

        // Bind the values
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':image_url', $caminhoFoto); // Use :image_url for the database field
        $stmt->bindParam(':preco', $preco);
        $stmt->bindParam(':receitaTotal', $receitaTotal);
        $stmt->bindParam(':receitaDiaria', $receitaDiaria);
        $stmt->bindParam(':diasDeReceita', $diasDeReceita);
        $stmt->bindParam(':limite', $limite);
        $stmt->bindParam(':vip', $vip);

        // Execute the query
        $stmt->execute();

        echo json_encode(["success" => true, "message" => "Plano adicionado com sucesso!"]);
    } catch (Exception $e) {
        // Log the error for debugging
        error_log("Erro ao adicionar plano: " . $e->getMessage());
        echo json_encode(["success" => false, "message" => "Erro: " . $e->getMessage()]);
    }
    exit(); // IMPORTANT: Exit here to prevent rendering the HTML below for AJAX requests
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Novo Plano - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #eef2f6; /* Light bluish-gray */
            color: #333;
        }
        .navbar {
            background-color: #2c3e50 !important; /* Darker blue-gray */
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-weight: 700;
            letter-spacing: 1px;
            color: #ecf0f1 !important; /* Lighter text for brand */
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important; /* Light gray for links */
            transition: color 0.3s ease;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: #ffffff !important; /* White on hover/active */
            background-color: #34495e; /* Slightly darker background on hover/active */
            border-radius: 5px;
        }
        .form-container {
            margin: 40px auto;
            max-width: 600px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px; /* More rounded corners */
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15); /* More prominent shadow */
            animation: slideInUp 0.6s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
        }

        @keyframes slideInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .form-label {
            font-weight: 600;
            color: #34495e; /* Darker label text */
            margin-bottom: 8px;
        }
        .form-control {
            border-radius: 8px;
            border: 1px solid #ced4da;
            padding: 10px 15px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-control:focus {
            border-color: #4CAF50; /* Green focus border */
            box-shadow: 0 0 0 0.25rem rgba(76, 175, 80, 0.25); /* Green shadow */
        }
        .btn-primary {
            background-color: #4CAF50; /* Green submit button */
            border-color: #4CAF50;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: 600;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #45a049; /* Darker green on hover */
            border-color: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .alert {
            margin-top: 20px;
            border-radius: 8px;
            padding: 15px;
            font-weight: 500;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #badbcc;
        }
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto"> <li class="nav-item">
                        <a class="nav-link" href="index">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="planos">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip">VIPs</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Adicionar Novo Plano</h2>
        <div class="form-container">
            <form id="addPlanForm" action="" method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome do Plano</label>
                    <input type="text" class="form-control" id="nome" name="nome" required>
                </div>
                <div class="mb-3">
                    <label for="foto" class="form-label">Foto do Plano</label>
                    <input type="file" class="form-control" id="foto" name="foto" accept="image/*" required>
                </div>
                <div class="mb-3">
                    <label for="preco" class="form-label">Preço (R$)</label>
                    <input type="number" step="0.01" class="form-control" id="preco" name="preco" required>
                </div>
                <div class="mb-3">
                    <label for="receitaTotal" class="form-label">Receita Total (R$)</label>
                    <input type="number" step="0.01" class="form-control" id="receitaTotal" name="receitaTotal" required>
                </div>
                <div class="mb-3">
                    <label for="receitaDiaria" class="form-label">Receita Diária (R$)</label>
                    <input type="number" step="0.01" class="form-control" id="receitaDiaria" name="receitaDiaria" required>
                </div>
                <div class="mb-3">
                    <label for="diasDeReceita" class="form-label">Dias de Receita</label>
                    <input type="number" class="form-control" id="diasDeReceita" name="diasDeReceita" required>
                </div>
                <div class="mb-3">
                    <label for="limite" class="form-label">Limite por Usuário</label>
                    <input type="number" class="form-control" id="limite" name="limite" required>
                </div>
                <div class="mb-3">
                    <label for="vip" class="form-label">Nível VIP Requerido (Ex: VIP0, VIP1)</label>
                    <input type="text" class="form-control" id="vip" name="vip" placeholder="Ex: VIP0 ou VIP1">
                </div>
                <button type="submit" class="btn btn-primary w-100">Adicionar Plano</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() { // Ensure DOM is fully loaded
            const addPlanForm = document.getElementById('addPlanForm');
            
            if (addPlanForm) { // Check if the form element exists
                addPlanForm.addEventListener('submit', function(event) {
                    event.preventDefault(); // Prevent default form submission
    
                    const formData = new FormData(this); // Get form data with file
    
                    fetch(this.action, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => {
                        // Check if the response is JSON, otherwise try to parse as text
                        const contentType = response.headers.get('content-type');
                        if (contentType && contentType.includes('application/json')) {
                            return response.json();
                        } else {
                            // If it's not JSON, it means the PHP script might have outputted something unexpected
                            // or the header isn't set correctly. We'll still try to read it as text.
                            console.warn('Received non-JSON response, attempting to read as text.');
                            return response.text().then(text => {
                                throw new Error('Non-JSON response: ' + text);
                            });
                        }
                    })
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Sucesso!',
                                text: data.message,
                                showConfirmButton: false,
                                timer: 2000
                            }).then(() => {
                                addPlanForm.reset(); // Clear form fields using the form variable
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro!',
                                text: data.message,
                                showConfirmButton: true
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Erro na requisição Fetch:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro de Requisição',
                            text: 'Ocorreu um erro ao tentar adicionar o plano. Detalhes: ' + error.message,
                            showConfirmButton: true
                        });
                    });
                });
            } else {
                console.error('Formulário com ID "addPlanForm" não encontrado.');
            }
        });
    </script>
</body>
</html>