<?php
session_start();

// 1. Verifique a autenticação do administrador
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['success' => false, 'message' => 'Acesso negado. Faça login como administrador.']);
    exit();
}

// Inclua o arquivo de conexão com o banco de dados.
// Certifique-se de que o caminho está correto em relação a este script.
// Se 'api_config.php' estiver na mesma pasta que 'configuracoes.php',
// e 'database.php' estiver em '../servidor/', o caminho está correto.
require '../servidor/database.php';

// Define o cabeçalho para resposta JSON
header('Content-Type: application/json');

// 2. Receba os dados da requisição PUT
// Para requisições PUT, os dados vêm do php://input
$input = file_get_contents('php://input');
$data = json_decode($input, true); // Decodifica o JSON para um array associativo

// 3. Verifique se os dados necessários foram recebidos e são válidos
// Faça uma verificação mais robusta para todos os campos esperados
if (
    !isset($data['id']) ||
    !isset($data['telegram']) ||
    !isset($data['whatsapp']) ||
    !isset($data['saque_minimo']) || !is_numeric($data['saque_minimo']) ||
    !isset($data['recarga_minima']) || !is_numeric($data['recarga_minima']) ||
    !isset($data['taxa_saque']) || !is_numeric($data['taxa_saque']) ||
    !isset($data['lv1']) || !is_numeric($data['lv1']) ||
    !isset($data['lv2']) || !is_numeric($data['lv2']) ||
    !isset($data['lv3']) || !is_numeric($data['lv3']) ||
    !isset($data['saque_diario_max']) || !is_numeric($data['saque_diario_max']) ||
    !isset($data['saque_maximo_por_transacao']) || !is_numeric($data['saque_maximo_por_transacao']) ||
    !isset($data['permitir_saque_24h']) // Checkbox envia 0 ou 1, que é válido
) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Dados inválidos ou incompletos para configuração.']);
    exit();
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 4. Prepare e execute a atualização no banco de dados com TODOS os campos
    $stmt = $pdo->prepare("UPDATE configuracoes SET
        telegram = :telegram,
        whatsapp = :whatsapp,
        saque_minimo = :saque_minimo,
        recarga_minima = :recarga_minima,
        taxa_saque = :taxa_saque,
        lv1 = :lv1,
        lv2 = :lv2,
        lv3 = :lv3,
        saque_diario_max = :saque_diario_max,
        saque_maximo_por_transacao = :saque_maximo_por_transacao,
        permitir_saque_24h = :permitir_saque_24h
        WHERE id = :id");

    // 5. Bind dos parâmetros
    $stmt->bindParam(':telegram', $data['telegram']);
    $stmt->bindParam(':whatsapp', $data['whatsapp']);
    $stmt->bindParam(':saque_minimo', $data['saque_minimo']); // PDO pode inferir tipo para numéricos
    $stmt->bindParam(':recarga_minima', $data['recarga_minima']);
    $stmt->bindParam(':taxa_saque', $data['taxa_saque']);
    $stmt->bindParam(':lv1', $data['lv1']);
    $stmt->bindParam(':lv2', $data['lv2']);
    $stmt->bindParam(':lv3', $data['lv3']);
    $stmt->bindParam(':saque_diario_max', $data['saque_diario_max']);
    $stmt->bindParam(':saque_maximo_por_transacao', $data['saque_maximo_por_transacao']);
    $stmt->bindParam(':permitir_saque_24h', $data['permitir_saque_24h'], PDO::PARAM_INT); // Para booleanos (0 ou 1)
    $stmt->bindParam(':id', $data['id'], PDO::PARAM_INT);

    $stmt->execute();

    // 6. Verifique se alguma linha foi afetada para confirmar a atualização
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Configuração atualizada com sucesso!']);
    } else {
        // Isso pode acontecer se o ID não existir ou se os dados não mudaram (iguais aos do BD)
        echo json_encode(['success' => false, 'message' => 'Nenhuma alteração foi feita ou a configuração não foi encontrada.']);
    }

} catch (PDOException $e) {
    // Em caso de erro no banco de dados, registra e retorna erro genérico
    error_log("Erro ao atualizar configuração no DB: " . $e->getMessage());
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor ao salvar configuração.']);
}

$pdo = null; // Fecha a conexão PDO
?>