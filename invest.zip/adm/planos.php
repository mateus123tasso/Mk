<?php
// Ensure session is started before any output
session_start();

// Redirect if admin is not logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.html");
    exit();
}

// Include database connection
require '../servidor/database.php'; // Verifique se o caminho para database.php está correto

// Defina o domínio base do seu site
$base_url = 'https://raspwin.com/'; // Ajuste para o seu domínio

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Query to fetch all plans, ordered by name
    $stmt = $pdo->query("SELECT * FROM planos ORDER BY nome ASC");
    $planos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Log the error and display a user-friendly message
    error_log("Database connection error: " . $e->getMessage());
    die("Erro ao conectar ao banco de dados. Por favor, tente novamente mais tarde.");
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Planos - Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4CAF50;
            --secondary-color: #2c3e50;
            --accent-color: #FFA500;
            --light-bg: #eef2f6;
            --white: #ffffff;
            --text-dark: #333;
            --text-light: #ecf0f1;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }

        /* --- Navbar Styling --- */
        .navbar {
            background-color: var(--secondary-color) !important;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            letter-spacing: 1px;
            color: var(--text-light) !important;
        }
        .navbar-nav .nav-link {
            color: #bdc3c7 !important;
            transition: color 0.3s ease, background-color 0.3s ease;
            border-radius: 5px;
            margin: 0 5px;
            padding: 8px 15px;
        }
        .navbar-nav .nav-link:hover,
        .navbar-nav .nav-link.active {
            color: var(--white) !important;
            background-color: #34495e;
        }
        .navbar-toggler {
            border-color: rgba(255, 255, 255, 0.2);
        }
        .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }

        /* --- Main Content Container --- */
        .container.mt-4 {
            padding-top: 15px;
            padding-bottom: 15px;
        }

        /* --- Table Container --- */
        .table-container {
            margin: 20px auto;
            max-width: 1400px;
            background-color: var(--white);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.6s ease-out forwards;
            opacity: 0;
            transform: translateY(15px);
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            color: var(--secondary-color);
            font-weight: 600;
            margin-bottom: 25px;
            font-size: 1.5rem;
        }

        /* --- Table Styling --- */
        .table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            font-size: 0.85rem;
        }
        .table thead th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: 600;
            padding: 10px 8px;
            border-bottom: none;
            vertical-align: middle;
            text-align: center;
            font-size: 0.8rem;
            white-space: nowrap;
            min-height: 40px;
        }
        .table tbody tr {
            background-color: var(--white);
            transition: background-color 0.2s ease, transform 0.2s ease;
        }
        .table tbody tr:hover {
            background-color: #f8f9fa;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .table tbody td {
            padding: 10px 8px;
            vertical-align: middle;
            text-align: center;
            border-top: 1px solid #dee2e6;
            font-size: 0.8rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            min-height: 45px;
            line-height: 1.4;
        }
        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f7f9fc;
        }
        
        /* --- Product Image Styling --- */
        .product-image {
            width: 50px;
            height: 50px;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            object-fit: cover;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .product-image:hover {
            transform: scale(1.1);
        }
        
        .no-image {
            width: 50px;
            height: 50px;
            background: #f8f9fa;
            border: 2px dashed #dee2e6;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6c757d;
            font-size: 0.7rem;
            margin: 0 auto;
        }

        /* --- Compact Button Styles --- */
        .btn {
            font-weight: 500;
            padding: 4px 8px;
            border-radius: 4px;
            transition: all 0.2s ease;
            font-size: 0.75rem;
            margin: 1px;
        }
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        .btn-primary:hover {
            background-color: #43a047;
            border-color: #43a047;
            transform: translateY(-1px);
        }
        .btn-warning {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            color: var(--text-dark);
        }
        .btn-warning:hover {
            background-color: #e69500;
            border-color: #e69500;
            transform: translateY(-1px);
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
            transform: translateY(-1px);
        }
        .btn-sm {
            padding: 3px 6px;
            font-size: 0.7rem;
        }

        /* --- Modal Styling --- */
        .modal-content {
            border-radius: 10px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            border: none;
        }
        .modal-header {
            background-color: var(--secondary-color);
            color: var(--white);
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            padding: 12px 20px;
            border-bottom: none;
        }
        .modal-title {
            font-weight: 600;
            font-size: 1.1rem;
        }
        .modal-body {
            padding: 20px;
        }
        .modal-footer {
            border-top: 1px solid #e9ecef;
            padding: 12px 20px;
        }
        .form-label {
            font-weight: 500;
            color: var(--secondary-color);
            font-size: 0.9rem;
        }
        .form-control {
            border-radius: 6px;
            padding: 8px 10px;
            transition: border-color 0.2s ease, box-shadow 0.2s ease;
            font-size: 0.9rem;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(76, 175, 80, 0.25);
        }
        .current-image-container {
            text-align: center;
            margin-bottom: 15px;
        }
        .current-image {
            max-width: 120px;
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .image-upload-info {
            background: #e8f4fd;
            border: 1px solid #b3d9f2;
            border-radius: 6px;
            padding: 10px;
            margin-top: 8px;
            font-size: 0.8rem;
            color: #0c5aa0;
        }
        
        .image-upload-info strong {
            color: #084c87;
        }

        /* --- Mobile Responsive CSS --- */
        @media (max-width: 768px) {
            .table-container {
                padding: 15px;
                margin: 15px auto;
                max-width: 95%;
            }

            .table thead {
                display: none;
            }

            .table tbody, .table tr, .table td {
                display: block;
                width: 100%;
            }

            .table tr {
                margin-bottom: 15px;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                overflow: hidden;
                background: white;
            }

            .table td {
                text-align: right;
                padding-left: 50%;
                position: relative;
                white-space: normal;
                border: none;
                padding: 8px 15px;
            }

            .table td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                width: calc(50% - 20px);
                padding-right: 10px;
                white-space: nowrap;
                text-align: left;
                font-weight: 600;
                color: var(--secondary-color);
            }

            .table td:nth-of-type(1)::before { content: "ID"; }
            .table td:nth-of-type(2)::before { content: "Nome"; }
            .table td:nth-of-type(3)::before { content: "Preço"; }
            .table td:nth-of-type(4)::before { content: "Receita Total"; }
            .table td:nth-of-type(5)::before { content: "Receita Diária"; }
            .table td:nth-of-type(6)::before { content: "Dias de Receita"; }
            .table td:nth-of-type(7)::before { content: "Limite"; }
            .table td:nth-of-type(8)::before { content: "VIP"; }
            .table td:nth-of-type(9)::before { content: "Imagem"; }
            .table td:nth-of-type(10)::before { content: ""; }

            .table td:last-child {
                text-align: center;
                padding-top: 15px;
                padding-bottom: 15px;
                border-top: 1px solid #eee;
                padding-left: 15px;
            }

            .btn-group {
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .btn-group .btn {
                width: 100%;
                padding: 8px 12px;
                font-size: 0.85rem;
            }

            .mb-3.text-end {
                text-align: center !important;
            }
            .navbar-nav {
                text-align: center;
            }
            .navbar-nav .nav-item {
                margin: 5px 0;
            }
            
            h2 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Painel Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Início</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="usuarios.php">Usuários</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transacoes.php">Transações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="planos.php">Planos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="configuracoes.php">Configurações</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="depositos.php">Depósitos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saques.php">Saques</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="niveis_vip.php">VIPs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <h2 class="text-center mb-3">Gerenciar Planos</h2>
        <div class="mb-3 text-end">
            <a href="add_planos.php" class="btn btn-primary">+ Novo Plano</a>
        </div>
        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th style="width: 5%">ID</th>
                            <th style="width: 14%">Nome</th>
                            <th style="width: 8%">Preço</th>
                            <th style="width: 9%">Receita Total</th>
                            <th style="width: 9%">Receita Diária</th>
                            <th style="width: 6%">Dias</th>
                            <th style="width: 7%">Limite</th>
                            <th style="width: 15%">VIP</th>
                            <th style="width: 8%">Imagem</th>
                            <th style="width: 19%">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($planos): ?>
                            <?php foreach ($planos as $plano): ?>
                                <tr>
                                    <td data-label="ID"><?php echo htmlspecialchars($plano['id']); ?></td>
                                    <td data-label="Nome">
                                        <?php echo htmlspecialchars($plano['nome']); ?>
                                    </td>
                                    <td data-label="Preço">R$<?php echo number_format($plano['preco'], 2, ',', '.'); ?></td>
                                    <td data-label="Receita Total">R$<?php echo number_format($plano['receitaTotal'], 2, ',', '.'); ?></td>
                                    <td data-label="Receita Diária">R$<?php echo number_format($plano['receitaDiaria'], 2, ',', '.'); ?></td>
                                    <td data-label="Dias"><?php echo htmlspecialchars($plano['diasDeReceita']); ?></td>
                                    <td data-label="Limite"><?php echo htmlspecialchars($plano['limite']); ?></td>
                                    <td data-label="VIP"><?php echo htmlspecialchars($plano['vip']); ?></td>
                                    <td data-label="Imagem">
                                        <?php if (!empty($plano['image_url'])): ?>
                                            <?php $full_image_url = $base_url . ltrim($plano['image_url'], '/'); ?>
                                            <img src="<?php echo htmlspecialchars($full_image_url); ?>" 
                                                 alt="Imagem do Plano" 
                                                 class="product-image"
                                                 onclick="previewImage('<?php echo htmlspecialchars($full_image_url); ?>', '<?php echo htmlspecialchars($plano['nome']); ?>')">
                                        <?php else: ?>
                                            <div class="no-image">Sem imagem</div>
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="">
                                        <div class="btn-group">
                                            <button class="btn btn-warning btn-sm" onclick="editPlan(<?php echo htmlspecialchars(json_encode($plano), ENT_QUOTES, 'UTF-8'); ?>)">Editar</button>
                                            <button class="btn btn-danger btn-sm" onclick="deletePlan(<?php echo $plano['id']; ?>)">Excluir</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="10" class="text-center py-4">Nenhum plano encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal de Edição -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Editar Plano</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm">
                        <input type="hidden" id="editid" name="id">
                        
                        <!-- Imagem Atual -->
                        <div class="current-image-container">
                            <img id="currentImage" src="" alt="Imagem Atual do Plano" class="current-image">
                        </div>
                        
                        <!-- Campos do Formulário -->
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editNome" class="form-label">Nome</label>
                                <input type="text" class="form-control" id="editNome" name="nome" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editPreco" class="form-label">Preço</label>
                                <input type="number" step="0.01" class="form-control" id="editPreco" name="preco" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="editReceitaTotal" class="form-label">Receita Total</label>
                                <input type="number" step="0.01" class="form-control" id="editReceitaTotal" name="receitaTotal" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="editReceitaDiaria" class="form-label">Receita Diária</label>
                                <input type="number" step="0.01" class="form-control" id="editReceitaDiaria" name="receitaDiaria" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="editDiasDeReceita" class="form-label">Dias de Receita</label>
                                <input type="number" class="form-control" id="editDiasDeReceita" name="diasDeReceita" required min="0">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="editLimite" class="form-label">Limite</label>
                                <input type="number" class="form-control" id="editLimite" name="limite" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="editVip" class="form-label">VIP</label>
                                <input type="text" class="form-control" id="editVip" name="vip">
                            </div>
                        </div>
                        
                        <!-- Upload de Imagem -->
                        <div class="mb-3">
                            <label for="editImagem" class="form-label">Nova Imagem</label>
                            <input type="file" class="form-control" id="editImagem" name="imagem" accept="image/*">
                            <div class="image-upload-info">
                                <strong>Recomendação:</strong> Use imagens quadradas de <strong>500x500 pixels</strong> para melhor qualidade e uniformidade na exibição.
                                <br><small>Formatos aceitos: JPG, PNG, GIF (máx. 2MB)</small>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Salvar Alterações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Exclusão -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Excluir Plano</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Tem certeza de que deseja excluir este plano? Esta ação é irreversível.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger btn-sm" id="confirmDeleteBtn">Excluir</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Preview da Imagem -->
    <div class="modal fade" id="imagePreviewModal" tabindex="-1" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imagePreviewModalLabel">Preview da Imagem</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <img id="previewImage" src="" alt="Preview" style="max-width: 100%; max-height: 400px; border-radius: 8px;">
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script>
        let currentPlanId = null;

        // Função para preview da imagem
        function previewImage(src, title) {
            document.getElementById('previewImage').src = src;
            document.getElementById('imagePreviewModalLabel').textContent = `Imagem - ${title}`;
            const modal = new bootstrap.Modal(document.getElementById('imagePreviewModal'));
            modal.show();
        }

        function editPlan(plano) {
            currentPlanId = plano.id;
            document.getElementById('editid').value = plano.id;
            document.getElementById('editNome').value = plano.nome;
            document.getElementById('editPreco').value = plano.preco;
            document.getElementById('editReceitaTotal').value = plano.receitaTotal;
            document.getElementById('editReceitaDiaria').value = plano.receitaDiaria;
            document.getElementById('editDiasDeReceita').value = plano.diasDeReceita;
            document.getElementById('editLimite').value = plano.limite;
            document.getElementById('editVip').value = plano.vip;

            const currentImage = document.getElementById('currentImage');
            if (plano.image_url) {
                // Construir URL completa
                const baseUrl = '<?php echo $base_url; ?>';
                const fullUrl = baseUrl + plano.image_url.replace(/^\/+/, '');
                currentImage.src = fullUrl;
                currentImage.style.display = 'block';
            } else {
                currentImage.style.display = 'none';
            }

            const editModal = new bootstrap.Modal(document.getElementById('editModal'));
            editModal.show();
        }

        function deletePlan(id) {
            currentPlanId = id;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }

        function handleEditFormSubmit(event) {
            event.preventDefault();

            if (currentPlanId === null) {
                Swal.fire('Erro', 'Nenhum plano selecionado para edição.', 'error');
                return;
            }

            const formData = new FormData(event.target);
            formData.append('id', currentPlanId);

            Swal.fire({
                title: 'Confirmar Alterações?',
                text: "Você tem certeza que deseja salvar as alterações neste plano?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim, Salvar!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    Swal.fire({
                        title: 'Salvando...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    axios.post('api_plan.php', formData, {
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    })
                    .then(response => {
                        Swal.close();
                        if (response.data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Sucesso!',
                                text: response.data.message,
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro!',
                                text: response.data.message,
                                showConfirmButton: true
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Erro ao atualizar o plano:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro de Requisição',
                            text: 'Ocorreu um erro ao atualizar o plano. Tente novamente.',
                            showConfirmButton: true
                        });
                    });
                }
            });
            
            const editModalInstance = bootstrap.Modal.getInstance(document.getElementById('editModal'));
            if (editModalInstance) editModalInstance.hide();
        }

        document.getElementById('editForm').addEventListener('submit', handleEditFormSubmit);

        document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
            if (currentPlanId !== null) {
                axios.delete(`api_plan.php?id=${currentPlanId}`)
                    .then(response => {
                        if (response.data.success) {
                            Swal.fire({
                                icon: 'success',
                                title: 'Sucesso!',
                                text: response.data.message,
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Erro!',
                                text: response.data.message,
                                showConfirmButton: true
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Erro ao excluir o plano:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro de Requisição',
                            text: 'Ocorreu um erro ao excluir o plano. Tente novamente.',
                            showConfirmButton: true
                        });
                    });
            }
        });
    </script>
</body>
</html>