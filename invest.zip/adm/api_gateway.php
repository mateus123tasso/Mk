<?php
session_start();

// Define o arquivo de log para o gateway
define('LOG_FILE_GATEWAY', __DIR__ . '/api_gateway.log');

/**
 * Função para registrar mensagens no log do gateway.
 * @param string $message A mensagem a ser logada.
 * @param string $level O nível do log (INFO, DEBUG, ERROR, WARNING).
 */
function write_log_gateway($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);
    file_put_contents(LOG_FILE_GATEWAY, $log_entry, FILE_APPEND);
}

write_log_gateway("Início da requisição para api_gateway.php. Método: " . $_SERVER['REQUEST_METHOD'], 'DEBUG');

// Verifica se o administrador está logado. Se não, redireciona.
if (!isset($_SESSION['admin_logged_in'])) {
    write_log_gateway("Acesso negado. Sessão de administrador não encontrada.", 'WARNING');
    http_response_code(403); // Forbidden
    echo json_encode(['success' => false, 'message' => 'Acesso negado. Faça login como administrador.']);
    exit();
}

// Inclui o arquivo de conexão com o banco de dados
require '../servidor/database.php';

header('Content-Type: application/json');

// 1. Conecta ao banco de dados usando PDO
try {
    write_log_gateway("Tentando conectar ao banco de dados...", 'DEBUG');
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    write_log_gateway("Conexão com o banco de dados estabelecida.", 'INFO');
} catch (PDOException $e) {
    write_log_gateway("Erro de conexão com o banco de dados: " . $e->getMessage(), 'CRITICAL');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco de dados.']);
    exit();
}

// 2. Lê os dados da requisição PUT
$input = file_get_contents('php://input');
$data = json_decode($input, true);

write_log_gateway("Dados recebidos da requisição PUT: " . json_encode($data), 'DEBUG');

// 3. Verifique os dados de entrada
if (empty($data['client_id']) || empty($data['client_secret']) || empty($data['urlnoty'])) {
    write_log_gateway("Dados incompletos. Rejeitando requisição.", 'WARNING');
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dados incompletos. Por favor, preencha todos os campos.']);
    exit();
}

try {
    // 4. VERIFICA SE O REGISTRO JÁ EXISTE ANTES DE TENTAR INSERIR OU ATUALIZAR
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM gateway_bspaybr WHERE id = ?");
    $stmt->execute([$data['id']]);
    $entryExists = ($stmt->fetchColumn() > 0);

    if ($entryExists) {
        // Se o registro já existe, apenas atualiza
        write_log_gateway("Registro com ID " . $data['id'] . " existe. Tentando atualizar.", 'INFO');
        $stmt = $pdo->prepare("UPDATE gateway_bspaybr SET client_id = ?, client_secret = ?, urlnoty = ? WHERE id = ?");
        $stmt->execute([$data['client_id'], $data['client_secret'], $data['urlnoty'], $data['id']]);
        write_log_gateway("Registro atualizado com sucesso para ID: " . $data['id'], 'SUCCESS');
    } else {
        // Se o registro não existe, insere um novo
        write_log_gateway("Registro com ID " . $data['id'] . " não existe. Tentando inserir.", 'INFO');
        $stmt = $pdo->prepare("INSERT INTO gateway_bspaybr (id, client_id, client_secret, urlnoty) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data['id'], $data['client_id'], $data['client_secret'], $data['urlnoty']]);
        write_log_gateway("Novo registro inserido com sucesso para ID: " . $data['id'], 'SUCCESS');
    }
    
    echo json_encode(['success' => true, 'message' => 'Credenciais do gateway atualizadas com sucesso!']);

} catch (PDOException $e) {
    write_log_gateway("Erro ao salvar as credenciais no banco de dados: " . $e->getMessage(), 'ERROR');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar as credenciais no banco de dados.']);
}

$pdo = null; // Fecha a conexão PDO
?>