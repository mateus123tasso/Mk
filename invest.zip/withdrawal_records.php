<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

include('./servidor/infor.php');
require './servidor/database.php'; // Usa a conexão PDO

$user_id = $_SESSION['user_id'];

// A consulta SQL agora usa PDO, o mesmo padrão dos outros arquivos
try {
    $sql = "SELECT * FROM transacoes_retirada WHERE usuario_id = ? ORDER BY data_transacao DESC";
    $stmt = $pdo->prepare($sql); // Usa a variável $pdo
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Busca todos os resultados em um array
} catch (PDOException $e) {
    // Em caso de erro, registra no log para debugging
    error_log("Erro ao buscar histórico de retirada: " . $e->getMessage());
    $result = []; // Garante que a variável seja um array vazio para não dar erro no loop
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="/static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Histórico de Retirada</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&family=Orbitron:wght@400;500;700;900&display=swap" rel="stylesheet">
    <style>
        /* --- General Styles (Same as index.php) --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #fff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }
        ::-webkit-scrollbar { width: 0px; background: transparent; }
        body { -ms-overflow-style: none; scrollbar-width: none; }

        /* --- Background Effects (Same as index.php) --- */
        .cyber-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image:
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 30px 30px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }
        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(30px, 30px); }
        }
        .floating-particles {
            position: fixed;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }
        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: radial-gradient(circle, rgba(255,215,0,0.8), transparent);
            border-radius: 50%;
            animation: floatParticle linear infinite;
        }
        @keyframes floatParticle {
            0% { transform: translateY(100vh) translateX(0px); opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { transform: translateY(-100px) translateX(-50px); opacity: 0; }
        }

        /* --- Main Container --- */
        .main-container {
            position: relative;
            z-index: 10;
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 100px; /* Space for the tabbar */
        }

        /* --- Header (Similar to index.php) --- */
        .cyber-header {
            position: relative;
            padding: 60px 20px 30px;
            background: linear-gradient(135deg,
                rgba(255,255,255,0.1) 0%,
                rgba(255,255,255,0.05) 50%,
                rgba(255,255,255,0.1) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,215,0,0.3);
            margin-bottom: 30px;
        }
        .cyber-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            animation: scanLine 3s ease-in-out infinite;
        }
        @keyframes scanLine {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }
        .header-content {
            display: flex;
            align-items: center;
        }
        .header-title {
            font-family: 'Orbitron', monospace;
            font-size: 28px;
            font-weight: 900;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            text-shadow: 0 0 20px rgba(255,215,0,0.5);
        }
        .header-title::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 2px;
        }
        .back-button {
            margin-right: 20px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .back-button:hover {
            transform: translateX(-5px);
        }
        .back-button img {
            width: 28px;
            filter: brightness(1.2) drop-shadow(0 0 5px rgba(255,215,0,0.3));
        }

        /* --- Transaction List (New Glassmorphism Style) --- */
        .my-bill-content {
            padding: 0 20px;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .my-bill-box {
            background: linear-gradient(135deg,
                rgba(255,255,255,0.08) 0%,
                rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(15px);
            border-radius: 24px;
            border: 1px solid rgba(255,215,0,0.15);
            padding: 20px;
            position: relative;
            transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            animation: fadeInUp 0.8s ease-out forwards;
            opacity: 0;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .my-bill-box:hover {
            transform: translateY(-5px);
            border-color: rgba(255,215,0,0.4);
            box-shadow:
                0 15px 30px rgba(0,0,0,0.3),
                0 0 20px rgba(255,215,0,0.2);
        }
        .my-bill-box div {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .my-bill-box div:last-child {
            margin-bottom: 0;
        }
        .my-bill-box .description {
            font-size: 1.1em;
            font-weight: 600;
            color: #fff;
            text-shadow: 0 0 10px rgba(255,255,255,0.3);
        }
        .my-bill-box .amount {
            font-family: 'Orbitron', monospace;
            font-size: 1.2em;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
        }
        .my-bill-box .date-label,
        .my-bill-box .date-value {
            font-size: 0.9em;
            color: rgba(255, 255, 255, 0.7);
        }
        /* Status Colors */
        .my-bill-box .status-pending { color: #FFA500; font-weight: 600; }
        .my-bill-box .status-concluido { color: #00e880; font-weight: 600; }
        .my-bill-box .status-falhou { color: #FF4D4D; font-weight: 600; }

        .no-more-data {
            text-align: center;
            padding: 40px 20px;
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.1em;
            font-weight: 500;
        }
        
        /* --- Responsividade --- */
        @media (max-width: 500px) {
            .cyber-header { padding: 50px 15px 25px; }
            .header-title { font-size: 22px; }
            .back-button img { width: 24px; }
            .my-bill-content { padding: 0 15px; }
            .my-bill-box { padding: 15px; border-radius: 15px; }
            .my-bill-box .description { font-size: 1em; }
            .my-bill-box .amount { font-size: 1.1em; }
            .my-bill-box .date-label,
            .my-bill-box .date-value { font-size: 0.8em; }
        }
    </style>
</head>

<body>
    <div class="cyber-grid"></div>
    <div class="floating-particles" id="particles"></div>

    <div class="main-container">
        <div class="cyber-header">
            <div class="header-content">
                <div class="back-button" onclick="window.history.back()">
                    <img src="/static/yunta/image/device/left.png" alt="Voltar">
                </div>
                <div class="header-title">Histórico</div>
            </div>
        </div>

        <div class="my-bill-content">
            <?php if (!empty($result)) { ?>
                <?php foreach ($result as $row) {
                    $status_class = '';
                    switch (strtolower($row['status'])) {
                        case 'pendente':
                            $status_class = 'status-pending';
                            break;
                        case 'pago': // Alterado para 'pago' para corresponder ao webhook
                            $status_class = 'status-concluido';
                            break;
                        case 'falhou':
                        case 'cancelada': // Adicionado para corresponder ao webhook
                            $status_class = 'status-falhou';
                            break;
                        default:
                            $status_class = '';
                            break;
                    }
                ?>
                    <div class="my-bill-box">
                        <div>
                            <span class="description">Retirada de fundos</span>
                            <span class="amount">R$<?php echo number_format($row['valor_retirada'], 2, ',', '.'); ?></span>
                        </div>
                        <div>
                            <span>Status</span>
                            <span class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                        </div>
                        <div>
                            <span>Data</span>
                            <span><?php echo date("d/m/Y H:i", strtotime($row['data_transacao'])); ?></span>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="no-more-data">
                    Não há dados para exibir.
                </div>
            <?php } ?>
        </div>
    </div>
    
    <script>
        // Create floating particles
        function createParticles() {
            const particleContainer = document.getElementById('particles');
            const particleCount = 15;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 10 + 5) + 's';
                particle.style.animationDelay = Math.random() * 5 + 's';
                particleContainer.appendChild(particle);
            }
        }
        createParticles();
    </script>

</body>
</html>