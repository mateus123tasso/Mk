<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

// REMOVIDO: O include('servidor/atualizar_rendimento.php') foi removido.
// A lógica de rendimento é processada na página 'equipe.php'.
include('./servidor/infor.php');
require './servidor/database.php'; // Usa a conexão PDO

$user_id = $_SESSION['user_id'];

// A consulta SQL agora usa PDO, o mesmo padrão dos outros arquivos
try {
    $sql = "SELECT * FROM transacoes_retirada WHERE usuario_id = ? ORDER BY data_transacao DESC";
    $stmt = $pdo->prepare($sql); // Usa a variável $pdo
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Busca todos os resultados em um array
} catch (PDOException $e) {
    // Em caso de erro, registra no log para debugging
    error_log("Erro ao buscar histórico de retirada: " . $e->getMessage());
    $result = []; // Garante que a variável seja um array vazio para não dar erro no loop
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="/static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Histórico de Retirada</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <style>
        /* Reset e estilos de fundo com gradiente e formas animadas */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow-x: hidden;
            position: relative;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Oculta a barra de rolagem para todos os navegadores */
        ::-webkit-scrollbar { display: none; width: 0 !important; height: 0 !important; }
        body { -ms-overflow-style: none; scrollbar-width: none; }

        /* Elementos de fundo animados (bolhas) */
        .background-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* Estilos do cabeçalho */
        .page-head {
            padding: 25px 20px 20px 20px;
            color: #fff;
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            max-width: 450px;
            z-index: 10;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
            font-family: 'Montserrat', sans-serif;
            letter-spacing: -0.5px;
        }
        .page-head .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .page-head .back-button:hover {
            transform: translateX(-5px);
        }
        .page-head .back-button img {
            width: 28px;
            height: 28px;
            margin-right: 15px;
            filter: drop-shadow(2px 2px 5px rgba(0,0,0,0.3));
        }
        .page-head span {
            font-weight: 800;
        }

        /* Estilos da lista de transações (aplicando Glassmorphism) */
        .my-bill-content {
            width: 100%;
            max-width: 450px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 20px;
            padding: 20px 25px;
            margin: 20px auto;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 1;
            animation: slideInUp 0.8s ease-out forwards;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .my-bill-box {
            padding: 18px 0px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            transition: background 0.3s ease;
        }
        .my-bill-box:last-child {
            border-bottom: none;
        }
        .my-bill-box:hover {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        .my-bill-box > div {
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: rgba(255, 255, 255, 0.85);
            font-size: 1.05em;
            font-weight: 400;
        }
        .my-bill-box > div:first-child {
            margin-top: 0;
            font-weight: 500;
        }
        .my-bill-box .description {
            color: #fff;
            font-size: 1.15em;
            font-weight: 600;
        }
        .my-bill-box .amount {
            color: #FFD700;
            font-size: 1.2em;
            font-weight: 700;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }
        /* Status colors */
        .my-bill-box .status-pending { color: #FFA500; font-weight: 600; }
        .my-bill-box .status-concluido { color: #2ECC71; font-weight: 600; }
        .my-bill-box .status-falhou { color: #FF4D4D; font-weight: 600; }

        .no-more-data {
            text-align: center;
            padding: 40px 0;
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.1em;
            font-weight: 500;
        }

        /* Responsividade */
        @media (max-width: 500px) {
            .page-head {
                font-size: 20px;
                padding: 20px 15px;
            }
            .page-head .back-button img {
                width: 24px;
                height: 24px;
                margin-right: 10px;
            }
            .my-bill-content {
                margin: 15px;
                padding: 15px 20px;
                border-radius: 15px;
            }
            .my-bill-box {
                padding: 15px 0;
            }
            .my-bill-box > div {
                font-size: 0.95em;
                margin-top: 8px;
            }
            .my-bill-box .description {
                font-size: 1.05em;
            }
            .my-bill-box .amount {
                font-size: 1.1em;
            }
            .no-more-data {
                padding: 30px 0;
                font-size: 1em;
            }
        }
    </style>
</head>

<body>
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="my-bill">
        <div class="page-head">
            <div class="back-button" onclick="window.history.back()">
                <img src="/static/yunta/image/device/left.png" alt="Voltar">
                <span>Histórico de Retiradas</span>
            </div>
        </div>

        <div class="my-bill-content">
            <?php if (!empty($result)) { ?>
                <?php foreach ($result as $row) {
                    $status_class = '';
                    switch (strtolower($row['status'])) {
                        case 'pendente':
                            $status_class = 'status-pending';
                            break;
                        case 'concluido':
                            $status_class = 'status-concluido'; // Corrigido
                            break;
                        case 'falhou':
                            $status_class = 'status-falhou'; // Corrigido
                            break;
                        default:
                            $status_class = '';
                            break;
                    }
                ?>
                    <div class="my-bill-box">
                        <div>
                            <span class="description">Retirada de fundos <span class="<?php echo $status_class; ?>"><?php echo htmlspecialchars($row['status']); ?></span></span>
                            <span class="amount">R$<?php echo number_format($row['valor_retirada'], 2, ',', '.'); ?></span>
                        </div>
                        <div>
                            <span>Data</span>
                            <span><?php echo date("d/m/Y H:i", strtotime($row['data_transacao'])); ?></span>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="no-more-data">
                    Não há mais dados (nenhum registro de retirada).
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>