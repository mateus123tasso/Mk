<div class="tabbar">
    <div class="tabbar-nav">
        <a href="/" class="tab-item" data-page="home">
            <svg class="tab-icon" viewBox="0 0 24 24">
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
            </svg>
            <div class="tab-text">Início</div>
        </a>
        <a href="/team" class="tab-item" data-page="team">
            <svg class="tab-icon" viewBox="0 0 24 24">
                <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-4 0c1.66 0 2.99-1.34 2.99-3S13.66 5 12 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-4 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm8 4c-2.33 0-7 1.17-7 3.5V19h14v-1.5c0-2.33-4.67-3.5-7-3.5z"/>
            </svg>
            <div class="tab-text">Equipe</div>
        </a>
        <a href="/record" class="tab-item" data-page="record">
            <svg class="tab-icon" viewBox="0 0 24 24">
                <path d="M13 3c-4.97 0-9 4.03-9 9H1l3.05 3.05c.29.29.76.29 1.05 0L8 12H5c0-3.86 3.14-7 7-7s7 3.14 7 7-3.14 7-7 7c-1.93 0-3.68-.79-4.95-2.05-.29-.29-.76-.29-1.05 0C7.81 20.35 9.8 21 12 21c4.97 0 9-4.03 9-9s-4.03-9-9-9z"/>
            </svg>
            <div class="tab-text">Registro</div>
        </a>
        <a href="/my" class="tab-item" data-page="my">
            <svg class="tab-icon" viewBox="0 0 24 24">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
            <div class="tab-text">Meu</div>
        </a>
    </div>
</div>

<script>
    // Este script é incluído com a tabbar, garantindo que ele seja executado uma vez.
    document.addEventListener('DOMContentLoaded', function() {
        const tabItems = document.querySelectorAll('.tabbar .tab-item');
        const currentPath = window.location.pathname;

        tabItems.forEach(item => {
            // Remove 'tab-active' de todos primeiro
            item.classList.remove('tab-active');

            const itemHref = item.getAttribute('href');
            // Lógica de ativação: verifica se o href do item corresponde ao caminho atual ou se é a raiz (home)
            if (currentPath === '/' && itemHref === '/') {
                item.classList.add('tab-active');
            } else if (itemHref && itemHref !== '/' && currentPath.startsWith(itemHref)) {
                item.classList.add('tab-active');
            }
        });
    });
</script>