<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

// O script de rendimento foi removido daqui, pois a lógica agora está em equipe.php
include('servidor/infor.php');
require 'servidor/database.php'; // Usa a conexão PDO

$user_id = $_SESSION['user_id'];

// A consulta SQL usa PDO, o mesmo padrão dos outros arquivos
try {
    $sql = "SELECT * FROM transacoes WHERE usuario_id = ? ORDER BY data_transacao DESC";
    $stmt = $pdo->prepare($sql); // Usa a variável $pdo
    $stmt->bindParam(1, $user_id, PDO::PARAM_INT);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Busca todos os resultados em um array
} catch (PDOException $e) {
    // Em caso de erro, registra no log e exibe uma mensagem amigável
    error_log("Erro ao buscar transações do usuário: " . $e->getMessage());
    $result = []; // Garante que a variável seja um array vazio para não dar erro no loop
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Minhas Transações</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="mytabbar.css">
    <style>
        /* Variáveis CSS para Cores e Fontes */
        :root {
            --primary-bg-gradient: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            --card-bg-color: rgba(255, 255, 255, 0.15);
            --card-border-color: rgba(255, 255, 255, 0.2);
            --text-light: rgba(255, 255, 255, 0.85);
            --text-dark: #fff;
            --highlight-color: #FFD700; /* Dourado */
            --shadow-color: rgba(0, 0, 0, 0.4);
            --font-poppins: 'Poppins', sans-serif;
            --font-montserrat: 'Montserrat', sans-serif;
        }

        /* Reset e Estilos Globais */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--font-poppins);
        }

        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            background: var(--primary-bg-gradient);
            color: var(--text-dark);
            overflow-x: hidden;
            position: relative;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        /* Ocultar Barra de Rolagem */
        ::-webkit-scrollbar { display: none; width: 0 !important; height: 0 !important; }
        body { -ms-overflow-style: none; scrollbar-width: none; }

        /* Animação para entrada de elementos */
        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Formas de Fundo Animadas (Bolhas) */
        .background-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* Cabeçalho da Página */
        .page-head {
            padding: 25px 20px 20px 20px;
            color: var(--text-dark);
            font-size: 24px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            max-width: 450px;
            z-index: 10;
            text-shadow: 2px 2px 8px var(--shadow-color);
            font-family: var(--font-montserrat);
            letter-spacing: -0.5px;
        }
        .page-head .back-icon {
            width: 28px;
            height: 28px;
            margin-right: 15px;
            filter: drop-shadow(2px 2px 5px var(--shadow-color));
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .page-head .back-icon:hover {
            transform: translateX(-5px);
        }
        .page-head span {
            font-weight: 800;
        }

        /* Conteúdo da Lista de Transações (Card Glassmorphism) */
        .my-bill-content {
            width: 100%;
            max-width: 450px;
            background: var(--card-bg-color);
            border-radius: 20px;
            padding: 20px 25px;
            margin: 20px auto;
            box-shadow: 0 15px 40px var(--shadow-color);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid var(--card-border-color);
            z-index: 1;
            animation: slideInUp 0.8s ease-out forwards;
        }

        /* Itens Individuais da Transação */
        .my-bill-box {
            padding: 18px 0;
            border-bottom: 1px solid var(--card-border-color);
            transition: background 0.3s ease, transform 0.2s ease;
            position: relative;
        }
        .my-bill-box:last-child {
            border-bottom: none;
        }
        .my-bill-box:hover {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            transform: translateY(-3px);
        }
        .my-bill-box > div {
            margin-top: 10px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: var(--text-light);
            font-size: 1.05em;
            font-weight: 400;
        }
        .my-bill-box > div:first-child {
            margin-top: 0;
            color: var(--text-dark);
            font-size: 1.15em;
            font-weight: 600;
        }
        .my-bill-box > div:first-child .value {
            color: var(--highlight-color);
            font-size: 1.2em;
            font-weight: 700;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* Mensagem de Sem Dados */
        .no-more-data {
            text-align: center;
            padding: 40px 0;
            color: rgba(255, 255, 255, 0.7);
            font-size: 1.1em;
            font-weight: 500;
        }

        /* Responsividade */
        @media (max-width: 500px) {
            .page-head {
                font-size: 20px;
                padding: 20px 15px;
            }
            .page-head .back-icon {
                width: 24px;
                height: 24px;
                margin-right: 10px;
            }
            .my-bill-content {
                margin: 15px;
                padding: 15px 20px;
                border-radius: 15px;
            }
            .my-bill-box {
                padding: 15px 0;
            }
            .my-bill-box > div {
                font-size: 0.95em;
                margin-top: 8px;
            }
            .my-bill-box > div:first-child {
                font-size: 1.05em;
            }
            .my-bill-box > div:first-child .value {
                font-size: 1.1em;
            }
            .no-more-data {
                padding: 30px 0;
                font-size: 1em;
            }
        }
    </style>
</head>
<body>
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="my-bill">
        <div class="page-head">
            <div>
                <img src="static/yunta/image/device/left.png" class="back-icon" onclick="window.history.back()" alt="Back">
                <span>Minhas Transações</span>
            </div>
        </div>
        <div class="my-bill-content">
            <?php if (!empty($result)) { ?>
                <?php foreach ($result as $row) { ?>
                    <div class="my-bill-box">
                        <div>
                            <span><?php echo htmlspecialchars($row['descricao']); ?></span>
                            <span class="value">R$<?php echo number_format($row['valor'], 2, ',', '.'); ?></span>
                        </div>
                        <div>
                            <span>Data</span>
                            <span><?php echo date("d/m/Y H:i", strtotime($row['data_transacao'])); ?></span>
                        </div>
                    </div>
                <?php } ?>
            <?php } else { ?>
                <div class="no-more-data">
                    Nenhum registro de transação encontrado.
                </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>