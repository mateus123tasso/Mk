<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <title>fany-ai - Acesso à Plataforma</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow: hidden;
            position: relative;
            padding: 10px;
        }

        /* Efeitos de fundo otimizados */
        .background-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.04);
            border-radius: 50%;
            animation: moveShapes 20s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 80px; height: 80px; top: 15%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 120px; height: 120px; top: 60%; left: 85%; animation-delay: 3s; }
        .background-shapes div:nth-child(3) { width: 60px; height: 60px; top: 75%; left: 15%; animation-delay: 6s; }
        .background-shapes div:nth-child(4) { width: 160px; height: 160px; top: 25%; left: 70%; animation-delay: 9s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.7; }
            50% { transform: translate(20px, 30px) scale(1.05); opacity: 0.5; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.7; }
        }

        /* Container principal compacto */
        .login-card {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 16px;
            padding: 32px;
            width: 100%;
            max-width: 360px;
            text-align: center;
            box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 1;
            animation: slideInUp 0.8s ease-out forwards;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .logo {
            margin-bottom: 20px;
            max-width: 120px;
            height: auto;
            display: block;
            margin-left: auto;
            margin-right: auto;
            filter: drop-shadow(0 0 8px rgba(0, 0, 0, 0.5));
        }

        .login-card h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.2em;
            margin-bottom: 8px;
            color: #fff;
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
            font-weight: 800;
            letter-spacing: -0.3px;
        }

        .login-card p.subtitle {
            font-size: 0.95em;
            color: rgba(255, 255, 255, 0.85);
            margin-bottom: 28px;
            font-weight: 400;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        .input-group label {
            position: absolute;
            top: 50%;
            left: 55px;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.7);
            font-size: 0.9em;
            pointer-events: none;
            transition: 0.3s ease all;
            background: transparent;
            padding: 0 4px;
            z-index: 5;
            width: auto;
            text-align: left;
        }

        .input-group.no-prefix label {
            left: 16px;
        }

        .input-group input {
            width: 100%;
            padding: 14px 16px;
            padding-left: 55px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            font-size: 0.95em;
            color: #fff;
            background-color: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.15);
        }

        .input-group.no-prefix input {
            padding-left: 16px;
        }

        .input-group .prefix {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: rgba(255, 255, 255, 0.95);
            font-weight: 600;
            font-size: 0.95em;
            z-index: 6;
        }

        .input-group input:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.7);
            background-color: rgba(255, 255, 255, 0.25);
            box-shadow: 0 0 0 3px rgba(255, 255, 255, 0.3), inset 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .input-group input:focus + label,
        .input-group input:not(:placeholder-shown) + label {
            top: -12px;
            left: 16px;
            transform: none;
            font-size: 0.75em;
            color: #fff;
            background: linear-gradient(90deg, #2ECC71, #FFD700);
            padding: 2px 8px;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
            z-index: 10;
            width: auto;
            text-align: left;
        }

        .login-button {
            background: linear-gradient(45deg, #FFD700, #FFA500);
            color: #333;
            padding: 14px 24px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 700;
            width: 100%;
            transition: all 0.3s ease;
            margin-top: 24px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
            letter-spacing: 0.5px;
        }

        .login-button:hover {
            background: linear-gradient(45deg, #FFA500, #FFD700);
            transform: translateY(-2px);
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.4);
        }

        .login-button:active {
            transform: translateY(0);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .links {
            margin-top: 24px;
            font-size: 0.9em;
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .links a {
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            padding: 4px 0;
        }

        .links a:hover {
            color: #fff;
            text-shadow: 0 0 8px rgba(255, 255, 255, 0.7);
            text-decoration: underline;
        }

        /* Responsividade aprimorada */
        @media (max-width: 480px) {
            body {
                padding: 15px;
            }
            .login-card {
                padding: 28px 24px;
                border-radius: 14px;
                max-width: 100%;
            }
            .logo {
                max-width: 100px;
                margin-bottom: 16px;
            }
            .login-card h2 {
                font-size: 1.8em;
                margin-bottom: 6px;
            }
            .login-card p.subtitle {
                font-size: 0.85em;
                margin-bottom: 24px;
            }
            .input-group {
                margin-bottom: 18px;
            }
            .input-group input {
                padding: 12px 14px;
                padding-left: 50px;
                font-size: 0.9em;
            }
            .input-group.no-prefix input {
                padding-left: 14px;
            }
            .input-group .prefix {
                left: 14px;
                font-size: 0.9em;
            }
            .input-group label {
                left: 50px;
                font-size: 0.85em;
            }
            .input-group.no-prefix label {
                left: 14px;
            }
            .input-group input:focus + label,
            .input-group input:not(:placeholder-shown) + label {
                left: 14px;
                font-size: 0.7em;
            }
            .login-button {
                padding: 12px 20px;
                font-size: 1em;
                margin-top: 20px;
            }
            .links {
                margin-top: 20px;
                font-size: 0.85em;
                gap: 16px;
            }
        }

        @media (max-width: 360px) {
            .login-card {
                padding: 24px 20px;
            }
            .login-card h2 {
                font-size: 1.6em;
            }
            .links {
                flex-direction: column;
                gap: 12px;
            }
        }
    </style>
</head>
<body>

    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="login-card">
        <img src="/logo/logo.png" class="logo" alt="Logo">
        <h2>Olá Novamente!</h2>
        <p class="subtitle">Faça login para acessar sua conta.</p>

        <form id="loginForm">
            <div class="input-group phone-input">
                <span class="prefix">+55</span>
                <input type="text" id="mobile" name="mobile" placeholder=" " required inputmode="numeric" pattern="[0-9]*" maxlength="11">
                <label for="mobile">Celular</label>
            </div>
            <div class="input-group no-prefix">
                <input type="password" id="password" name="password" placeholder=" " required>
                <label for="password">Senha</label>
            </div>
            <button type="submit" class="login-button">Entrar</button>
        </form>

        <div class="links">
            <a href="forgot_password">Esqueci a Senha?</a>
            <a href="reg">Criar Nova Conta</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function (event) {
            event.preventDefault();

            const mobile = document.getElementById('mobile').value;
            const password = document.getElementById('password').value;

            if (!mobile || !password) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Atenção!',
                    text: 'Por favor, preencha seu celular e senha.',
                    position: 'center',
                    showConfirmButton: false,
                    timer: 2000
                });
                return;
            }

            if (mobile.length < 8 || mobile.length > 11 || !/^\d+$/.test(mobile)) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Formato Inválido',
                    text: 'Por favor, insira um número de celular válido (8 a 11 dígitos, somente números).',
                    position: 'center',
                    showConfirmButton: false,
                    timer: 3000
                });
                return;
            }

            const xhr = new XMLHttpRequest();
            const url = 'servidor/login.php';

            xhr.open('POST', url, true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

            const formData = `mobile=${encodeURIComponent(mobile)}&password=${encodeURIComponent(password)}`;

            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        const response = xhr.responseText;

                        if (response === "Login bem-sucedido!") {
                            Swal.fire({
                                icon: 'success',
                                title: 'Login Efetuado!',
                                text: 'Redirecionando...',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                window.location.href = '/';
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Falha no Login!',
                                text: response,
                                position: 'center',
                                showConfirmButton: false,
                                timer: 3000
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro de Conexão!',
                            text: `Não foi possível conectar ao servidor. Status: ${xhr.status} - ${xhr.statusText}. Por favor, tente novamente.`,
                            position: 'center',
                            showConfirmButton: false,
                            timer: 4000
                        });
                        console.error('AJAX Error:', xhr.status, xhr.status, xhr.responseText);
                    }
                }
            };

            xhr.send(formData);
        });

        document.querySelectorAll('.input-group input').forEach(input => {
            input.addEventListener('focus', () => {
                input.parentNode.classList.add('focused');
            });
            input.addEventListener('blur', () => {
                if (input.value === '') {
                    input.parentNode.classList.remove('focused');
                }
            });
            if (input.value !== '') {
                input.parentNode.classList.add('focused');
            }
        });
    </script>

</body>
</html>