<?php
session_start();
include('servidor/atualizar_rendimento.php');
include('servidor/infor.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php';

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Contato</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&display=swap" rel="stylesheet">
    <style>
        /* Reset Básico */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif; /* Consistente com a página "Dispositivo" */
        }

        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            /* Fundo da Heineken */
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow-x: hidden;
            position: relative;
        }

        /* Ocultar Scrollbar */
        ::-webkit-scrollbar {
            width: 0px;
            background: transparent;
        }
        body {
            -ms-overflow-style: none; /* IE e Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* Efeitos de fundo (bolhas/formas) */
        .background-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            pointer-events: none;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* Container principal (o .device original) */
        .main-container {
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 100px; /* Espaço para a tabbar */
            background: rgba(255, 255, 255, 0.1); /* Efeito Glassmorphism */
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding-top: 0;
        }

        /* Cabeçalho da página de Contato */
        .header {
            padding: 50px 17px 20px;
            background: rgba(255, 255, 255, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 20;
        }

        .header .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            width: 24px; /* Tamanho do ícone */
            height: 24px;
            margin-right: 15px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3)); /* Seta branca brilhante */
        }

        .header-title {
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            font-size: 26px;
            font-weight: 800;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* Seção de Título Principal */
        .contact-hero {
            padding: 40px 17px 30px;
            text-align: center;
            color: #fff;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            animation: fadeInDown 0.8s ease-out forwards;
            opacity: 0;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .contact-hero h1 {
            font-family: 'Montserrat', sans-serif;
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .contact-hero p {
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            line-height: 1.5;
            margin-bottom: 20px;
            color: rgba(255, 255, 255, 0.9);
        }

        .contact-hero .info-box {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 10px;
            padding: 12px 20px;
            font-family: 'Poppins', sans-serif;
            font-size: 15px;
            color: #FFD700; /* Dourado */
            font-weight: 600;
            display: inline-block;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            animation: zoomIn 0.6s ease-out forwards;
            animation-delay: 0.3s;
            opacity: 0;
        }
        @keyframes zoomIn {
            from { opacity: 0; transform: scale(0.8); }
            to { opacity: 1; transform: scale(1); }
        }

        /* Lista de Contato */
        .contact-list-section {
            padding: 17px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px 20px 0 0;
            margin-top: 20px;
            padding-top: 30px;
            box-shadow: 0 -5px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 255, 255, 0.2);
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.6s;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .contact-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px;
            margin-bottom: 15px;
            border-radius: 15px;
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            animation: fadeInUpSmooth 0.9s ease-out forwards;
            opacity: 0;
        }

        .contact-item:nth-child(1) { animation-delay: 0.8s; }
        .contact-item:nth-child(2) { animation-delay: 1.0s; }
        /* Adicione mais se tiver mais itens de contato */

        @keyframes fadeInUpSmooth {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .contact-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }

        .contact-item .icon-wrapper {
            margin-right: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .contact-item .icon-wrapper img {
            width: 45px; /* Ícone um pouco maior */
            height: 45px;
            filter: drop-shadow(0 0 5px rgba(0,0,0,0.2));
        }

        .contact-item .text-content {
            flex: 1;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }

        .contact-item .text-content .title {
            font-family: 'Poppins', sans-serif;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .contact-item .text-content .description {
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            color: rgba(255, 255, 255, 0.8);
        }

        .contact-item .arrow-right {
            width: 16px;
            height: 16px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3)); /* Seta branca brilhante */
            margin-left: 10px;
        }

        /* Tabbar (ajustado para o novo design) */
        .tabbar {
            position: fixed;
            bottom: 0;
            width: 100%;
            max-width: 750px;
            left: 50%;
            transform: translateX(-50%);
            background: #0A4A3C;
            box-shadow: 0 -8px 25px rgba(0, 0, 0, 0.4);
            z-index: 20;
            border-top-left-radius: 30px;
            border-top-right-radius: 30px;
            overflow: hidden;
            border-top: 2px solid #17706E;
            padding: 10px 0;
            box-sizing: content-box;
        }
        
        .tabbar-nav {
            display: flex;
            justify-content: space-around;
            width: 100%;
            margin: 0;
            padding: 0;
        }
        
        .tab-item {
            flex: 1;
            text-align: center;
            padding: 8px 0;
            cursor: pointer;
            transition: transform 0.2s ease, color 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .tab-item:hover {
            transform: translateY(-5px);
        }
        
        .tab-icon {
            width: 32px;
            height: 32px;
            filter: grayscale(50%) brightness(1.2) opacity(0.8);
            transition: filter 0.3s ease, transform 0.2s ease;
        }
        .tab-active .tab-icon {
            filter: grayscale(0%) brightness(1) opacity(1);
            transform: scale(1.1);
        }
        
        .tab-text {
            font-size: 13px;
            margin-top: 4px;
            color: rgba(255, 255, 255, 0.7);
            font-weight: 500;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }
        
        .tab-active .tab-text {
            color: #FFD700;
            font-weight: 700;
            text-shadow: 0 0 8px rgba(255, 255, 255, 0.5);
        }
        
        /* Utilitários Uni-app (mantidos para compatibilidade, mas os divs e imgs substituem uni-view/uni-image para estilização direta) */
        uni-view {
            display: block; /* Garante que uni-view se comporte como um div */
        }
        uni-image {
            display: inline-block; /* Permite controlar a imagem */
            width: 100%;
            height: 100%;
        }
        uni-image > div { /* Estilo do background-image para uni-image */
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
        }

        /* Responsividade */
        @media (max-width: 500px) {
            .main-container {
                border-radius: 0;
                box-shadow: none;
                padding-bottom: 100px;
            }
            .header {
                padding: 40px 15px 15px;
            }
            .header-title {
                font-size: 24px;
            }
            .contact-hero h1 {
                font-size: 24px;
            }
            .contact-hero p {
                font-size: 14px;
            }
            .contact-hero .info-box {
                font-size: 14px;
                padding: 10px 15px;
            }
            .contact-list-section {
                padding: 15px;
                border-radius: 0;
                margin-top: 15px;
                padding-top: 25px;
            }
            .contact-item {
                padding: 15px;
                margin-bottom: 10px;
            }
            .contact-item .icon-wrapper img {
                width: 40px;
                height: 40px;
            }
            .contact-item .text-content .title {
                font-size: 16px;
            }
            .contact-item .text-content .description {
                font-size: 12px;
            }
            .tabbar {
                border-top-left-radius: 0;
                border-top-right-radius: 0;
            }
        }
    </style>
</head>
<body class="uni-body pages-sys-user-cotactUs" style="overflow: visible;">
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="main-container">
        <div class="header">
            <div class="back-button" onclick="window.history.back()">
                <img src="static/yunta/image/device/left.png" alt="Voltar">
            </div>
            <div class="header-title">Contato</div>
        </div>
        
        <div class="contact-hero">
            <h1>Tem alguma pergunta? Encontre-nos</h1>
            <p>Horário de atendimento: 09:00-18:00</p>
            <div class="info-box">Uma variedade de maneiras de orientar sua riqueza</div>
        </div>
        
        <div class="contact-list-section">
            <div class="contact-item" onclick="window.open('<?php echo configuracao('1','telegram'); ?>', '_blank'); return false;">
                <div class="icon-wrapper">
                    <img src="static/yunta/image/user/group.png" alt="Telegram">
                </div>
                <div class="text-content">
                    <div class="title">Telegram</div>
                    <div class="description">Clique para entrar em contato conosco</div>
                </div>
                <img src="static/yunta/image/device/d-2.png" class="arrow-right" alt="Seta">
            </div>
            </div>
    </div>

    <?php include 'tabbar.php'; // Inclui o arquivo da tabbar aqui ?>

</body>
</html>