<?php
session_start();
include('servidor/infor.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php';

// Dados da Equipe (mantidos no PHP, mas o cartão principal será substituído)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$currentUrl = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$codigoConvite = usuario($_SESSION['user_id'], 'codigo_convite');
$newUrl = $protocol . $_SERVER['HTTP_HOST'] . '/reg?code=' . urlencode($codigoConvite);

try {
    $stmt = $pdo->query("SELECT * FROM configuracoes ORDER BY id ASC LIMIT 1");
    $configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);

    $comissaoLv1 = $configuracoes['lv1'];
    $comissaoLv2 = $configuracoes['lv2'];
    $comissaoLv3 = $configuracoes['lv3'];

    function countUsersBySponsor($pdo, $sponsorId) {
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE id_patrocinador = :id_patrocinador");
        $stmt->bindParam(':id_patrocinador', $sponsorId, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    $firstLevel = countUsersBySponsor($pdo, $_SESSION['user_id']);
    
    $secondLevel = [];
    foreach ($firstLevel as $userId) {
        $secondLevel = array_merge($secondLevel, countUsersBySponsor($pdo, $userId));
    }
    
    $thirdLevel = [];
    foreach ($secondLevel as $userId) {
        $thirdLevel = array_merge($thirdLevel, countUsersBySponsor($pdo, $userId));
    }
    
    $totalTeam = count($firstLevel) + count($secondLevel) + count($thirdLevel);

} catch (PDOException $e) {
    error_log("Erro na conexão (equipe): " . $e->getMessage());    
    $totalTeam = 0;    
    $firstLevel = [];
    $secondLevel = [];
    $thirdLevel = [];
}

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Equipe</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&family=Orbitron:wght@400;500;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <link rel="stylesheet" href="mytabbar.css">
    
    <style>
        /* Reset e configurações básicas */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #fff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        ::-webkit-scrollbar {
            display: none;
        }

        /* Efeitos de fundo futuristas */
        .cyber-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 30px 30px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(30px, 30px); }
        }

        .floating-particles {
            position: fixed;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: radial-gradient(circle, rgba(255,215,0,0.8), transparent);
            border-radius: 50%;
            animation: floatParticle linear infinite;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(-50px);
                opacity: 0;
            }
        }

        /* Loading Spinner Sofisticado */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.8s ease, visibility 0.8s ease;
        }

        .loading-overlay.hidden {
            opacity: 0;
            visibility: hidden;
        }

        .futuristic-spinner {
            position: relative;
            width: 120px;
            height: 120px;
        }

        .spinner-ring {
            position: absolute;
            border: 2px solid transparent;
            border-radius: 50%;
            animation: spinRotate 2s linear infinite;
        }

        .spinner-ring:nth-child(1) {
            width: 120px;
            height: 120px;
            border-top: 2px solid #FFD700;
            border-right: 2px solid #FFD700;
            animation-duration: 1.5s;
        }

        .spinner-ring:nth-child(2) {
            width: 90px;
            height: 90px;
            border-bottom: 2px solid #FFA500;
            border-left: 2px solid #FFA500;
            top: 15px;
            left: 15px;
            animation-direction: reverse;
            animation-duration: 2s;
        }

        .spinner-ring:nth-child(3) {
            width: 60px;
            height: 60px;
            border-top: 2px solid #17706E;
            border-right: 2px solid #17706E;
            top: 30px;
            left: 30px;
            animation-duration: 1.2s;
        }

        .spinner-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #FFD700, #FFA500);
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes spinRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
            50% { transform: translate(-50%, -50%) scale(1.5); opacity: 0.7; }
        }

        /* Container Principal */
        .main-container {
            position: relative;
            z-index: 10;
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 120px;
        }

        /* Header Futurista */
        .cyber-header {
            position: relative;
            padding: 60px 20px 30px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.1) 0%,
                rgba(255,255,255,0.05) 50%,
                rgba(255,255,255,0.1) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,215,0,0.3);
            margin-bottom: 30px;
        }

        .cyber-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            animation: scanLine 3s ease-in-out infinite;
        }

        @keyframes scanLine {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand-logo {
            font-family: 'Orbitron', monospace;
            font-size: 28px;
            font-weight: 900;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            text-shadow: 0 0 20px rgba(255,215,0,0.5);
        }

        .brand-logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 2px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
        }

        .action-btn {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,215,0,0.2);
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,215,0,0.2), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.3);
            border-color: rgba(255,215,0,0.5);
        }

        .action-btn img {
            width: 24px;
            height: 24px;
            filter: brightness(1.2) drop-shadow(0 0 5px rgba(255,215,0,0.3));
            z-index: 1;
        }

        /* Products Section */
        .products-section {
            margin: 0 20px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.08) 0%,
                rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(15px);
            border-radius: 25px 25px 0 0;
            border: 1px solid rgba(255,215,0,0.15);
            padding: 30px 25px 25px;
            box-shadow: 0 -5px 20px rgba(0,0,0,0.2);
            animation: slideInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        @keyframes slideInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .products-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(255,215,0,0.2);
        }

        .products-title-section {
            flex: 1;
        }

        .products-main-title {
            font-family: 'Orbitron', monospace;
            font-size: 24px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
            margin-bottom: 5px;
        }

        .products-subtitle {
            font-size: 14px;
            color: rgba(255,255,255,0.7);
        }

        .products-icon {
            width: 60px;
            height: 60px;
            filter: brightness(1.2) drop-shadow(0 0 10px rgba(255,215,0,0.3));
        }

        /* Product Cards */
        .product-card {
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.06) 0%,
                rgba(255,255,255,0.02) 100%);
            backdrop-filter: blur(10px);
            border-radius: 18px;
            border: 1px solid rgba(255,215,0,0.1);
            margin-bottom: 20px;
            padding: 20px;
            transition: all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            position: relative;
            overflow: hidden;
            animation: fadeInUp 0.6s ease-out forwards;
            opacity: 0;
        }

        .product-card:nth-child(1) { animation-delay: 0.1s; }
        .product-card:nth-child(2) { animation-delay: 0.2s; }
        .product-card:nth-child(3) { animation-delay: 0.3s; }
        .product-card:nth-child(4) { animation-delay: 0.4s; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .product-card:hover {
            transform: translateY(-5px) scale(1.02);
            border-color: rgba(255,215,0,0.3);
            box-shadow: 0 15px 35px rgba(255,215,0,0.1);
        }

        .product-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .product-card:hover::before {
            opacity: 1;
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.08);
            transition: all 0.3s ease;
        }

        .info-row:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .info-row:first-child {
            padding-top: 0;
        }

        .info-label {
            font-size: 14px;
            color: rgba(255,255,255,0.8);
            font-weight: 500;
            min-width: 140px;
        }

        .info-value {
            font-size: 15px;
            font-weight: 600;
            color: #FFD700;
            text-shadow: 0 0 10px rgba(255,215,0,0.3);
            text-align: right;
            flex: 1;
        }

        .info-value.status {
            color: #27ae60;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 8px;
        }

        .info-value.status::before {
            content: "●";
            color: #27ae60;
            font-size: 12px;
            animation: pulse-status 2s ease-in-out infinite;
        }

        @keyframes pulse-status {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        .info-value.status.finalizado {
            color: #e74c3c;
        }

        .info-value.status.finalizado::before {
            content: "●";
            color: #e74c3c;
            animation: none;
        }

        .cronometro {
            font-family: 'Orbitron', monospace;
            font-weight: 700;
            color: #00ff88;
            text-shadow: 0 0 15px rgba(0,255,136,0.4);
            font-size: 16px;
        }

        /* No Products State */
        .no-products {
            text-align: center;
            padding: 60px 20px;
            color: rgba(255,255,255,0.7);
        }

        .no-products-icon {
            width: 120px;
            height: 120px;
            opacity: 0.6;
            filter: brightness(1.2) drop-shadow(0 0 10px rgba(255,215,0,0.2));
            margin-bottom: 20px;
        }

        .no-products-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 10px;
        }

        .no-products-subtext {
            font-size: 14px;
            color: rgba(255,255,255,0.5);
        }

        /* Loading State */
        .loading-products {
            text-align: center;
            padding: 40px 20px;
            color: rgba(255,255,255,0.8);
        }

        .loading-products-text {
            font-size: 16px;
            margin-bottom: 20px;
        }

        .mini-spinner {
            width: 40px;
            height: 40px;
            border: 3px solid rgba(255,215,0,0.3);
            border-top: 3px solid #FFD700;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .main-container {
                padding-bottom: 140px;
            }
            
            .cyber-header {
                padding: 50px 15px 25px;
            }
            
            .brand-logo {
                font-size: 22px;
            }
            
            .header-actions {
                gap: 10px;
            }
            
            .action-btn {
                width: 40px;
                height: 40px;
            }
            
            .action-btn img {
                width: 20px;
                height: 20px;
            }
            
            .products-section {
                margin: 0 15px;
                padding: 25px 20px;
                border-radius: 20px 20px 0 0;
            }
            
            .products-main-title {
                font-size: 20px;
            }
            
            .products-icon {
                width: 50px;
                height: 50px;
            }
            
            .product-card {
                padding: 18px;
                margin-bottom: 15px;
            }
            
            .info-row {
                padding: 10px 0;
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
            
            .info-label {
                font-size: 13px;
                min-width: auto;
            }
            
            .info-value {
                font-size: 14px;
                text-align: left;
                align-self: flex-end;
            }
            
            .cronometro {
                font-size: 15px;
            }
        }

        @media (max-width: 480px) {
            .products-header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .info-row {
                padding: 8px 0;
            }
            
            .product-card {
                padding: 15px;
            }
        }

        /* Micro animações */
        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
        }

        .glitch-effect:hover {
            animation: glitch 0.3s;
        }
    </style>
</head>

<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="futuristic-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-center"></div>
        </div>
    </div>

    <!-- Background Effects -->
    <div class="cyber-grid"></div>
    <div class="floating-particles" id="particles"></div>

    <!-- Main Container -->
    <div class="main-container" id="mainContent" style="opacity: 0;">
        <!-- Header -->
        <div class="cyber-header">
            <div class="header-content">
                <div class="brand-logo glitch-effect">Registro</div>
                <div class="header-actions">
                    <div class="action-btn" onclick="alert('Funcionalidade de mensagem em breve!');">
                        <img src="static/yunta/image/home/msg.png" alt="Messages">
                    </div>
                    <div class="action-btn" onclick="window.location.href='/cotactUs'">
                        <img src="static/yunta/image/home/service.png" alt="Service">
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Products Section -->
        <div class="products-section">
            <div class="products-header">
                <div class="products-title-section">
                    <div class="products-main-title">Meus Produtos</div>
                    <div class="products-subtitle">Seus investimentos ativos e histórico</div>
                </div>
                <img src="static/yunta/image/device/d-3.png" class="products-icon" alt="Products" draggable="false">
            </div>
            
            <div id="compras-content">
                <div class="loading-products">
                    <div class="loading-products-text">Carregando seus produtos...</div>
                    <div class="mini-spinner"></div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'tabbar.php'; ?>

    <script>
        // Loading Animation
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('loadingOverlay').classList.add('hidden');
                document.getElementById('mainContent').style.opacity = '1';
                document.getElementById('mainContent').style.transition = 'opacity 1s ease';
            }, 1200);
        });

        // Create floating particles
        function createParticles() {
            const particleContainer = document.getElementById('particles');
            const particleCount = 12;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 8 + 4) + 's';
                particle.style.animationDelay = Math.random() * 4 + 's';
                particleContainer.appendChild(particle);
            }
        }

        createParticles();

        // Função para copiar link de convite (mantida por compatibilidade)
        function copyInviteLink() {
            var copyText = document.getElementById("inviteLink");
            if (copyText) {
                copyText.select();
                copyText.setSelectionRange(0, 99999);
                document.execCommand("copy");
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso',
                    text: "Link de convite copiado!",
                    position: 'center',
                    showConfirmButton: false,
                    timer: 2000,
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                    color: '#fff'
                });
            } else {
                console.warn("Elemento #inviteLink não encontrado para copiar.");
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            const apiUrl = 'servidor/buys.php';
            
            // Armazena os IDs dos intervalos para que possamos limpá-los
            const intervalosTimers = {};

            function fetchCompras() {
                fetch(apiUrl)
                    .then(response => response.json())
                    .then(data => {
                        console.log("Dados recebidos do buys.php:", data);
                        const comprasContainer = document.getElementById('compras-content');
                        let html = '';

                        // Limpa todos os timers existentes antes de recriá-los
                        for (const id in intervalosTimers) {
                            clearInterval(intervalosTimers[id]);
                        }
                        Object.keys(intervalosTimers).forEach(id => delete intervalosTimers[id]);

                        if (data.length === 0) {
                            html += `
                                <div class="no-products">
                                    <img src="static/yunta/image/device/no-Order.png" class="no-products-icon" draggable="false" alt="No products">
                                    <div class="no-products-text">Nenhum investimento encontrado</div>
                                    <div class="no-products-subtext">Seus produtos aparecerão aqui quando você fizer seu primeiro investimento</div>
                                </div>`;
                        } else {
                            data.forEach((compra, index) => {
                                const nomePlano = compra.nome_plano || 'N/A';
                                const valorInvestido = parseFloat(compra.valor_investido || 0).toFixed(2).replace('.', ',');
                                const rendaDiaria = parseFloat(compra.renda_diaria || 0).toFixed(2).replace('.', ',');
                                const rendaTotalPrevista = parseFloat(compra.renda_total_prevista || 0).toFixed(2).replace('.', ',');
                                const dataCompra = compra.data_compra ? new Date(compra.data_compra).toLocaleDateString('pt-BR') : 'N/A';
                                const dataVencimento = compra.vencimento ? new Date(compra.vencimento).toLocaleDateString('pt-BR') : 'N/A';
                                const status = compra.status || 'Desconhecido';
                                
                                const statusClass = (status.toLowerCase() === 'finalizado') ? 'finalizado' : '';

                                const proximoRendimentoTimestamp = (status.toLowerCase() === 'rodando' && compra.proximo_rendimento) ? new Date(compra.proximo_rendimento).getTime() : null;

                                html += `
                                    <div class="product-card" style="animation-delay: ${0.1 * (index + 1)}s;"> 
                                        <div class="info-row">
                                            <span class="info-label">Produto:</span>
                                            <span class="info-value">${nomePlano}</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label">Valor Investido:</span>
                                            <span class="info-value">R$${valorInvestido}</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label">Renda Diária:</span>
                                            <span class="info-value">R$${rendaDiaria}</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label">Renda Total:</span>
                                            <span class="info-value">R$${rendaTotalPrevista}</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label">Data da Compra:</span>
                                            <span class="info-value">${dataCompra}</span>
                                        </div>
                                        <div class="info-row">
                                            <span class="info-label">Vencimento:</span>
                                            <span class="info-value">${dataVencimento}</span>
                                        </div>
                                        ${proximoRendimentoTimestamp ? 
                                            `<div class="info-row">
                                                <span class="info-label">Próximo Rendimento:</span>
                                                <span class="info-value cronometro" data-compra-id="${compra.id}" data-target-time="${proximoRendimentoTimestamp}">Calculando...</span>
                                            </div>` : ''
                                        }
                                        <div class="info-row">
                                            <span class="info-label">Status:</span>
                                            <span class="info-value status ${statusClass}">${status}</span>
                                        </div>
                                    </div>`;
                            });
                        }
                        comprasContainer.innerHTML = html;

                        if (data.length > 0) {
                            updateTimersAndStartLoops();
                        }
                    })
                    .catch(error => {
                        console.error('Erro geral na requisição de produtos:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: 'Falha ao carregar seus produtos. Por favor, tente novamente mais tarde.',
                            confirmButtonText: 'Ok',
                            background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                            color: '#fff'
                        });
                        document.getElementById('compras-content').innerHTML = `
                            <div class="no-products">
                                <img src="static/yunta/image/device/no-Order.png" class="no-products-icon" draggable="false" alt="Error">
                                <div class="no-products-text">Erro ao carregar produtos</div>
                                <div class="no-products-subtext">Tente novamente em alguns instantes</div>
                            </div>`;
                    });
            }

            function updateTimersAndStartLoops() {
                document.querySelectorAll('.cronometro').forEach(timerElement => {
                    const compraId = timerElement.getAttribute('data-compra-id');
                    const updateFunction = () => {
                        const targetTime = parseInt(timerElement.getAttribute('data-target-time'));
                        const now = new Date().getTime();
                        const distance = targetTime - now;

                        if (distance <= 0) {
                            timerElement.innerHTML = "Processando...";
                            clearInterval(intervalosTimers[compraId]);
                            processarRendimento(compraId, timerElement);
                            return;
                        }

                        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

                        timerElement.innerHTML = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                    };

                    // Executa a função imediatamente e depois a cada segundo
                    updateFunction();
                    intervalosTimers[compraId] = setInterval(updateFunction, 1000);
                });
            }

            function processarRendimento(compraId, timerElement) {
                const formData = new FormData();
                formData.append('compra_id', compraId);

                fetch('servidor/processa_rendimentos.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Falha na resposta do servidor.');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        // Não mostra pop-up de sucesso.
                        // O processamento acontece em segundo plano.
                        
                        // Atualiza o tempo do cronômetro para o próximo ciclo
                        timerElement.setAttribute('data-target-time', data.novoProximoRendimento);
                        
                    } else {
                        console.error("Erro do servidor:", data.message);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro',
                            text: data.message,
                            confirmButtonText: 'OK',
                            background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                            color: '#fff'
                        });
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro na Conexão',
                        text: 'Não foi possível se conectar ao servidor.',
                        confirmButtonText: 'OK',
                        background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
                        color: '#fff'
                    });
                });
            }

            // Inicia o carregamento dos produtos
            fetchCompras();
        });
    </script>
</body>
</html>