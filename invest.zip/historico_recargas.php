<?php
session_start();

include('servidor/infor.php');
include('servidor/atualizar_rendimento.php'); // Certifique-se que este arquivo é necessário aqui, se não, pode remover.

if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php'; // Assume que 'database.php' define e retorna a conexão PDO em $pdo

$user_id = $_SESSION['user_id'];
$recargas = [];

try {
    // Usando a tabela e colunas 'depositos' conforme sua estrutura fornecida
    $stmt = $pdo->prepare("SELECT id, user_id, amount, transaction_date, status, descricao 
                            FROM depositos 
                            WHERE user_id = ? 
                            ORDER BY transaction_date DESC");
    $stmt->execute([$user_id]);
    $recargas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Em um ambiente de produção, você logaria o erro e mostraria uma mensagem genérica
    error_log("Erro ao buscar histórico de recargas: " . $e->getMessage());
    // Para depuração, pode exibir o erro (remova em produção):
    // die("Erro ao carregar histórico: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Histórico de Recargas</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* --- Ocultar Scrollbar --- */
        ::-webkit-scrollbar {
            width: 0px;
            background: transparent;
        }
        body {
            -ms-overflow-style: none; /* IE e Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* --- Basic Reset & Body Styles --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%); /* Heineken Green */
            color: #333;
            overflow-x: hidden;
            position: relative;
            padding-bottom: 0;
        }

        /* --- Background Shapes (consistent) --- */
        .background-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            pointer-events: none;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* --- Main Container --- */
        .main-container {
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 30px;
            background: rgba(255, 255, 255, 0.1); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding-top: 0;
            display: flex;
            flex-direction: column;
        }

        /* --- Header --- */
        .header {
            padding: 50px 17px 20px;
            background: rgba(255, 255, 255, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 20;
            /* Usar justify-content para espaçar, pois não tem botão aqui */
            justify-content: flex-start; /* Alinha o conteúdo à esquerda, para que o título fique ao lado do botão de voltar */
        }

        .header .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            width: 24px;
            height: 24px;
            margin-right: 15px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3));
        }

        .header-title {
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            font-size: 26px;
            font-weight: 800;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
            flex-grow: 1; /* Permite que o título ocupe o espaço restante */
            text-align: left; /* Alinha o texto do título à esquerda */
        }

        /* --- Histórico de Recargas Content --- */
        .history-content {
            padding: 20px;
            color: #fff;
            flex-grow: 1; /* Permite que o conteúdo ocupe o espaço restante */
        }

        .history-content h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 28px;
            font-weight: 800;
            text-align: center;
            margin-bottom: 30px;
            color: #FFD700; /* Gold */
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.4);
        }

        .no-records {
            text-align: center;
            font-size: 18px;
            color: rgba(255, 255, 255, 0.7);
            padding: 50px 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 15px;
            margin: 20px auto;
            width: calc(100% - 40px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .recharge-item {
            background: rgba(255, 255, 255, 0.15);
            border-radius: 15px;
            padding: 15px 20px;
            margin-bottom: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: transform 0.2s ease;
        }

        .recharge-item:hover {
            transform: translateY(-3px);
        }

        .recharge-info {
            flex-grow: 1;
        }

        .recharge-info p {
            margin: 5px 0;
            font-size: 15px;
            color: rgba(255, 255, 255, 0.9);
            text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        }
        .recharge-info strong {
            font-weight: 600;
            color: #FFD700; /* Gold */
        }

        .recharge-amount {
            font-family: 'Montserrat', sans-serif;
            font-weight: 800;
            font-size: 22px;
            margin-left: 20px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }

        /* Status Colors */
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            color: #fff;
            margin-top: 5px; /* Espaço do valor */
        }

        /* Bem-sucedido: Verde (Heineken Green) */
        .status-pago, .status-concluido { /* Supondo 'concluido' também seja sucesso */
            background-color: #4CAF50; /* Um verde mais vibrante para sucesso */
            box-shadow: 0 2px 8px rgba(76, 175, 80, 0.4);
        }

        /* Não Pago/Pendente: Laranja/Amarelo */
        .status-pendente, .status-aguardando {
            background-color: #FFC107; /* Amarelo */
            color: #333; /* Texto escuro para contraste */
            box-shadow: 0 2px 8px rgba(255, 193, 7, 0.4);
        }

        /* Cancelado/Falha: Vermelho */
        .status-cancelada, .status-falha, .status-rejeitado {
            background-color: #F44336; /* Vermelho */
            box-shadow: 0 2px 8px rgba(244, 67, 54, 0.4);
        }
        
        /* Outros status (se houver, como 'processando') */
        .status-processando {
            background-color: #2196F3; /* Azul */
            box-shadow: 0 2px 8px rgba(33, 150, 243, 0.4);
        }

        /* Responsive Adjustments */
        @media (max-width: 500px) {
            .main-container {
                border-radius: 0;
                box-shadow: none;
                padding-bottom: 20px;
            }
            .header {
                padding: 40px 15px 15px;
            }
            .header-title {
                font-size: 24px;
            }
            .history-content {
                padding: 15px;
            }
            .history-content h2 {
                font-size: 24px;
                margin-bottom: 20px;
            }
            .recharge-item {
                flex-direction: column; /* Empilha informações verticalmente em telas pequenas */
                align-items: flex-start;
                padding: 12px 15px;
            }
            .recharge-info {
                width: 100%;
                margin-bottom: 10px;
            }
            .recharge-amount {
                margin-left: 0;
                align-self: flex-end; /* Alinha o valor à direita na parte inferior */
                font-size: 20px;
            }
            .status-badge {
                align-self: flex-start;
                margin-top: 0;
            }
        }
    </style>
</head>
<body>
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="main-container">
        <div class="header">
            <div class="back-button" onclick="window.history.back()">
                <img src="static/yunta/image/device/left.png" alt="Voltar">
            </div>
            <div class="header-content">
                <div class="header-title">Histórico de Recargas</div>
            </div>
        </div>

        <div class="history-content">
            <h2>Minhas Recargas</h2>
            <?php if (empty($recargas)): ?>
                <div class="no-records">Nenhuma recarga encontrada ainda.</div>
            <?php else: ?>
                <?php foreach ($recargas as $recarga): 
                    $status_class = '';
                    // Usando os status da sua tabela 'depositos'
                    switch (strtolower($recarga['status'])) { 
                        case 'pago':
                            $status_class = 'status-pago';
                            break;
                        case 'pendente':
                            $status_class = 'status-pendente';
                            break;
                        // Adicione outros casos se tiver mais status como 'falha', 'cancelada', 'processando'
                        default:
                            $status_class = 'status-pendente'; // Default para não pago ou desconhecido
                            break;
                    }
                ?>
                    <div class="recharge-item">
                        <div class="recharge-info">
                            <p><strong>ID da Recarga:</strong> <?= htmlspecialchars($recarga['id']) ?></p>
                            <p><strong>Descrição:</strong> <?= htmlspecialchars($recarga['descricao'] ?? 'N/A') ?></p>
                            <p><strong>Data:</strong> <?= htmlspecialchars(date('d/m/Y H:i', strtotime($recarga['transaction_date']))) ?></p>
                            <span class="status-badge <?= $status_class ?>"><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $recarga['status']))) ?></span>
                        </div>
                        <div class="recharge-amount">
                            R$<?= htmlspecialchars(number_format($recarga['amount'], 2, ',', '.')) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>