<?php
session_start();
include('servidor/infor.php');
include('servidor/atualizar_rendimento.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login");
    exit();
}

require 'servidor/database.php';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username_db, $password_db);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $pdo->query("SELECT * FROM planos");
    $planos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

// Buscar configurações do banco de dados
$configs = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM configuracoes LIMIT 1");
    $stmt->execute();
    $configs = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Se não conseguir buscar, usa valores padrão
    $configs = [];
}

// Função auxiliar para obter configuração
function getConfig($field, $default = '') {
    global $configs;
    return (!empty($configs[$field])) ? $configs[$field] : $default;
}

// Carregar configurações com valores padrão
$site_name = getConfig('site_name', 'fany-ai');
$site_title = getConfig('site_title', 'fany-ai plataform premium investiment oficial');
$banner_image = getConfig('banner_image', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZuUfV_bkS6-CX7poJDZUspb6tMDShVV1qimsYCRom9GpNvN1rbaeuklov&s=10');
$favicon = getConfig('favicon', 'static/yunta/favicon.png');

// Textos configuráveis
$checkin_title = getConfig('checkin_title', 'Login Diário Premium');
$checkin_subtitle = getConfig('checkin_subtitle', 'Ganhe R$ 1,00 por check-in diário');
$checkin_button = getConfig('checkin_button', 'Entrar');

// Mensagens do ticker
$ticker_message_1 = getConfig('ticker_message_1', 'Bem-vindo ao futuro dos investimentos com fany-ai');
$ticker_message_2 = getConfig('ticker_message_2', 'Novos planos disponíveis');
$ticker_message_3 = getConfig('ticker_message_3', 'Ganhe bônus incríveis');

// Modal de anúncio
$modal_title = getConfig('modal_title', 'O que a fany-ai oferece?');
$modal_welcome = getConfig('modal_welcome', '✨ Bem-vindo à fany-ai');
$modal_bonus_register = getConfig('modal_bonus_register', '💰 Cadastre-se com sucesso e ganhe 5 R$');
$modal_daily_login = getConfig('modal_daily_login', '🎯 Entre e faça login diariamente para receber 1 R$');
$modal_commission = getConfig('modal_commission', '🚀 31% de comissão de bônus alto está esperando por você');
$modal_telegram = getConfig('modal_telegram', '📱 Siga o canal oficial no Telegram para últimas informações');

// Checkin Modal
$checkin_success_title = getConfig('checkin_success_title', '✅ Check-in Realizado');
$checkin_success_message = getConfig('checkin_success_message', 'Você recebeu R$ 1,00 de bônus diário!');

// URL do Telegram
$telegram_url = getConfig('telegram', 'https://t.me/seu_canal_telegram');

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <title><?php echo htmlspecialchars($site_title, ENT_QUOTES, 'UTF-8'); ?></title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo htmlspecialchars($favicon, ENT_QUOTES, 'UTF-8'); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&family=Orbitron:wght@400;500;700;900&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="mytabbar.css">
    
    <style>
        /* Reset e configurações básicas */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #fff;
            overflow-x: hidden;
            position: relative;
            min-height: 100vh;
        }

        /* Efeitos de fundo futuristas */
        .cyber-grid {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: 
                linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px);
            background-size: 30px 30px;
            pointer-events: none;
            z-index: 0;
            animation: gridMove 20s linear infinite;
        }

        @keyframes gridMove {
            0% { transform: translate(0, 0); }
            100% { transform: translate(30px, 30px); }
        }

        .floating-particles {
            position: fixed;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
        }

        .particle {
            position: absolute;
            width: 3px;
            height: 3px;
            background: radial-gradient(circle, rgba(255,215,0,0.8), transparent);
            border-radius: 50%;
            animation: floatParticle linear infinite;
        }

        @keyframes floatParticle {
            0% {
                transform: translateY(100vh) translateX(0px);
                opacity: 0;
            }
            10% {
                opacity: 1;
            }
            90% {
                opacity: 1;
            }
            100% {
                transform: translateY(-100px) translateX(-50px);
                opacity: 0;
            }
        }

        /* Loading Spinner Sofisticado */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.8s ease, visibility 0.8s ease;
        }

        .loading-overlay.hidden {
            opacity: 0;
            visibility: hidden;
        }

        .futuristic-spinner {
            position: relative;
            width: 120px;
            height: 120px;
        }

        .spinner-ring {
            position: absolute;
            border: 2px solid transparent;
            border-radius: 50%;
            animation: spinRotate 2s linear infinite;
        }

        .spinner-ring:nth-child(1) {
            width: 120px;
            height: 120px;
            border-top: 2px solid #FFD700;
            border-right: 2px solid #FFD700;
            animation-duration: 1.5s;
        }

        .spinner-ring:nth-child(2) {
            width: 90px;
            height: 90px;
            border-bottom: 2px solid #FFA500;
            border-left: 2px solid #FFA500;
            top: 15px;
            left: 15px;
            animation-direction: reverse;
            animation-duration: 2s;
        }

        .spinner-ring:nth-child(3) {
            width: 60px;
            height: 60px;
            border-top: 2px solid #17706E;
            border-right: 2px solid #17706E;
            top: 30px;
            left: 30px;
            animation-duration: 1.2s;
        }

        .spinner-center {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            background: radial-gradient(circle, #FFD700, #FFA500);
            border-radius: 50%;
            animation: pulse 1.5s ease-in-out infinite;
        }

        @keyframes spinRotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes pulse {
            0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
            50% { transform: translate(-50%, -50%) scale(1.5); opacity: 0.7; }
        }

        /* Container Principal */
        .main-container {
            position: relative;
            z-index: 10;
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 100px;
        }

        /* Header Futurista */
        .cyber-header {
            position: relative;
            padding: 60px 20px 30px;
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.1) 0%,
                rgba(255,255,255,0.05) 50%,
                rgba(255,255,255,0.1) 100%);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255,215,0,0.3);
            margin-bottom: 30px;
        }

        .cyber-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            animation: scanLine 3s ease-in-out infinite;
        }

        @keyframes scanLine {
            0%, 100% { opacity: 0; }
            50% { opacity: 1; }
        }

        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .brand-logo {
            font-family: 'Orbitron', monospace;
            font-size: 28px;
            font-weight: 900;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            text-shadow: 0 0 20px rgba(255,215,0,0.5);
        }

        .brand-logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #FFD700, #FFA500);
            border-radius: 2px;
        }

        .header-actions {
            display: flex;
            gap: 20px;
        }

        .action-btn {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,215,0,0.2);
            position: relative;
            overflow: hidden;
        }

        .action-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,215,0,0.2), transparent);
            transition: left 0.5s ease;
        }

        .action-btn:hover::before {
            left: 100%;
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(255,215,0,0.3);
            border-color: rgba(255,215,0,0.5);
        }

        .action-btn img {
            width: 24px;
            height: 24px;
            filter: brightness(1.2) drop-shadow(0 0 5px rgba(255,215,0,0.3));
            z-index: 1;
        }
        
        /* Modificações no Cartão de Check-in */
        .cyber-checkin {
            margin: 0 20px 30px;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.1);
            padding: 15px;
            position: relative;
            overflow: hidden;
            animation: none;
            transition: all 0.3s ease;
        }

        .cyber-checkin:hover {
            background: rgba(255,255,255,0.08);
        }
        
        .checkin-layout {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .checkin-icon {
            width: 40px;
            height: 40px;
            background: none;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            box-shadow: inset 0 0 5px rgba(255,255,255,0.2);
        }

        .checkin-icon img {
            width: 20px;
            height: 20px;
            filter: brightness(1);
        }

        .checkin-info {
            flex: 1;
        }

        .checkin-title {
            font-size: 16px;
            font-weight: 500;
            color: #ccc;
            margin-bottom: 4px;
            text-shadow: none;
        }

        .checkin-subtitle {
            font-size: 12px;
            color: rgba(255,255,255,0.5);
        }

        .cyber-btn {
            padding: 8px 16px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            color: #fff;
            font-weight: 500;
            font-size: 12px;
            text-transform: none;
            letter-spacing: 0;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .cyber-btn:hover {
            background: rgba(255,255,255,0.2);
            transform: none;
            box-shadow: none;
        }

        /* Banner Futurista - Banner dinâmico do banco */
        .cyber-banner {
            margin: 0 20px 30px;
            height: 200px;
            background: linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05));
            border-radius: 20px;
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(255,215,0,0.2);
            animation: slideInRight 0.8s ease-out;
        }

        @keyframes slideInRight {
            from { opacity: 0; transform: translateX(50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .banner-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('<?php echo htmlspecialchars($banner_image, ENT_QUOTES, 'UTF-8'); ?>');
            background-size: cover;
            background-position: center;
        }

        .banner-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, 
                rgba(10,74,60,0.3) 0%,
                rgba(23,112,110,0.2) 100%);
        }

        .announcement-ticker {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 50px;
            background: linear-gradient(135deg, rgba(0,0,0,0.6), rgba(0,0,0,0.4));
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            overflow: hidden;
        }

        .ticker-content {
            white-space: nowrap;
            animation: tickerScroll 15s linear infinite;
            font-size: 14px;
            font-weight: 500;
            color: #FFD700;
            text-shadow: 0 0 10px rgba(255,215,0,0.5);
        }

        @keyframes tickerScroll {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }

        /* Cards de Produtos Futuristas */
        .products-grid {
            padding: 0 20px;
            display: flex;
            flex-direction: column;
            gap: 25px;
        }

        .product-card {
            background: linear-gradient(135deg, 
                rgba(255,255,255,0.08) 0%,
                rgba(255,255,255,0.03) 100%);
            backdrop-filter: blur(15px);
            border-radius: 24px;
            border: 1px solid rgba(255,215,0,0.15);
            overflow: hidden;
            position: relative;
            transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            animation: fadeInUp 0.8s ease-out forwards;
            opacity: 0;
        }

        .product-card:nth-child(1) { animation-delay: 0.2s; }
        .product-card:nth-child(2) { animation-delay: 0.4s; }
        .product-card:nth-child(3) { animation-delay: 0.6s; }
        .product-card:nth-child(4) { animation-delay: 0.8s; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .product-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #FFD700, transparent);
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .product-card:hover::before {
            opacity: 1;
        }

        .product-card:hover {
            transform: translateY(-10px) scale(1.02);
            border-color: rgba(255,215,0,0.4);
            box-shadow: 
                0 25px 50px rgba(0,0,0,0.3),
                0 0 30px rgba(255,215,0,0.2);
        }

        .product-layout {
            display: flex;
            padding: 0;
        }

        .product-image {
            width: 140px;
            height: 140px;
            object-fit: cover;
            position: relative;
        }

        .product-image::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, 
                rgba(255,215,0,0.1) 0%,
                transparent 50%);
        }

        .product-details {
            flex: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .product-header {
            margin-bottom: 15px;
        }

        .product-price {
            font-family: 'Orbitron', monospace;
            font-size: 24px;
            font-weight: 700;
            color: #FFD700;
            text-shadow: 0 0 15px rgba(255,215,0,0.4);
            margin-bottom: 8px;
        }

        .product-name {
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            text-shadow: 0 0 10px rgba(255,255,255,0.3);
        }

        .product-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 14px;
            font-weight: 600;
            color: #FFD700;
            margin-bottom: 4px;
        }

        .stat-label {
            font-size: 11px;
            color: rgba(255,255,255,0.6);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .purchase-btn {
            background: linear-gradient(135deg, #FFD700, #FFA500);
            color: #333;
            border: none;
            border-radius: 15px;
            padding: 15px;
            font-weight: 700;
            font-size: 14px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: auto;
        }

        .purchase-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            transition: left 0.5s ease;
        }

        .purchase-btn:hover::before {
            left: 100%;
        }

        .purchase-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(255,215,0,0.4);
        }

        /* Modal Futurista - POPUPS SÓLIDOS, NÃO TRANSPARENTES */
        .cyber-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            backdrop-filter: blur(20px);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            pointer-events: none;
            transition: all 0.4s ease;
        }

        .cyber-modal.visible {
            opacity: 1;
            pointer-events: auto;
        }

        .modal-container {
            background: linear-gradient(135deg, 
                #1a1a1a 0%,
                #2d2d2d 100%);
            border-radius: 25px;
            border: 2px solid #FFD700;
            padding: 40px 30px;
            max-width: 400px;
            width: 90%;
            position: relative;
            transform: scale(0.9);
            transition: transform 0.4s ease;
            box-shadow: 0 20px 40px rgba(0,0,0,0.7);
        }

        .cyber-modal.visible .modal-container {
            transform: scale(1);
        }

        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: rgba(255,255,255,0.3);
            transform: rotate(90deg);
        }

        .modal-close::before,
        .modal-close::after {
            content: '';
            position: absolute;
            width: 60%;
            height: 2px;
            background: #fff;
            border-radius: 2px;
        }

        .modal-close::before {
            transform: rotate(45deg);
        }

        .modal-close::after {
            transform: rotate(-45deg);
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .main-container {
                padding-bottom: 120px;
            }
            
            .cyber-header {
                padding: 50px 15px 25px;
            }
            
            .brand-logo {
                font-size: 22px;
            }
            
            .header-actions {
                gap: 15px;
            }
            
            .action-btn {
                width: 45px;
                height: 45px;
            }
            
            .cyber-checkin,
            .cyber-banner,
            .products-grid {
                margin-left: 15px;
                margin-right: 15px;
            }
            
            .product-layout {
                flex-direction: column;
            }
            
            .product-image {
                width: 100%;
                height: 180px;
            }
            
            .product-stats {
                grid-template-columns: repeat(4, 1fr);
                gap: 10px;
            }
        }

        /* Micro animações */
        @keyframes glitch {
            0%, 100% { transform: translate(0); }
            20% { transform: translate(-2px, 2px); }
            40% { transform: translate(-2px, -2px); }
            60% { transform: translate(2px, 2px); }
            80% { transform: translate(2px, -2px); }
        }

        .glitch-effect:hover {
            animation: glitch 0.3s;
        }
    </style>
</head>

<body>
    <div class="loading-overlay" id="loadingOverlay">
        <div class="futuristic-spinner">
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-ring"></div>
            <div class="spinner-center"></div>
        </div>
    </div>

    <div class="cyber-grid"></div>
    <div class="floating-particles" id="particles"></div>

    <div class="main-container" id="mainContent" style="opacity: 0;">
        <div class="cyber-header">
            <div class="header-content">
                <div class="brand-logo glitch-effect"><?php echo htmlspecialchars($site_name, ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="header-actions">
                    <div class="action-btn" onclick="dialogo()">
                        <img src="static/yunta/image/home/msg.png" alt="Messages">
                    </div>
                    <div class="action-btn" onclick="window.location.href='/cotactUs'">
                        <img src="static/yunta/image/home/service.png" alt="Service">
                    </div>
                </div>
            </div>
        </div>
        
        <div class="cyber-checkin">
            <div class="checkin-layout">
                <div class="checkin-icon">
                    <img src="static/yunta/image/home/signin-left.png" alt="Check-in">
                </div>
                <div class="checkin-info">
                    <div class="checkin-title"><?php echo htmlspecialchars($checkin_title, ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="checkin-subtitle"><?php echo htmlspecialchars($checkin_subtitle, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <button class="cyber-btn" onclick="realizarCheckin()">
                    <?php echo htmlspecialchars($checkin_button, ENT_QUOTES, 'UTF-8'); ?>
                </button>
            </div>
        </div>
        
        <div class="cyber-banner">
            <div class="banner-bg"></div>
            <div class="banner-overlay"></div>
            <div class="announcement-ticker">
                <div class="ticker-content" id="tickerContent">
                    <?php echo htmlspecialchars($ticker_message_1, ENT_QUOTES, 'UTF-8'); ?> • <?php echo htmlspecialchars($ticker_message_2, ENT_QUOTES, 'UTF-8'); ?> • <?php echo htmlspecialchars($ticker_message_3, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            </div>
        </div>
        
        <div class="products-grid">
            <?php foreach ($planos as $plano): ?>
            <div class="product-card">
                <div class="product-layout">
                    <img src="<?php echo htmlspecialchars($plano['image_url'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" 
                         class="product-image" 
                         alt="<?php echo htmlspecialchars($plano['nome'] ?? 'Product Image', ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="product-details">
                        <div class="product-header">
                            <div class="product-price">R$<?php echo number_format($plano['preco'], 2, ',', '.'); ?></div>
                            <div class="product-name"><?php echo htmlspecialchars($plano['nome'], ENT_QUOTES, 'UTF-8'); ?></div>
                        </div>
                        
                        <div class="product-stats">
                            <div class="stat-item">
                                <div class="stat-value"><?php echo $plano['diasDeReceita']; ?></div>
                                <div class="stat-label">Dias</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value"><?php echo $plano['limite']; ?></div>
                                <div class="stat-label">Limite</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value">R$<?php echo $plano['receitaDiaria']; ?></div>
                                <div class="stat-label">Por Dia</div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-value">R$<?php echo $plano['receitaTotal']; ?></div>
                                <div class="stat-label">Total</div>
                            </div>
                        </div>
                        
                        <button class="purchase-btn" onclick="buy(<?php echo $plano['id']; ?>)">
                            Adquirir Agora
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div id="announcementModal" class="cyber-modal">
        <div class="modal-container">
            <div class="modal-close" onclick="dialogo()"></div>
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 25px; text-align: center; color: #FFD700;">
                <?php echo htmlspecialchars($modal_title, ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <div style="max-height: 300px; overflow-y: auto; text-align: left; line-height: 1.6;">
                <div style="margin-bottom: 15px;">
                    <div><?php echo htmlspecialchars($modal_welcome, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div style="margin-bottom: 15px;">
                    <div><?php echo htmlspecialchars($modal_bonus_register, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div style="margin-bottom: 15px;">
                    <div><?php echo htmlspecialchars($modal_daily_login, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div style="margin-bottom: 15px;">
                    <div><?php echo htmlspecialchars($modal_commission, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div style="margin-bottom: 15px;">
                    <div><?php echo htmlspecialchars($modal_telegram, ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
            </div>
            <button class="cyber-btn" style="width: 100%; margin-top: 20px;" 
                    onclick="window.open('<?php echo htmlspecialchars($telegram_url, ENT_QUOTES, 'UTF-8'); ?>', '_blank'); return false;">
                Abrir Telegram
            </button>
        </div>
    </div>
    
    <div id="checkinModal" class="cyber-modal">
        <div class="modal-container" style="text-align: center;">
            <div class="modal-close" onclick="dialogo2()"></div>
            <div style="font-size: 24px; font-weight: 700; margin-bottom: 20px; color: #FFD700;">
                <?php echo htmlspecialchars($checkin_success_title, ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <div style="font-size: 18px; margin-bottom: 30px;">
                <?php echo htmlspecialchars($checkin_success_message, ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <button class="cyber-btn" style="width: 100%;" onclick="dialogo2()">
                OK
            </button>
        </div>
    </div>
    
    <?php include 'tabbar.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Loading Animation
        window.addEventListener('load', function() {
            setTimeout(() => {
                document.getElementById('loadingOverlay').classList.add('hidden');
                document.getElementById('mainContent').style.opacity = '1';
                document.getElementById('mainContent').style.transition = 'opacity 1s ease';
            }, 1500);
        });

        // Create floating particles
        function createParticles() {
            const particleContainer = document.getElementById('particles');
            const particleCount = 15;
            
            for (let i = 0; i < particleCount; i++) {
                const particle = document.createElement('div');
                particle.className = 'particle';
                particle.style.left = Math.random() * 100 + '%';
                particle.style.animationDuration = (Math.random() * 10 + 5) + 's';
                particle.style.animationDelay = Math.random() * 5 + 's';
                particleContainer.appendChild(particle);
            }
        }

        createParticles();

        // Modal functions
        function dialogo() {
            document.getElementById("announcementModal").classList.toggle("visible");
        }

        function dialogo2() {
            document.getElementById("checkinModal").classList.remove("visible");
        }

        // Check-in function - USANDO APENAS SWEETALERT2 SIMPLES
        function realizarCheckin() {
            const btn = event.target;
            const originalText = btn.textContent;
            
            // Add loading state
            btn.textContent = 'Processando...';
            btn.disabled = true;
            btn.style.opacity = '0.7';
            
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "servidor/checkin", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    // Reset button
                    btn.textContent = originalText;
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    
                    if (xhr.status === 200) {
                        var resposta = xhr.responseText.trim();
                        if (resposta === "login uma vez por dia") {
                            Swal.fire({
                                icon: 'info',
                                title: 'Aviso!',
                                text: resposta,
                                confirmButtonColor: '#FFD700',
                                background: '#1a1a1a',
                                color: '#fff'
                            });
                        } else {
                            Swal.fire({
                                icon: 'success',
                                title: '<?php echo htmlspecialchars($checkin_success_title, ENT_QUOTES, 'UTF-8'); ?>',
                                text: '<?php echo htmlspecialchars($checkin_success_message, ENT_QUOTES, 'UTF-8'); ?>',
                                confirmButtonColor: '#FFD700',
                                background: '#1a1a1a',
                                color: '#fff',
                                timer: 3000,
                                timerProgressBar: true
                            });
                        }
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: 'Falha na requisição. Tente novamente.',
                            confirmButtonColor: '#FFD700',
                            background: '#1a1a1a',
                            color: '#fff'
                        });
                    }
                }
            };
            xhr.send(null);
        }

        // Purchase function with loading state
        function buy(planoId) {
            const productCard = event.target.closest('.product-card');
            const productName = productCard.querySelector('.product-name').textContent;
            const productPrice = productCard.querySelector('.product-price').textContent;

            Swal.fire({
                title: 'Confirmar Compra?',
                html: `Você tem certeza que deseja adquirir o plano <strong>${productName}</strong> por <strong>${productPrice}</strong>?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#FFD700',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim, Comprar!',
                cancelButtonText: 'Cancelar',
                background: '#1a1a1a',
                color: '#fff'
            }).then((result) => {
                if (result.isConfirmed) {
                    const btn = event.target;
                    const originalText = btn.textContent;
                    
                    // Add loading state
                    btn.textContent = 'Processando...';
                    btn.disabled = true;
                    btn.style.opacity = '0.7';
                    
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "servidor/comprar", true);
                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4) {
                            // Reset button
                            btn.textContent = originalText;
                            btn.disabled = false;
                            btn.style.opacity = '1';
                            
                            if (xhr.status === 200) {
                                var resposta = xhr.responseText.trim();
                                var icon = 'info';
                                var titleText = '';

                                if (resposta === "sucesso!") {
                                    icon = 'success';
                                    titleText = 'Sucesso!';
                                } else if (resposta === "Saldo insuficiente") {
                                    icon = 'warning';
                                    titleText = 'Atenção!';
                                } else if (resposta.includes("VIP")) {
                                    icon = 'info';
                                    titleText = 'Informação';
                                } else {
                                    icon = 'error';
                                    titleText = 'Erro!';
                                }

                                Swal.fire({
                                    icon: icon,
                                    title: titleText,
                                    text: resposta,
                                    confirmButtonColor: '#FFD700',
                                    background: '#1a1a1a',
                                    color: '#fff'
                                });
                            }
                        }
                    };
                    xhr.send("id=" + encodeURIComponent(planoId));
                }
            });
        }

        // Ticker animation management
        document.addEventListener('DOMContentLoaded', function() {
            const ticker = document.getElementById('tickerContent');
            const announcements = [
                "<?php echo addslashes(htmlspecialchars($ticker_message_1, ENT_QUOTES, 'UTF-8')); ?>",
                "<?php echo addslashes(htmlspecialchars($ticker_message_2, ENT_QUOTES, 'UTF-8')); ?>",
                "<?php echo addslashes(htmlspecialchars($ticker_message_3, ENT_QUOTES, 'UTF-8')); ?>"
            ];
            let currentIndex = 0;

            setInterval(() => {
                currentIndex = (currentIndex + 1) % announcements.length;
                ticker.textContent = announcements[currentIndex];
            }, 8000);
        });
    </script>
</body>
</html>