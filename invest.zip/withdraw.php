<?php
session_start();

// REMOVIDO: O include('servidor/atualizar_rendimento.php') foi removido.
// A lógica de rendimento agora é processada na página 'equipe.php'.
include('servidor/infor.php');

// Redirect if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /");
    exit();
}

require 'servidor/database.php'; // Ensure database connection is established

$usuario_id = $_SESSION['user_id'];
$nome_completo = ''; // Initialize to avoid warnings

// Use PDO for database operations
try {
    $carteira_query = "SELECT nome_completo FROM carteiras WHERE uid = ?";
    $carteira_stmt = $pdo->prepare($carteira_query);
    $carteira_stmt->execute([$usuario_id]);
    $carteira = $carteira_stmt->fetch(PDO::FETCH_ASSOC);

    if (!$carteira) {
        // If no wallet is registered, redirect to the account setup
        header("Location: account");
        exit();
    }
} catch (PDOException $e) {
    // Log the error in production, show generic message to the user
    error_log("Erro de banco de dados ao buscar carteira: " . $e->getMessage());
    header("Location: /error.php"); // Redirect to a generic error page
    exit();
}

// Fetch user's withdrawal balance
$saldo_retirada = usuario($_SESSION['user_id'], 'saldo_retirada') ?? 0;

// Fetch withdrawal configuration from the database
$saque_minimo = 0;
$saque_taxa = 0;
$saque_diario_max = 0;
$saque_maximo_por_transacao = 0;
$permitir_saque_24h = false; // Default: restricted hours

try {
    $stmt_config = $pdo->query("SELECT saque_minimo, taxa_saque, saque_diario_max, saque_maximo_por_transacao, permitir_saque_24h FROM configuracoes ORDER BY id ASC LIMIT 1");
    $configuracoes = $stmt_config->fetch(PDO::FETCH_ASSOC);

    if ($configuracoes) {
        $saque_minimo = $configuracoes['saque_minimo'];
        $saque_taxa = $configuracoes['taxa_saque'];
        $saque_diario_max = $configuracoes['saque_diario_max'];
        $saque_maximo_por_transacao = $configuracoes['saque_maximo_por_transacao'];
        $permitir_saque_24h = (bool)$configuracoes['permitir_saque_24h']; // Convert to boolean
    }
} catch (PDOException $e) {
    error_log("Erro de banco de dados ao buscar configurações: " . $e->getMessage());
    // Fallback values already initialized
}

// --- Time and Day Validation Logic ---
date_default_timezone_set('America/Fortaleza'); // Ensure correct timezone
$dataHoraAtual = new DateTime();
$horaInicio = new DateTime('10:00:00');
$horaFim = new DateTime('17:00:00');
$diaDaSemanaPermitido = ($dataHoraAtual->format('N') >= 1 && $dataHoraAtual->format('N') <= 5); // Monday=1 to Friday=5

// The $horarioPermitido variable now depends on the database configuration
$horarioPermitido = $permitir_saque_24h || ($dataHoraAtual >= $horaInicio && $dataHoraAtual <= $horaFim && $diaDaSemanaPermitido);

header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="static/yunta/favicon.png">
    <meta name="viewport" content="width=device-width,user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1">
    <title>Retirar</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700&family=Poppins:wght@300;400;500;600;700;800&family=Montserrat:wght@800&display=swap" rel="stylesheet">
    <style>
        /* --- Hide Scrollbar --- */
        ::-webkit-scrollbar {
            width: 0px;
            background: transparent;
        }
        body {
            -ms-overflow-style: none; /* IE and Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* --- Basic Reset & Body Styles --- */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif; /* Consistent with other pages */
        }

        body {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            /* Heineken Background */
            background: linear-gradient(145deg, #0A4A3C 0%, #17706E 100%);
            color: #333;
            overflow-x: hidden;
            position: relative;
            padding-bottom: 0; /* No need for padding-bottom here if the main container handles it */
        }

        /* --- Background Shapes (consistent) --- */
        .background-shapes {
            position: fixed;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: 0;
            pointer-events: none;
        }
        .background-shapes div {
            position: absolute;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 50%;
            animation: moveShapes 15s infinite ease-in-out alternate;
        }
        .background-shapes div:nth-child(1) { width: 100px; height: 100px; top: 10%; left: 10%; animation-delay: 0s; }
        .background-shapes div:nth-child(2) { width: 150px; height: 150px; top: 50%; left: 80%; animation-delay: 2s; }
        .background-shapes div:nth-child(3) { width: 80px; height: 80px; top: 70%; left: 20%; animation-delay: 4s; }
        .background-shapes div:nth-child(4) { width: 200px; height: 200px; top: 20%; left: 60%; animation-delay: 6s; }
        .background-shapes div:nth-child(5) { width: 120px; height: 120px; top: 80%; left: 50%; animation-delay: 8s; }

        @keyframes moveShapes {
            0% { transform: translate(0, 0) scale(1); opacity: 0.8; }
            50% { transform: translate(30px, 50px) scale(1.1); opacity: 0.6; }
            100% { transform: translate(0, 0) scale(1); opacity: 0.8; }
        }

        /* --- Main Container (like .device on other pages) --- */
        .main-container {
            max-width: 750px;
            width: 100%;
            margin: 0 auto;
            padding-bottom: 30px; /* Adjust if a fixed tabbar is present below content */
            background: rgba(255, 255, 255, 0.1); /* Glassmorphism effect */
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            z-index: 1;
            min-height: 100vh;
            padding-top: 0;
            display: flex;
            flex-direction: column; /* Allows content to stack vertically */
        }

        /* --- Header (consistent) --- */
        .header {
            padding: 50px 17px 20px;
            background: rgba(255, 255, 255, 0.15);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            justify-content: space-between; /* Space out title and icon */
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 20;
        }

        .header .back-button {
            display: flex;
            align-items: center;
            cursor: pointer;
            width: 24px;
            height: 24px;
            margin-right: 15px;
            filter: invert(100%) brightness(1.5) drop-shadow(0 0 3px rgba(0,0,0,0.3)); /* White arrow with shadow */
        }

        .header-title {
            font-family: 'Montserrat', sans-serif;
            color: #fff;
            font-size: 26px;
            font-weight: 800;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.3);
        }

        /* Style for the circular container of the "Payment History" text */
        .payment-history-circle {
            background: rgba(255, 255, 255, 0.3); /* Translucent background */
            border-radius: 50px; /* Large enough to be circular */
            padding: 8px 15px; /* Internal padding */
            color: #fff;
            font-family: 'Poppins', sans-serif;
            font-size: 14px; /* Adjust font size if necessary */
            font-weight: 600;
            text-align: center;
            cursor: pointer;
            white-space: nowrap; /* Ensures text stays on one line */
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .payment-history-circle:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0,0,0,0.3);
        }
        .payment-history-circle:active {
            transform: translateY(0);
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }

        /* --- Withdraw Card (Balance Display) --- */
        .withdraw-card {
            padding: 20px 17px;
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.2); /* Translucent background */
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            text-align: center; /* Center content */
            animation: slideInLeft 0.6s ease-out forwards;
            animation-delay: 0.2s;
            opacity: 0;
        }

        @keyframes slideInLeft {
            from { opacity: 0; transform: translateX(-50px); }
            to { opacity: 1; transform: translateX(0); }
        }

        .withdraw-card .balance-label {
            font-size: 15px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }

        .withdraw-card .balance-amount {
            margin-top: 8px;
            font-family: 'Montserrat', sans-serif; /* Montserrat for amount */
            font-weight: 800;
            font-size: 38px;
            color: #FFD700; /* Gold for value */
            text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.4);
        }

        /* --- Withdraw Input Box --- */
        .withdraw-box {
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.15); /* Slightly less opaque for inner elements */
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 20px;
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.4s;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .withdraw-box .input-label {
            font-size: 15px;
            color: rgba(255, 255, 255, 0.9);
            font-weight: 500;
            margin-bottom: 12px;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
        }

        .withdraw-input-wrapper {
            height: 50px; /* Slightly taller input */
            background: rgba(255, 255, 255, 0.3); /* Lighter background for input */
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.5);
            display: flex;
            align-items: center;
            padding: 0 15px;
            color: #0A4A3C; /* Dark green text for input */
            font-size: 18px;
            font-weight: 600;
            box-shadow: inset 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .withdraw-input-wrapper span {
            color: #0A4A3C;
        }

        .withdraw-input-wrapper input {
            flex: 1;
            margin-left: 10px;
            border: none;
            outline: none;
            background: transparent;
            font-size: 18px;
            color: #0A4A3C;
            font-weight: 600;
        }
        .withdraw-input-wrapper input::placeholder {
            color: rgba(10, 74, 60, 0.7); /* Lighter placeholder text */
        }

        .withdraw-button {
            height: 55px;
            margin-top: 25px;
            background: linear-gradient(90deg, #FFD700 0%, #FFA500 100%); /* Gold button */
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
            color: #333;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(255, 215, 0, 0.3);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .withdraw-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 25px rgba(255, 215, 0, 0.4);
        }
        .withdraw-button:active {
            transform: translateY(0);
            box-shadow: 0 5px 15px rgba(255, 215, 0, 0.2);
        }

        /* --- Instructions Section --- */
        .withdraw-bottom {
            margin: 20px auto;
            width: calc(100% - 34px);
            background: rgba(255, 255, 255, 0.15);
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 20px;
            color: #fff;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.2);
            animation: fadeInUp 0.8s ease-out forwards;
            animation-delay: 0.6s;
            opacity: 0;
        }

        .withdraw-bottom p {
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            line-height: 1.6; /* Improved readability */
            margin-bottom: 10px;
            color: rgba(255, 255, 255, 0.9);
        }
        .withdraw-bottom p strong {
            color: #FFD700; /* Gold for strong text */
            font-weight: 600;
        }
        .withdraw-bottom p:last-child {
            margin-bottom: 0; /* Remove margin from last paragraph */
        }
        .withdraw-bottom .info-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #FFD700; /* Gold for section title */
            text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
        }

        /* --- Withdrawal Time Alert --- */
        .withdraw-time-alert {
            margin: 20px auto;
            width: calc(100% - 34px);
            background: linear-gradient(45deg, #f7dc6f, #f0c300); /* Gold-yellow alert */
            border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            padding: 15px;
            color: #333;
            font-family: 'Poppins', sans-serif;
            font-size: 15px;
            text-align: center;
            font-weight: 600;
            text-shadow: 1px 1px 2px rgba(255,255,255,0.5);
            animation: fadeIn 0.5s ease-out forwards;
            animation-delay: 0.8s; /* Adjusted to appear after other sections */
            opacity: 0;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* --- Responsive Adjustments --- */
        @media (max-width: 500px) {
            .main-container {
                border-radius: 0;
                box-shadow: none;
                padding-bottom: 20px;
            }
            .header {
                padding: 40px 15px 15px;
            }
            .header-title {
                font-size: 24px;
            }
            .payment-history-circle {
                font-size: 12px; /* Reduce font on smaller screens */
                padding: 6px 12px;
            }
            .withdraw-card,
            .withdraw-box,
            .withdraw-bottom,
            .withdraw-time-alert {
                width: calc(100% - 30px); /* Slightly less padding on smaller screens */
                margin-left: 15px;
                margin-right: 15px;
            }
            .withdraw-card .balance-amount {
                font-size: 34px;
            }
            .withdraw-input-wrapper {
                height: 45px;
                font-size: 16px;
            }
            .withdraw-input-wrapper input {
                font-size: 16px;
            }
            .withdraw-button {
                height: 50px;
                font-size: 18px;
            }
            .withdraw-bottom p {
                font-size: 13px;
            }
            .withdraw-bottom .info-title {
                font-size: 15px;
            }
            .withdraw-time-alert {
                font-size: 14px;
                padding: 12px;
            }
        }
    </style>
</head>

<body class="uni-body pages-sys-user-withdraw">
    <div class="background-shapes">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>

    <div class="main-container">
        <div class="header">
            <div class="back-button-group">
                <div class="back-button" onclick="window.history.back()">
                    <img src="static/yunta/image/device/left.png" alt="Voltar">
                </div>
            </div>
            <div class="header-title">Retirar</div>
            <div class="history-icon-wrapper">
                <div class="payment-history-circle" onclick="window.location.href='withdrawal_records.php'">
                    Histórico de Pagamento
                </div>
            </div>
        </div>

        <?php if (!$permitir_saque_24h && !$horarioPermitido): ?>
            <div class="withdraw-time-alert">
                Atenção: O horário de retirada permitido é de Segunda a Sexta, das 10:00 às 17:00.
            </div>
        <?php endif; ?>

        <div class="withdraw-card">
            <div>
                <div class="balance-label">Meu Saldo de Retirada</div>
                <div class="balance-amount">R$<?php echo number_format($saldo_retirada, 2, ',', '.'); ?></div>
            </div>
        </div>

        <div class="withdraw-box">
            <div>
                <div class="input-label">Valor de retirada</div>
                <div class="withdraw-input-wrapper">
                    <span>R$</span>
                    <input maxlength="140" id="amount" placeholder="Por favor, insira o valor do saque" type="number" class="uni-input-input">
                </div>
            </div>
            <div class="withdraw-button" onclick="iniciarRetirada()">
                Retirar
            </div>
        </div>

        <div class="withdraw-bottom">
            <p class="info-title">Instruções de Retirada</p>
            <p>1. Valor mínimo de retirada: <strong>R$<?php echo number_format($saque_minimo, 2, ',', '.'); ?></strong>.</p>
            <p>2. Valor máximo por transação: <strong>R$<?php echo number_format($saque_maximo_por_transacao, 2, ',', '.'); ?></strong>.</p>
            <p>3. Taxa de retirada: <strong><?php echo number_format($saque_taxa, 2, ',', '.'); ?>%</strong>.</p>
            <p>4. Limite máximo diário de saque: <strong>R$<?php echo number_format($saque_diario_max, 2, ',', '.'); ?></strong>.</p>
            <p>
                5. Horário de retirada:
                <?php if ($permitir_saque_24h): ?>
                    <strong>24 horas por dia, 7 dias por semana.</strong>
                <?php else: ?>
                    <strong>De Segunda a Sexta, das 10:00 às 17:00.</strong>
                    <br>Solicitações fora deste horário serão processadas no próximo período de operação.
                <?php endif; ?>
            </p>
            <p>6. Preencha as informações corretas da conta bancária (PIX) para garantir que seu saque chegue a tempo. Seu saque será enviado para a chave PIX registrada em "Minha Conta Bancária".</p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        /**
         * Handles the withdrawal request.
         */
        function iniciarRetirada() {
            const valorRetirada = parseFloat(document.getElementById('amount').value);
            const saldoAtual = parseFloat(<?php echo json_encode($saldo_retirada); ?>);
            const saqueMinimo = parseFloat(<?php echo json_encode($saque_minimo); ?>);
            const saqueMaximoPorTransacao = parseFloat(<?php echo json_encode($saque_maximo_por_transacao); ?>);
            const taxaSaque = parseFloat(<?php echo json_encode($saque_taxa); ?>);
            const permitirSaque24h = <?php echo json_encode($permitir_saque_24h); ?>;
            const horarioPermitidoAtual = <?php echo json_encode($horarioPermitido); ?>;

            // 1. Validação de horário de retirada
            if (!permitirSaque24h && !horarioPermitidoAtual) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Horário de Retirada!',
                    text: 'Retiradas são processadas apenas de Segunda a Sexta, das 10:00 às 17:00. Por favor, tente novamente neste período.',
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // 2. Validação de entrada
            if (isNaN(valorRetirada) || valorRetirada <= 0) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Atenção!',
                    text: 'Por favor, insira um valor válido para a retirada.',
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // 3. Validação de saque mínimo
            if (valorRetirada < saqueMinimo) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro!',
                    text: `O valor mínimo para retirada é de R$${saqueMinimo.toFixed(2).replace('.', ',')}.`,
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // 4. Validação de saque máximo por transação
            if (saqueMaximoPorTransacao > 0 && valorRetirada > saqueMaximoPorTransacao) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro!',
                    text: `O valor máximo permitido por transação é de R$${saqueMaximoPorTransacao.toFixed(2).replace('.', ',')}.`,
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // 5. VALIDAÇÃO DE SALDO CORRIGIDA: Agora verifica apenas se o saldo cobre o valor bruto do saque
            if (valorRetirada > saldoAtual) {
                Swal.fire({
                    icon: 'error',
                    title: 'Saldo Insuficiente!',
                    html: `Seu saldo (R$${saldoAtual.toFixed(2).replace('.', ',')}) é insuficiente para a retirada de R$${valorRetirada.toFixed(2).replace('.', ',')}.`,
                    position: 'center',
                    showConfirmButton: true
                });
                return;
            }

            // 6. Calcula a taxa APENAS para exibir na mensagem de confirmação
            const taxaCalculada = valorRetirada * (taxaSaque / 100);
            const totalLiquido = valorRetirada - taxaCalculada;

            // 7. Confirma a retirada com o usuário, explicando a nova lógica
            Swal.fire({
                title: 'Confirmar Retirada?',
                html: `Você está solicitando uma retirada de <strong>R$${valorRetirada.toFixed(2).replace('.', ',')}</strong>.<br>
                        A taxa de **${taxaSaque.toFixed(2).replace('.', ',')}%** será deduzida do valor final quando o pagamento for processado, resultando em um valor líquido de **R$${totalLiquido.toFixed(2).replace('.', ',')}** a ser recebido.<br><br>
                        **Importante:** O valor total da solicitação (R$${valorRetirada.toFixed(2).replace('.', ',')}) será deduzido do seu saldo agora para reservar o valor.`,
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sim, solicitar retirada!',
                cancelButtonText: 'Cancelar'
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch("servidor/retirada.php", {
                        method: "POST",
                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                        body: `amount=${encodeURIComponent(valorRetirada)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        Swal.fire({
                            icon: data.success ? 'success' : 'error',
                            title: data.success ? 'Sucesso!' : 'Aviso!',
                            text: data.message,
                            position: 'center',
                            showConfirmButton: true
                        });

                        if (data.success) {
                            document.getElementById('amount').value = '';
                            setTimeout(() => location.reload(), 1500);
                        }
                    })
                    .catch(error => {
                        console.error("Erro na solicitação de retirada:", error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Erro!',
                            text: 'Não foi possível processar a retirada. Tente novamente mais tarde.',
                            position: 'center',
                            showConfirmButton: true
                        });
                    });
                }
            });
        }
    </script>
</body>
</html>